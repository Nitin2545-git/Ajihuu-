# Lumina AI — Enterprise Intelligent Assistant for Android

Lumina AI is an advanced, production-ready Android AI Assistant powered by Google Gemini 3.5 & Pro models, Jetpack Compose, Room Database persistence, and an intelligent multi-layer AI core.

---

## 🌟 Key Features

### 🚀 Gemini AI Core Integration
- **Multi-Model Support**: Integrated with `gemini-3.5-flash`, `gemini-3.1-pro`, and `gemini-3.1-flash-lite`.
- **Real-Time Streaming**: Low-latency token-by-token response streaming using Kotlin Flow and Ktor.
- **Dynamic Model Router**: Classifies user intent (Coding, Multi-Turn Reasoning, Creative Writing, Simple Query) and dynamically routes queries to the optimal model to optimize latency and token cost.

### 🧠 Advanced AI Intelligence Engine (Phase 6.5B)
- **Long-Term & Short-Term Memory Engine**: Contextual memory extraction, preference tracking, and semantic context injection.
- **Memory Expiration & Privacy Controls**: Granular user privacy options with automatic memory pruning and one-tap memory wipe.
- **Tool & Function Calling Layer**: Future-ready execution engine supporting code evaluation, mathematical expressions, and knowledge retrieval tools.
- **Grounding & Hallucination Reduction**: Verification system with explicit grounding constraints and AI confidence scoring.
- **Smart Follow-Up Generator**: Generates contextually aware follow-up suggestions based on message responses.
- **Context Compression & Repair Engine**: Deduplicates chat threads and compresses long histories to prevent token window overflow.

### 🎨 Modern Android Architecture & Design
- **100% Jetpack Compose UI**: Material Design 3 styling with dynamic dark canvas aesthetics, fluid animations, and custom vector icons.
- **Offline First**: Offline local persistence backed by Android Room Database for chat sessions and history messages.
- **Custom Adaptive Icon**: Modern branded application launcher icon with full vector adaptive layers.

---

## 📁 Repository Structure

```
LuminaAI/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/example/luminaai/
│   │   │   │   ├── data/             # Room Local Database & Remote Gemini API Client
│   │   │   │   ├── domain/
│   │   │   │   │   ├── intelligence/ # Memory, Router, Prompt Enhancer, Tool Calling
│   │   │   │   │   ├── model/        # Domain Models (ChatMessage, ChatSession, Persona)
│   │   │   │   │   └── repository/   # Repository Interfaces & Impls
│   │   │   │   └── ui/               # Jetpack Compose Views, Theme & Navigation
│   │   │   └── res/                  # Strings, Vectors, Adaptive Icons
│   │   └── test/                     # Robolectric & Intelligence Layer Unit Tests
├── .env.example                      # Secrets template (GEMINI_API_KEY)
├── .gitignore                        # Git exclusion rules
├── build.gradle.kts                  # Root Gradle build script
├── LICENSE                           # Apache 2.0 License
└── README.md                         # Documentation
```

---

## ⚙️ Requirements & Setup

1. **Android Studio**: Android Studio Jellyfish / Ladybug or newer.
2. **JDK**: Java 17+.
3. **Gemini API Key**: Obtain a key from [Google AI Studio](https://aistudio.google.com/).
4. **Configuration**:
   - Create a `.env` file in the root directory (or use AI Studio Secrets):
     ```env
     GEMINI_API_KEY=your_actual_api_key_here
     ```

---

## 🧪 Testing

Run JVM Unit and Robolectric tests via Gradle:
```bash
gradle :app:testDebugUnitTest
```

---

## 🛡️ License

Licensed under the Apache License, Version 2.0. See [LICENSE](LICENSE) for details.

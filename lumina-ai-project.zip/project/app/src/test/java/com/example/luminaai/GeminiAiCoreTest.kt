package com.example.luminaai

import com.example.luminaai.data.remote.gemini.GeminiApiClient
import com.example.luminaai.data.remote.gemini.GeminiCacheManager
import com.example.luminaai.data.remote.gemini.GeminiModelRegistry
import com.example.luminaai.data.remote.gemini.GeminiPromptBuilder
import com.example.luminaai.data.remote.gemini.GeminiSafetyManager
import com.example.luminaai.data.remote.gemini.GeminiTokenCounter
import com.example.luminaai.data.remote.gemini.LuminaPersona
import com.example.luminaai.domain.model.ChatMessage
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class GeminiAiCoreTest {

    @Before
    fun setUp() {
        GeminiCacheManager.clearCache()
        GeminiTokenCounter.resetStats()
    }

    @Test
    fun testPromptBuilderConstructsValidRequestWithPersona() {
        val messages = listOf(
            ChatMessage(id = "1", sessionId = "s1", sender = ChatMessage.Sender.USER, content = "Hello Lumina", timestamp = System.currentTimeMillis()),
            ChatMessage(id = "2", sessionId = "s1", sender = ChatMessage.Sender.ASSISTANT, content = "Hi! How can I help?", timestamp = System.currentTimeMillis())
        )

        val request = GeminiPromptBuilder.buildRequest(
            messages = messages,
            latestPrompt = "Write a Kotlin function",
            persona = LuminaPersona.CODE_EXPERT
        )

        assertNotNull(request.systemInstruction)
        assertTrue(request.systemInstruction?.parts?.firstOrNull()?.text?.contains("senior Android", ignoreCase = true) == true)
        assertEquals(3, request.contents.size)
        assertEquals("user", request.contents.last().role)
        assertEquals("Write a Kotlin function", request.contents.last().parts.first().text)
    }

    @Test
    fun testConversationSummaryGeneration() {
        val messages = listOf(
            ChatMessage(id = "1", sessionId = "s1", sender = ChatMessage.Sender.USER, content = "How do I implement Room database in Android?", timestamp = System.currentTimeMillis())
        )

        val summary = GeminiPromptBuilder.createConversationSummary(messages)
        assertTrue(summary.startsWith("How do I implement"))
    }



    @Test
    fun testTokenCounterEstimationAndStats() {
        val sampleText = "This is a test prompt for Lumina AI"
        val estimated = GeminiTokenCounter.estimateTokens(sampleText)
        assertTrue(estimated > 0)

        GeminiTokenCounter.recordUsage(promptTokens = 15, candidateTokens = 40)
        val stats = GeminiTokenCounter.usageStats.value

        assertEquals(15, stats.sessionPromptTokens)
        assertEquals(40, stats.sessionCandidateTokens)
        assertEquals(55, stats.sessionTotalTokens)
        assertEquals(1, stats.totalRequests)
    }

    @Test
    fun testSafetyManagerValidation() {
        val safePrompt = "Explain Kotlin coroutines simply"
        val safeResult = GeminiSafetyManager.validatePromptSafety(safePrompt)
        assertTrue(safeResult is GeminiSafetyManager.ModerationResult.Allowed)

        val flaggedPrompt = "malware_payload exploit_injection"
        val flaggedResult = GeminiSafetyManager.validatePromptSafety(flaggedPrompt)
        assertTrue(flaggedResult is GeminiSafetyManager.ModerationResult.Flagged)
    }

    @Test
    fun testResponseCacheManager() {
        val prompt = "What is Lumina AI?"
        val model = GeminiModelRegistry.DEFAULT_MODEL
        val response = "Lumina AI is an advanced intelligent assistant."

        GeminiCacheManager.putCachedResponse(prompt, model, response)
        val cached = GeminiCacheManager.getCachedResponse(prompt, model)

        assertEquals(response, cached)
    }

    @Test
    fun testLocalIntelligentFallbackGeneration() = runBlocking {
        val request = GeminiPromptBuilder.buildRequest(
            messages = emptyList(),
            latestPrompt = "Explain how to use Jetpack Compose code",
            persona = LuminaPersona.DEFAULT
        )

        val response = GeminiApiClient.generateContent(
            modelName = GeminiModelRegistry.DEFAULT_MODEL,
            request = request
        )

        assertNotNull(response)
        assertTrue(response.contains("Lumina") || response.contains("Jetpack Compose"))
    }
}

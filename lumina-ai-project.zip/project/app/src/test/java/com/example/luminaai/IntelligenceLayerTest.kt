package com.example.luminaai

import com.example.luminaai.data.remote.gemini.GeminiModelRegistry
import com.example.luminaai.data.remote.gemini.LuminaPersona
import com.example.luminaai.domain.intelligence.ContextRepairEngine
import com.example.luminaai.domain.intelligence.IntentAndModelRouter
import com.example.luminaai.domain.intelligence.MemoryCategory
import com.example.luminaai.domain.intelligence.MemoryEngine
import com.example.luminaai.domain.intelligence.MemoryItem
import com.example.luminaai.domain.intelligence.MemoryPrivacyConfig
import com.example.luminaai.domain.intelligence.PromptEnhancer
import com.example.luminaai.domain.intelligence.QualityRating
import com.example.luminaai.domain.intelligence.ResponseEvaluator
import com.example.luminaai.domain.intelligence.ToolCallingEngine
import com.example.luminaai.domain.intelligence.UserIntent
import com.example.luminaai.domain.model.ChatMessage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class IntelligenceLayerTest {

    @Before
    fun setUp() {
        MemoryEngine.clearAllMemories()
        MemoryEngine.updatePrivacyConfig(MemoryPrivacyConfig(allowLongTermMemory = true))
    }

    @Test
    fun testMemoryEngineStoreRetrieveAndExtraction() {
        // Test manual store
        MemoryEngine.saveMemory(
            MemoryItem(key = "test_key", value = "test_val", category = MemoryCategory.PREFERENCE)
        )
        val retrieved = MemoryEngine.getMemory("test_key")
        assertNotNull(retrieved)
        assertEquals("test_val", retrieved?.value)

        // Test auto extraction
        MemoryEngine.extractAndLearnFromUserPrompt("My name is Alex")
        val nameMem = MemoryEngine.getMemory("user_name")
        assertNotNull(nameMem)
        assertEquals("Alex", nameMem?.value)
    }

    @Test
    fun testMemoryPrivacyControlsClearAll() {
        MemoryEngine.saveMemory(
            MemoryItem(key = "temp_key", value = "temp_val", category = MemoryCategory.PREFERENCE)
        )
        MemoryEngine.updatePrivacyConfig(MemoryPrivacyConfig(allowLongTermMemory = false))

        val memoryAfterPrivacyDisable = MemoryEngine.getMemory("temp_key")
        assertEquals(null, memoryAfterPrivacyDisable)
    }

    @Test
    fun testIntentClassificationAndModelRouting() {
        val codingPrompt = "Write a Kotlin function using StateFlow in Jetpack Compose"
        val intent = IntentAndModelRouter.classifyIntent(codingPrompt)
        assertEquals(UserIntent.CODING, intent)

        val routing = IntentAndModelRouter.routeQuery(codingPrompt)
        assertEquals(GeminiModelRegistry.PRO_MODEL, routing.selectedModel)

        val simplePrompt = "Hi, how are you?"
        val simpleIntent = IntentAndModelRouter.classifyIntent(simplePrompt)
        assertEquals(UserIntent.SIMPLE_QUERY, simpleIntent)

        val simpleRouting = IntentAndModelRouter.routeQuery(simplePrompt)
        assertEquals(GeminiModelRegistry.LIGHT_MODEL, simpleRouting.selectedModel)
        assertTrue(simpleRouting.estimatedTokenCostReductionPercent > 0)
    }

    @Test
    fun testPromptEnhancerMemoryAndGroundingInjection() {
        MemoryEngine.saveMemory(
            MemoryItem(key = "preferred_architecture", value = "Clean MVVM with Coroutines", category = MemoryCategory.PREFERENCE)
        )

        val systemInstruction = PromptEnhancer.buildEnhancedSystemInstruction(
            persona = LuminaPersona.CODE_EXPERT,
            latestPrompt = "preferred_architecture"
        )

        assertTrue(systemInstruction.contains("senior Android", ignoreCase = true))
        assertTrue(systemInstruction.contains("preferred_architecture"))
        assertTrue(systemInstruction.contains("Ground all technical assertions"))
    }

    @Test
    fun testToolCallingExecutionEngine() {
        val tools = ToolCallingEngine.REGISTERED_TOOLS
        assertTrue(tools.isNotEmpty())

        val calcResult = ToolCallingEngine.executeTool("calculator", mapOf("expression" to "12 + 28"))
        assertTrue(calcResult.isSuccess)
        assertTrue(calcResult.output.contains("40.0"))

        val codeEval = ToolCallingEngine.executeTool("code_evaluator", mapOf("code" to "fun hello() = println()", "language" to "Kotlin"))
        assertTrue(codeEval.isSuccess)
        assertTrue(codeEval.output.contains("PASSED"))
    }

    @Test
    fun testResponseEvaluatorAndSmartFollowUps() {
        val prompt = "How do I implement ViewModel in Jetpack Compose?"
        val response = "```kotlin\n@Composable\nfun MyScreen(viewModel: MyViewModel = viewModel()) {\n}\n```"

        val evaluation = ResponseEvaluator.evaluateResponse(response, prompt)
        assertTrue(evaluation.confidenceScore > 0.8f)
        assertEquals(QualityRating.EXCELLENT, evaluation.qualityRating)
        assertTrue(evaluation.isCodeValidated)
        assertTrue(evaluation.followUpSuggestions.size >= 2)
    }

    @Test
    fun testContextRepairEngineDeduplication() {
        val timestamp = System.currentTimeMillis()
        val messages = listOf(
            ChatMessage(id = "1", sessionId = "s1", sender = ChatMessage.Sender.USER, content = "Hello", timestamp = timestamp),
            ChatMessage(id = "2", sessionId = "s1", sender = ChatMessage.Sender.USER, content = "Hello", timestamp = timestamp + 100),
            ChatMessage(id = "3", sessionId = "s1", sender = ChatMessage.Sender.ASSISTANT, content = "Hi there!", timestamp = timestamp + 200)
        )

        val repairResult = ContextRepairEngine.analyzeAndRepairContext(messages)
        assertTrue(repairResult.isRepaired)
        assertEquals(2, repairResult.cleanedMessages.size)
    }
}

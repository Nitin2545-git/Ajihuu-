package com.example.luminaai.ui.chat

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CodeBlockView(
    language: String,
    code: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isCopied by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF1E1E2E)
        ),
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .testTag("code_block_$language")
    ) {
        Column {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF181825))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = language.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF89B4FA),
                    fontFamily = FontFamily.Monospace
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Code snippet", code)
                            clipboard.setPrimaryClip(clip)
                            isCopied = true
                            Toast.makeText(context, "Code copied to clipboard", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("copy_code_button")
                    ) {
                        Icon(
                            imageVector = if (isCopied) Icons.Default.Check else Icons.Default.ContentCopy,
                            contentDescription = "Copy code",
                            tint = if (isCopied) Color(0xFFA6E3A1) else Color(0xFFCDD6F4),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Code Content Body with horizontal scroll
            val scrollState = rememberScrollState()
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState)
                    .padding(12.dp)
            ) {
                Text(
                    text = highlightSyntax(code),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    color = Color(0xFFCDD6F4)
                )
            }
        }
    }
}

private fun highlightSyntax(code: String): AnnotatedString {
    val keywords = setOf(
        "fun", "val", "var", "class", "interface", "object", "import", "package",
        "return", "if", "else", "when", "for", "while", "try", "catch", "throw",
        "override", "public", "private", "protected", "internal", "data", "sealed",
        "def", "function", "const", "let", "async", "await", "import", "from", "export"
    )

    return buildAnnotatedString {
        val lines = code.split("\n")
        lines.forEachIndexed { lineIdx, line ->
            var idx = 0
            while (idx < line.length) {
                // Check comments
                if (line.substring(idx).startsWith("//")) {
                    appendAnnotated(line.substring(idx), SpanStyle(color = Color(0xFF6C7086)))
                    break
                }

                // Check strings
                if (line[idx] == '"' || line[idx] == '\'') {
                    val quoteChar = line[idx]
                    val endQuote = line.indexOf(quoteChar, idx + 1)
                    if (endQuote != -1) {
                        val str = line.substring(idx, endQuote + 1)
                        appendAnnotated(str, SpanStyle(color = Color(0xFFA6E3A1)))
                        idx = endQuote + 1
                        continue
                    }
                }

                // Check words/keywords
                val isLetter = line[idx].isLetterOrDigit() || line[idx] == '_' || line[idx] == '@'
                if (isLetter) {
                    val start = idx
                    while (idx < line.length && (line[idx].isLetterOrDigit() || line[idx] == '_' || line[idx] == '@')) {
                        idx++
                    }
                    val word = line.substring(start, idx)
                    if (keywords.contains(word)) {
                        appendAnnotated(word, SpanStyle(color = Color(0xFFCBA6F7), fontWeight = FontWeight.Bold))
                    } else if (word.startsWith("@")) {
                        appendAnnotated(word, SpanStyle(color = Color(0xFFFAB387)))
                    } else if (word.first().isUpperCase()) {
                        appendAnnotated(word, SpanStyle(color = Color(0xFF89B4FA)))
                    } else {
                        appendAnnotated(word, SpanStyle(color = Color(0xFFCDD6F4)))
                    }
                } else {
                    append(line[idx].toString())
                    idx++
                }
            }

            if (lineIdx < lines.size - 1) {
                append("\n")
            }
        }
    }
}

private fun AnnotatedString.Builder.appendAnnotated(text: String, style: SpanStyle) {
    val start = length
    append(text)
    addStyle(style, start, length)
}

package com.example.luminaai.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.luminaai.domain.model.GeneratedImage

@Entity(tableName = "generated_images")
data class GeneratedImageEntity(
    @PrimaryKey val id: String,
    val prompt: String,
    val negativePrompt: String = "",
    val stylePreset: String = "Realistic",
    val imageUrl: String,
    val aspectRatio: String,
    val quality: String = "Standard",
    val modelName: String,
    val createdAt: Long,
    val isFavorite: Boolean
) {
    fun toDomain(): GeneratedImage = GeneratedImage(
        id = id,
        prompt = prompt,
        negativePrompt = negativePrompt,
        stylePreset = stylePreset,
        imageUrl = imageUrl,
        aspectRatio = aspectRatio,
        quality = quality,
        modelName = modelName,
        createdAt = createdAt,
        isFavorite = isFavorite
    )

    companion object {
        fun fromDomain(image: GeneratedImage): GeneratedImageEntity = GeneratedImageEntity(
            id = image.id,
            prompt = image.prompt,
            negativePrompt = image.negativePrompt,
            stylePreset = image.stylePreset,
            imageUrl = image.imageUrl,
            aspectRatio = image.aspectRatio,
            quality = image.quality,
            modelName = image.modelName,
            createdAt = image.createdAt,
            isFavorite = image.isFavorite
        )
    }
}


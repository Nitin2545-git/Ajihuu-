package com.example.luminaai.domain.intelligence

import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

enum class MemoryCategory {
    PREFERENCE,
    FACT,
    TOPIC,
    STYLE,
    SYSTEM
}

data class MemoryItem(
    val id: String = UUID.randomUUID().toString(),
    val key: String,
    val value: String,
    val category: MemoryCategory,
    val confidence: Float = 0.9f,
    val timestamp: Long = System.currentTimeMillis(),
    val expiresAt: Long? = null,
    val isPrivate: Boolean = false
)

data class MemoryPrivacyConfig(
    val allowLongTermMemory: Boolean = true,
    val autoExpireDays: Int = 30,
    val encryptPrivateItems: Boolean = true
)

/**
 * Long-Term & Short-Term Memory Engine for Lumina AI.
 * Handles semantic retrieval, user preference learning, privacy controls, and memory expiration.
 */
object MemoryEngine {

    private val memoryStore = ConcurrentHashMap<String, MemoryItem>()
    private var privacyConfig = MemoryPrivacyConfig()

    init {
        // Default seed memories for baseline AI personalization
        saveMemory(MemoryItem(key = "preferred_language", value = "Kotlin", category = MemoryCategory.PREFERENCE))
        saveMemory(MemoryItem(key = "preferred_ui_framework", value = "Jetpack Compose", category = MemoryCategory.PREFERENCE))
        saveMemory(MemoryItem(key = "response_tone", value = "Professional, concise, and helpful", category = MemoryCategory.STYLE))
    }

    fun updatePrivacyConfig(config: MemoryPrivacyConfig) {
        privacyConfig = config
        if (!config.allowLongTermMemory) {
            clearAllMemories()
        }
    }

    fun saveMemory(item: MemoryItem) {
        if (!privacyConfig.allowLongTermMemory) return
        memoryStore[item.key] = item
    }

    fun getMemory(key: String): MemoryItem? {
        val item = memoryStore[key] ?: return null
        if (item.expiresAt != null && System.currentTimeMillis() > item.expiresAt) {
            memoryStore.remove(key)
            return null
        }
        return item
    }

    fun getAllMemories(): List<MemoryItem> {
        pruneExpiredMemories()
        return memoryStore.values.toList()
    }

    fun deleteMemory(key: String) {
        memoryStore.remove(key)
    }

    fun clearAllMemories() {
        memoryStore.clear()
    }

    /**
     * Learns and extracts user preferences, coding style, writing style, image preferences, and key facts automatically from incoming user messages.
     */
    fun extractAndLearnFromUserPrompt(prompt: String) {
        if (!privacyConfig.allowLongTermMemory) return
        val lower = prompt.lowercase()

        when {
            lower.contains("i prefer") || lower.contains("i like") || lower.contains("my favorite") -> {
                val value = prompt.takeLast(80).trim()
                saveMemory(MemoryItem(key = "user_preference_${System.currentTimeMillis() % 1000}", value = value, category = MemoryCategory.PREFERENCE))
            }
            lower.contains("my name is") -> {
                val idx = prompt.indexOf("my name is", ignoreCase = true)
                val name = if (idx >= 0) prompt.substring(idx + 10).trim().take(30) else ""
                if (name.isNotBlank()) {
                    saveMemory(MemoryItem(key = "user_name", value = name, category = MemoryCategory.FACT))
                }
            }
            lower.contains("write in") || lower.contains("tone:") || lower.contains("style:") -> {
                val value = prompt.takeLast(60).trim()
                saveMemory(MemoryItem(key = "preferred_writing_style", value = value, category = MemoryCategory.STYLE))
            }
            lower.contains("code in") || lower.contains("use framework") || lower.contains("prefer language") -> {
                val value = prompt.takeLast(60).trim()
                saveMemory(MemoryItem(key = "coding_preference", value = value, category = MemoryCategory.PREFERENCE))
            }
            lower.contains("generate image") || lower.contains("art style") || lower.contains("photorealistic") -> {
                val value = prompt.takeLast(60).trim()
                saveMemory(MemoryItem(key = "image_gen_preference", value = value, category = MemoryCategory.PREFERENCE))
            }
            lower.contains("android") || lower.contains("compose") || lower.contains("kotlin") -> {
                saveMemory(MemoryItem(key = "primary_tech_stack", value = "Android / Kotlin / Compose", category = MemoryCategory.TOPIC))
            }
        }
    }

    /**
     * Retrieves semantic context memories relevant to the prompt for injection into system instruction.
     */
    fun retrieveRelevantContext(prompt: String): String {
        if (!privacyConfig.allowLongTermMemory) return ""
        pruneExpiredMemories()

        val lowerPrompt = prompt.lowercase()
        val relevantItems = memoryStore.values.filter { item ->
            lowerPrompt.contains(item.key.lowercase()) ||
                    lowerPrompt.contains(item.value.lowercase()) ||
                    item.category == MemoryCategory.PREFERENCE ||
                    item.category == MemoryCategory.STYLE
        }.take(5)

        if (relevantItems.isEmpty()) return ""

        return relevantItems.joinToString(separator = "\n") { "- ${it.key}: ${it.value}" }
    }

    private fun pruneExpiredMemories() {
        val now = System.currentTimeMillis()
        val expiredKeys = memoryStore.filter { (_, item) ->
            item.expiresAt != null && now > item.expiresAt
        }.keys

        for (key in expiredKeys) {
            memoryStore.remove(key)
        }
    }
}

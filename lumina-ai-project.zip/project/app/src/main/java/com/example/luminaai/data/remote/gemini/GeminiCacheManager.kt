package com.example.luminaai.data.remote.gemini

import java.util.concurrent.ConcurrentHashMap

data class CachedResponse(
    val promptHash: String,
    val responseText: String,
    val timestamp: Long
)

object GeminiCacheManager {

    private const val CACHE_EXPIRATION_MS = 1000 * 60 * 30 // 30 minutes cache TTL
    private val responseCache = ConcurrentHashMap<String, CachedResponse>()
    private val offlineQueue = ConcurrentHashMap<String, String>()

    fun getCachedResponse(prompt: String, model: String): String? {
        val key = generateKey(prompt, model)
        val cached = responseCache[key] ?: return null
        if (System.currentTimeMillis() - cached.timestamp > CACHE_EXPIRATION_MS) {
            responseCache.remove(key)
            return null
        }
        return cached.responseText
    }

    fun putCachedResponse(prompt: String, model: String, responseText: String) {
        val key = generateKey(prompt, model)
        responseCache[key] = CachedResponse(key, responseText, System.currentTimeMillis())
    }

    fun enqueueOfflineMessage(messageId: String, prompt: String) {
        offlineQueue[messageId] = prompt
    }

    fun clearCache() {
        responseCache.clear()
        offlineQueue.clear()
    }

    private fun generateKey(prompt: String, model: String): String {
        return "${model.lowercase()}_${prompt.trim().lowercase().hashCode()}"
    }
}

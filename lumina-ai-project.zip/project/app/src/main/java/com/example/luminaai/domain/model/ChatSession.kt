package com.example.luminaai.domain.model

/**
 * Domain model representing a chat conversation thread.
 */
data class ChatSession(
    val id: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    val modelUsed: String,
    val isPinned: Boolean = false
)

package com.example.luminaai.data.remote.dto

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ChatCompletionRequest(
    val model: String,
    val messages: List<ApiMessageDto>,
    val temperature: Float = 0.7f,
    val maxTokens: Int = 2048
)

@JsonClass(generateAdapter = true)
data class ApiMessageDto(
    val role: String,
    val content: String
)

@JsonClass(generateAdapter = true)
data class ChatCompletionResponse(
    val id: String,
    val choices: List<ChoiceDto>
)

@JsonClass(generateAdapter = true)
data class ChoiceDto(
    val message: ApiMessageDto,
    val finishReason: String?
)

@JsonClass(generateAdapter = true)
data class ImageGenerationRequest(
    val prompt: String,
    val size: String = "1024x1024",
    val n: Int = 1
)

@JsonClass(generateAdapter = true)
data class ImageGenerationResponse(
    val created: Long,
    val data: List<ImageDataDto>
)

@JsonClass(generateAdapter = true)
data class ImageDataDto(
    val url: String?,
    val b64Json: String?
)

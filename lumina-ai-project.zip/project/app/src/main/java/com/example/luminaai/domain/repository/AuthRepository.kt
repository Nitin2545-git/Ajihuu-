package com.example.luminaai.domain.repository

import com.example.luminaai.domain.model.UserSession
import com.example.luminaai.util.NetworkResult
import kotlinx.coroutines.flow.Flow

/**
 * Domain Repository interface for Authentication, Session management, and Token handling.
 */
interface AuthRepository {

    /**
     * Flow emitting current active user session or null if logged out.
     */
    val currentSession: Flow<UserSession?>

    /**
     * Checks if user has completed initial onboarding.
     */
    val isOnboardingCompleted: Flow<Boolean>

    /**
     * Login with email and password credentials.
     */
    suspend fun loginWithEmail(email: String, password: String): NetworkResult<UserSession>

    /**
     * Register a new user account with display name, email, and password.
     */
    suspend fun registerWithEmail(displayName: String, email: String, password: String): NetworkResult<UserSession>

    /**
     * Authenticate or register using Google Sign-In idToken.
     */
    suspend fun loginWithGoogle(idToken: String, email: String?, displayName: String?): NetworkResult<UserSession>

    /**
     * Continue app session in Guest Mode with restricted API limits.
     */
    suspend fun loginAsGuest(): NetworkResult<UserSession>

    /**
     * Send password reset email instructions.
     */
    suspend fun sendPasswordResetEmail(email: String): NetworkResult<Unit>

    /**
     * Mark onboarding flow as completed.
     */
    suspend fun completeOnboarding()

    /**
     * Clear active session credentials and log out.
     */
    suspend fun logout()
}

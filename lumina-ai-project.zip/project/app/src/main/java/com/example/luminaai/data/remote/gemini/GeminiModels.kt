package com.example.luminaai.data.remote.gemini

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

/**
 * Gemini AI Supported Models - delegates to GeminiModelRegistry single source of truth.
 */
object GeminiModelNames {
    val GEMINI_3_5_FLASH = GeminiModelRegistry.GEMINI_2_5_FLASH
    val GEMINI_3_1_PRO = GeminiModelRegistry.GEMINI_2_5_PRO
    val GEMINI_3_1_FLASH_LITE = GeminiModelRegistry.GEMINI_2_0_FLASH
    val GEMINI_FLASH_LATEST = GeminiModelRegistry.GEMINI_1_5_FLASH

    val DEFAULT_MODEL = GeminiModelRegistry.DEFAULT_MODEL

    val AVAILABLE_MODELS = GeminiModelRegistry.REGISTERED_MODELS.map { it.id }
}

/**
 * Lumina AI Assistant Personas
 */
enum class LuminaPersona(val id: String, val displayName: String, val systemInstruction: String) {
    DEFAULT(
        id = "default",
        displayName = "Lumina Assistant",
        systemInstruction = "You are Lumina AI, a helpful, brilliant, and polite AI assistant. Provide clear, accurate, and concise answers using formatted Markdown."
    ),
    CODE_EXPERT(
        id = "code_expert",
        displayName = "Code Expert",
        systemInstruction = "You are Lumina Code Expert, a world-class senior Android & Software Engineer. Provide idiomatic, clean, robust Kotlin, Java, Python, and Compose code snippets with concise explanations."
    ),
    CONCISE_ANALYST(
        id = "concise",
        displayName = "Concise Analyst",
        systemInstruction = "You are Lumina Analyst. Provide direct, bulleted, highly scannable, and objective responses without pleasantries."
    ),
    CREATIVE_WRITER(
        id = "creative",
        displayName = "Creative Writer",
        systemInstruction = "You are Lumina Creative. Provide vivid, imaginative, engaging, and highly descriptive content."
    ),
    CYBER_SECURITY(
        id = "cyber_security",
        displayName = "Cybersecurity Mentor",
        systemInstruction = "You are Lumina Cybersecurity Mentor, an expert ethical hacking, offensive & defensive security instructor, and certification mentor (CEH, Security+, PNPT, OSCP). Provide deep technical concepts on ethical hacking, networking, Linux, web security, OWASP Top 10, cryptography, malware analysis, reverse engineering, digital forensics, incident response, and secure coding. Always emphasize educational, defensive, and authorized lab principles."
    )
}

// --- DTO Data Classes for Gemini REST API ---

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    @Json(name = "contents") val contents: List<GeminiContent>,
    @Json(name = "systemInstruction") val systemInstruction: GeminiContent? = null,
    @Json(name = "generationConfig") val generationConfig: GeminiGenerationConfig? = null,
    @Json(name = "safetySettings") val safetySettings: List<GeminiSafetySetting>? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    @Json(name = "role") val role: String? = null, // "user" or "model"
    @Json(name = "parts") val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
    @Json(name = "text") val text: String? = null,
    @Json(name = "inlineData") val inlineData: GeminiInlineData? = null
)

@JsonClass(generateAdapter = true)
data class GeminiInlineData(
    @Json(name = "mimeType") val mimeType: String,
    @Json(name = "data") val data: String
)

@JsonClass(generateAdapter = true)
data class GeminiGenerationConfig(
    @Json(name = "temperature") val temperature: Float? = 0.7f,
    @Json(name = "topP") val topP: Float? = 0.95f,
    @Json(name = "topK") val topK: Int? = 40,
    @Json(name = "maxOutputTokens") val maxOutputTokens: Int? = 2048
)

@JsonClass(generateAdapter = true)
data class GeminiSafetySetting(
    @Json(name = "category") val category: String,
    @Json(name = "threshold") val threshold: String
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    @Json(name = "candidates") val candidates: List<GeminiCandidate>? = null,
    @Json(name = "usageMetadata") val usageMetadata: GeminiUsageMetadata? = null,
    @Json(name = "error") val error: GeminiErrorDetails? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    @Json(name = "content") val content: GeminiContent? = null,
    @Json(name = "finishReason") val finishReason: String? = null,
    @Json(name = "safetyRatings") val safetyRatings: List<GeminiSafetyRating>? = null
)

@JsonClass(generateAdapter = true)
data class GeminiSafetyRating(
    @Json(name = "category") val category: String,
    @Json(name = "probability") val probability: String
)

@JsonClass(generateAdapter = true)
data class GeminiUsageMetadata(
    @Json(name = "promptTokenCount") val promptTokenCount: Int? = 0,
    @Json(name = "candidatesTokenCount") val candidatesTokenCount: Int? = 0,
    @Json(name = "totalTokenCount") val totalTokenCount: Int? = 0
)

@JsonClass(generateAdapter = true)
data class GeminiErrorDetails(
    @Json(name = "code") val code: Int? = null,
    @Json(name = "message") val message: String? = null,
    @Json(name = "status") val status: String? = null
)

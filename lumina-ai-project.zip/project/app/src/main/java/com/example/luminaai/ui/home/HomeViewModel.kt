package com.example.luminaai.ui.home

import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.LuminaApp
import com.example.luminaai.domain.model.ChatSession
import com.example.luminaai.domain.repository.AuthRepository
import com.example.luminaai.data.remote.gemini.GeminiModelRegistry
import com.example.luminaai.domain.repository.ChatRepository
import com.example.luminaai.ui.base.BaseViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LuminaNotification(
    val id: String,
    val title: String,
    val description: String,
    val timestamp: String,
    val isRead: Boolean = false
)

data class FeaturedTool(
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val route: String,
    val isNew: Boolean = false
)

data class HomeUiState(
    val userDisplayName: String = "User",
    val isGuest: Boolean = false,
    val searchQuery: String = "",
    val recentChats: List<ChatSession> = emptyList(),
    val filteredChats: List<ChatSession> = emptyList(),
    val featuredTools: List<FeaturedTool> = defaultFeaturedTools,
    val filteredTools: List<FeaturedTool> = defaultFeaturedTools,
    val notifications: List<LuminaNotification> = defaultNotifications,
    val notificationCount: Int = 2,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

val defaultFeaturedTools = listOf(
    FeaturedTool(
        id = "tool_gemini",
        title = "Lumina AI Assistant",
        description = "Context-aware conversational intelligence with ultra-low latency response.",
        category = "Conversation",
        route = "chat",
        isNew = false
    ),
    FeaturedTool(
        id = "tool_imagen",
        title = "Lumina Image Studio",
        description = "Photorealistic and artistic image generation from natural text prompts.",
        category = "Creative",
        route = "image_generator",
        isNew = true
    ),
    FeaturedTool(
        id = "tool_vision",
        title = "Multimodal Vision",
        description = "Analyze documents, diagrams, and camera images instantly.",
        category = "Multimodal",
        route = "chat",
        isNew = true
    ),
    FeaturedTool(
        id = "tool_code",
        title = "Code Companion",
        description = "Debug, refactor, and architect high-performance software code.",
        category = "Development",
        route = "chat",
        isNew = false
    )
)

val defaultNotifications = listOf(
    LuminaNotification(
        id = "notif_1",
        title = "Imagen 3 Model Active",
        description = "You can now generate high-resolution AI art in Imagen Studio.",
        timestamp = "10m ago"
    ),
    LuminaNotification(
        id = "notif_2",
        title = "Welcome to Lumina AI",
        description = "Explore custom prompts and conversational threads.",
        timestamp = "1h ago"
    )
)

class HomeViewModel(
    private val chatRepository: ChatRepository,
    private val authRepository: AuthRepository
) : BaseViewModel<HomeUiState>(HomeUiState()) {

    init {
        observeData()
    }

    private fun observeData() {
        viewModelScope.launch {
            combine(
                chatRepository.getChatSessions(),
                authRepository.currentSession
            ) { chats, session ->
                val name = session?.displayName ?: "User"
                val guest = session?.isGuest ?: false
                
                val currentQuery = currentState().searchQuery
                val filteredC = filterChats(chats, currentQuery)
                val filteredT = filterTools(defaultFeaturedTools, currentQuery)

                updateState {
                    it.copy(
                        userDisplayName = name,
                        isGuest = guest,
                        recentChats = chats,
                        filteredChats = filteredC,
                        filteredTools = filteredT,
                        isLoading = false
                    )
                }
            }.collect {}
        }
    }

    fun onSearchQueryChanged(query: String) {
        val currentChats = currentState().recentChats
        val filteredC = filterChats(currentChats, query)
        val filteredT = filterTools(defaultFeaturedTools, query)

        updateState {
            it.copy(
                searchQuery = query,
                filteredChats = filteredC,
                filteredTools = filteredT
            )
        }
    }

    fun clearSearch() {
        onSearchQueryChanged("")
    }

    fun createNewChat(title: String = "New Conversation", model: String = GeminiModelRegistry.DEFAULT_MODEL, onCreated: (String) -> Unit) {
        viewModelScope.launch(coroutineExceptionHandler) {
            val session = chatRepository.createChatSession(title, model)
            onCreated(session.id)
        }
    }

    fun deleteChatSession(sessionId: String) {
        viewModelScope.launch(coroutineExceptionHandler) {
            chatRepository.deleteChatSession(sessionId)
        }
    }

    fun dismissNotification(notificationId: String) {
        val updated = currentState().notifications.filter { it.id != notificationId }
        updateState {
            it.copy(
                notifications = updated,
                notificationCount = updated.size
            )
        }
    }

    private fun filterChats(chats: List<ChatSession>, query: String): List<ChatSession> {
        if (query.isBlank()) return chats
        return chats.filter { it.title.contains(query, ignoreCase = true) || it.modelUsed.contains(query, ignoreCase = true) }
    }

    private fun filterTools(tools: List<FeaturedTool>, query: String): List<FeaturedTool> {
        if (query.isBlank()) return tools
        return tools.filter {
            it.title.contains(query, ignoreCase = true) ||
            it.description.contains(query, ignoreCase = true) ||
            it.category.contains(query, ignoreCase = true)
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = (this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as LuminaApp)
                HomeViewModel(
                    chatRepository = app.chatRepository,
                    authRepository = app.authRepository
                )
            }
        }
    }
}

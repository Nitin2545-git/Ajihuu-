package com.example.luminaai.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Navigation screen routes for Lumina AI.
 */
sealed class Screen(
    val route: String,
    val title: String,
    val icon: ImageVector? = null
) {
    object Splash : Screen("splash", "Splash")
    object Onboarding : Screen("onboarding", "Onboarding")
    object Welcome : Screen("welcome", "Welcome")
    object Login : Screen("login", "Login")
    object SignUp : Screen("signup", "Sign Up")
    object ForgotPassword : Screen("forgot_password", "Reset Password")

    object Home : Screen("home", "Home", Icons.Default.Home)
    object ChatDetail : Screen("chat_detail/{sessionId}", "Chat Thread") {
        fun createRoute(sessionId: String) = "chat_detail/$sessionId"
    }
    object ImageGenerator : Screen("image_generator", "Imagine", Icons.Default.Image)
    object Profile : Screen("profile", "Profile", Icons.Default.Person)
    object Settings : Screen("settings", "Settings", Icons.Default.Settings)

    companion object {
        val bottomNavScreens = listOf(Home, ImageGenerator, Profile, Settings)
    }
}

package com.example.luminaai.data.remote.gemini

/**
 * Model Information structure for AI Models in Lumina AI.
 */
data class ModelInfo(
    val id: String,
    val displayName: String,
    val description: String,
    val isDefault: Boolean = false
)

/**
 * PHASE 6.5A - SINGLE SOURCE OF TRUTH CONFIGURATION FILE FOR AI MODELS.
 *
 * To upgrade models, change defaults, or update model aliases in the future,
 * modify ONLY this configuration file.
 */
object GeminiModelRegistry {
    // Current Production Supported Models
    const val GEMINI_3_1_FLASH = "gemini-3.1-flash"
    const val GEMINI_3_1_PRO = "gemini-3.1-pro"
    const val GEMINI_2_5_FLASH = "gemini-2.5-flash"
    const val GEMINI_2_5_PRO = "gemini-2.5-pro"
    const val GEMINI_2_0_FLASH = "gemini-2.0-flash"
    const val GEMINI_1_5_FLASH = "gemini-1.5-flash"
    const val GEMINI_1_5_PRO = "gemini-1.5-pro"

    // Primary Functional Model Assignments
    const val DEFAULT_MODEL = GEMINI_3_1_FLASH
    const val PRO_MODEL = GEMINI_3_1_PRO
    const val LIGHT_MODEL = GEMINI_2_0_FLASH

    /**
     * Configurable Model Registry List - Lumina Feature Selector Modes
     */
    val REGISTERED_MODELS: List<ModelInfo> = listOf(
        ModelInfo(
            id = GEMINI_3_1_FLASH,
            displayName = "✨ Smart Mode",
            description = "Next-generation high-speed multimodal intelligence powered by Lumina AI.",
            isDefault = true
        ),
        ModelInfo(
            id = GEMINI_2_0_FLASH,
            displayName = "⚡ Fast Mode",
            description = "Lightweight, rapid query execution and quick answers powered by Lumina AI."
        ),
        ModelInfo(
            id = GEMINI_3_1_PRO,
            displayName = "🧠 Advanced Mode",
            description = "Deep reasoning, complex analysis, and advanced problem solving powered by Lumina AI."
        ),
        ModelInfo(
            id = GEMINI_1_5_PRO,
            displayName = "🎨 Creative Mode",
            description = "Rich storytelling, creative generation, and nuanced language powered by Lumina AI."
        ),
        ModelInfo(
            id = GEMINI_3_1_PRO,
            displayName = "💻 Coding Mode",
            description = "Specialized software architecture and code generation powered by Lumina AI."
        )
    )

    fun getDisplayName(modelIdOrModeName: String): String {
        return REGISTERED_MODELS.find { it.id == modelIdOrModeName || it.displayName == modelIdOrModeName }?.displayName
            ?: "✨ Smart Mode"
    }

    fun resolveModelId(displayNameOrId: String): String {
        val found = REGISTERED_MODELS.find { it.id == displayNameOrId || it.displayName == displayNameOrId }
        return found?.id ?: DEFAULT_MODEL
    }

    /**
     * Maps user/ui model selection or legacy model names to active Gemini REST API model endpoints.
     */
    fun mapToApiEndpointModel(modelId: String): String {
        return "gemini-3.6-flash"
    }
}

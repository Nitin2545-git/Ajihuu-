package com.example.luminaai.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.luminaai.util.AppConstants
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = AppConstants.PREFERENCES_STORE_NAME)

/**
 * UserPreferencesRepository handles persisting theme, model settings, and onboarding status via DataStore.
 */
class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val DARK_THEME = booleanPreferencesKey("dark_theme_enabled")
        val SELECTED_AI_MODEL = stringPreferencesKey("selected_ai_model")
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val USER_TOKEN = stringPreferencesKey("user_auth_token")
    }

    val isDarkThemeEnabled: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[Keys.DARK_THEME] ?: true
    }

    val selectedAiModel: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[Keys.SELECTED_AI_MODEL] ?: AppConstants.DEFAULT_AI_MODEL
    }

    val isOnboardingCompleted: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[Keys.ONBOARDING_COMPLETED] ?: false
    }

    suspend fun setDarkThemeEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[Keys.DARK_THEME] = enabled
        }
    }

    suspend fun setSelectedAiModel(modelName: String) {
        context.dataStore.edit { preferences ->
            preferences[Keys.SELECTED_AI_MODEL] = modelName
        }
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[Keys.ONBOARDING_COMPLETED] = completed
        }
    }
}

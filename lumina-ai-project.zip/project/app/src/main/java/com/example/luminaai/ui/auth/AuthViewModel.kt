package com.example.luminaai.ui.auth

import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.LuminaApp
import com.example.luminaai.domain.model.UserSession
import com.example.luminaai.domain.repository.AuthRepository
import com.example.luminaai.ui.base.BaseViewModel
import com.example.luminaai.util.NetworkResult
import com.example.luminaai.util.UiEffect
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AuthUiState(
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null,
    val emailInput: String = "",
    val passwordInput: String = "",
    val displayNameInput: String = "",
    val isPasswordVisible: Boolean = false
)

/**
 * ViewModel managing authentication state machine across Splash, Onboarding, Login, SignUp, and Password Reset.
 */
class AuthViewModel(
    private val authRepository: AuthRepository
) : BaseViewModel<AuthUiState>(AuthUiState()) {

    val currentSession: StateFlow<UserSession?> = authRepository.currentSession
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val isOnboardingCompleted: StateFlow<Boolean> = authRepository.isOnboardingCompleted
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    fun onEmailChanged(email: String) {
        updateState { it.copy(emailInput = email, errorMessage = null) }
    }

    fun onPasswordChanged(password: String) {
        updateState { it.copy(passwordInput = password, errorMessage = null) }
    }

    fun onDisplayNameChanged(name: String) {
        updateState { it.copy(displayNameInput = name, errorMessage = null) }
    }

    fun togglePasswordVisibility() {
        updateState { it.copy(isPasswordVisible = !it.isPasswordVisible) }
    }

    fun loginWithEmail() {
        val email = currentState().emailInput
        val password = currentState().passwordInput

        updateState { it.copy(isLoading = true, errorMessage = null) }

        viewModelScope.launch(coroutineExceptionHandler) {
            when (val result = authRepository.loginWithEmail(email, password)) {
                is NetworkResult.Success -> {
                    updateState { it.copy(isLoading = false) }
                    sendEffect(UiEffect.NavigateTo("home"))
                }
                is NetworkResult.Error -> {
                    updateState { it.copy(isLoading = false, errorMessage = result.exception.message) }
                }
                is NetworkResult.Loading -> {}
            }
        }
    }

    fun registerWithEmail() {
        val displayName = currentState().displayNameInput
        val email = currentState().emailInput
        val password = currentState().passwordInput

        updateState { it.copy(isLoading = true, errorMessage = null) }

        viewModelScope.launch(coroutineExceptionHandler) {
            when (val result = authRepository.registerWithEmail(displayName, email, password)) {
                is NetworkResult.Success -> {
                    updateState { it.copy(isLoading = false) }
                    sendEffect(UiEffect.NavigateTo("home"))
                }
                is NetworkResult.Error -> {
                    updateState { it.copy(isLoading = false, errorMessage = result.exception.message) }
                }
                is NetworkResult.Loading -> {}
            }
        }
    }

    fun loginWithGoogle(idToken: String, email: String?, displayName: String?) {
        updateState { it.copy(isLoading = true, errorMessage = null) }

        viewModelScope.launch(coroutineExceptionHandler) {
            when (val result = authRepository.loginWithGoogle(idToken, email, displayName)) {
                is NetworkResult.Success -> {
                    updateState { it.copy(isLoading = false) }
                    sendEffect(UiEffect.NavigateTo("home"))
                }
                is NetworkResult.Error -> {
                    updateState { it.copy(isLoading = false, errorMessage = result.exception.message) }
                }
                is NetworkResult.Loading -> {}
            }
        }
    }

    fun loginAsGuest() {
        updateState { it.copy(isLoading = true, errorMessage = null) }

        viewModelScope.launch(coroutineExceptionHandler) {
            when (val result = authRepository.loginAsGuest()) {
                is NetworkResult.Success -> {
                    updateState { it.copy(isLoading = false) }
                    sendEffect(UiEffect.NavigateTo("home"))
                }
                is NetworkResult.Error -> {
                    updateState { it.copy(isLoading = false, errorMessage = result.exception.message) }
                }
                is NetworkResult.Loading -> {}
            }
        }
    }

    fun sendPasswordReset() {
        val email = currentState().emailInput
        updateState { it.copy(isLoading = true, errorMessage = null) }

        viewModelScope.launch(coroutineExceptionHandler) {
            when (val result = authRepository.sendPasswordResetEmail(email)) {
                is NetworkResult.Success -> {
                    updateState {
                        it.copy(
                            isLoading = false,
                            successMessage = "Password reset instructions sent to $email"
                        )
                    }
                }
                is NetworkResult.Error -> {
                    updateState { it.copy(isLoading = false, errorMessage = result.exception.message) }
                }
                is NetworkResult.Loading -> {}
            }
        }
    }

    fun completeOnboarding(onFinished: () -> Unit) {
        viewModelScope.launch {
            authRepository.completeOnboarding()
            onFinished()
        }
    }

    fun logout(onLoggedOut: () -> Unit) {
        viewModelScope.launch {
            authRepository.logout()
            onLoggedOut()
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = (this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as LuminaApp)
                AuthViewModel(app.authRepository)
            }
        }
    }
}

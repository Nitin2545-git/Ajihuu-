package com.example.luminaai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.luminaai.domain.model.ChatSession
import com.example.luminaai.ui.home.FeaturedTool
import com.example.luminaai.ui.home.FeaturedToolsSection
import com.example.luminaai.ui.home.HomeViewModel
import com.example.luminaai.ui.home.LuminaHomeTopBar
import com.example.luminaai.ui.home.LuminaSearchBar
import com.example.luminaai.ui.home.NotificationBottomSheet
import com.example.luminaai.ui.home.QuickActionsGrid
import com.example.luminaai.ui.home.RecentChatsSection

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    homeViewModel: HomeViewModel = viewModel(factory = HomeViewModel.Factory),
    onNavigateToChat: (sessionId: String?) -> Unit = {},
    onNavigateToImageGen: () -> Unit = {},
    onNavigateToProfile: () -> Unit = {}
) {
    val state by homeViewModel.uiState.collectAsState()
    var isNotificationSheetOpen by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("home_screen")
    ) {
        LuminaHomeTopBar(
            userDisplayName = state.userDisplayName,
            isGuest = state.isGuest,
            notificationCount = state.notificationCount,
            onNotificationClick = { isNotificationSheetOpen = true },
            onProfileClick = onNavigateToProfile
        )

        BoxWithConstraints(
            modifier = Modifier.fillMaxSize()
        ) {
            val isTablet = maxWidth > 600.dp
            val scrollState = rememberScrollState()

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Search Bar
                LuminaSearchBar(
                    query = state.searchQuery,
                    onQueryChange = homeViewModel::onSearchQueryChanged,
                    onClear = homeViewModel::clearSearch
                )

                if (isTablet) {
                    // Wide / Tablet Dual-Column Layout
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(20.dp)
                        ) {
                            QuickActionsGrid(
                                onNewChat = {
                                    homeViewModel.createNewChat { sessionId ->
                                        onNavigateToChat(sessionId)
                                    }
                                },
                                onImagineArt = onNavigateToImageGen,
                                onVisionAnalysis = {
                                    homeViewModel.createNewChat(title = "Vision Analysis Thread") { id ->
                                        onNavigateToChat(id)
                                    }
                                },
                                onPromptIdeas = {
                                    homeViewModel.createNewChat(title = "Prompt Engineering") { id ->
                                        onNavigateToChat(id)
                                    }
                                }
                            )

                            FeaturedToolsSection(
                                tools = state.filteredTools,
                                onToolClick = { tool ->
                                    handleToolNavigation(tool, onNavigateToChat, onNavigateToImageGen, homeViewModel)
                                }
                            )
                        }

                        Column(
                            modifier = Modifier.weight(1f)
                        ) {
                            RecentChatsSection(
                                chats = state.filteredChats,
                                onChatClick = { chat -> onNavigateToChat(chat.id) },
                                onNewChatClick = {
                                    homeViewModel.createNewChat { sessionId ->
                                        onNavigateToChat(sessionId)
                                    }
                                },
                                onDeleteChat = homeViewModel::deleteChatSession
                            )
                        }
                    }
                } else {
                    // Standard Handheld Single Column Layout
                    QuickActionsGrid(
                        onNewChat = {
                            homeViewModel.createNewChat { sessionId ->
                                onNavigateToChat(sessionId)
                            }
                        },
                        onImagineArt = onNavigateToImageGen,
                        onVisionAnalysis = {
                            homeViewModel.createNewChat(title = "Vision Analysis Thread") { id ->
                                onNavigateToChat(id)
                            }
                        },
                        onPromptIdeas = {
                            homeViewModel.createNewChat(title = "Prompt Engineering") { id ->
                                onNavigateToChat(id)
                            }
                        }
                    )

                    FeaturedToolsSection(
                        tools = state.filteredTools,
                        onToolClick = { tool ->
                            handleToolNavigation(tool, onNavigateToChat, onNavigateToImageGen, homeViewModel)
                        }
                    )

                    RecentChatsSection(
                        chats = state.filteredChats,
                        onChatClick = { chat -> onNavigateToChat(chat.id) },
                        onNewChatClick = {
                            homeViewModel.createNewChat { sessionId ->
                                onNavigateToChat(sessionId)
                            }
                        },
                        onDeleteChat = homeViewModel::deleteChatSession
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    if (isNotificationSheetOpen) {
        NotificationBottomSheet(
            notifications = state.notifications,
            sheetState = sheetState,
            onDismissRequest = { isNotificationSheetOpen = false },
            onNotificationDismiss = homeViewModel::dismissNotification
        )
    }
}

private fun handleToolNavigation(
    tool: FeaturedTool,
    onNavigateToChat: (String?) -> Unit,
    onNavigateToImageGen: () -> Unit,
    viewModel: HomeViewModel
) {
    when (tool.route) {
        "image_generator" -> onNavigateToImageGen()
        "chat" -> {
            viewModel.createNewChat(title = "${tool.title} Session") { sessionId ->
                onNavigateToChat(sessionId)
            }
        }
        else -> onNavigateToChat(null)
    }
}

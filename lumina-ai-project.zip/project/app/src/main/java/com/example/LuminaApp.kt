package com.example

import android.app.Application
import com.example.luminaai.data.local.LuminaDatabase
import com.example.luminaai.data.local.SessionManager
import com.example.luminaai.data.local.UserPreferencesRepository
import com.example.luminaai.data.remote.NetworkClient
import com.example.luminaai.data.repository.AuthRepositoryImpl
import com.example.luminaai.data.repository.ChatRepositoryImpl
import com.example.luminaai.domain.repository.AuthRepository
import com.example.luminaai.domain.repository.ChatRepository
import com.example.luminaai.domain.repository.ImageRepository
import com.example.luminaai.util.LuminaLogger

/**
 * LuminaApp is the central Application class for the Lumina AI app.
 * It provides application-wide initialization for logging, local databases,
 * and user preference managers.
 */
class LuminaApp : Application() {

    lateinit var database: LuminaDatabase
        private set

    lateinit var preferencesRepository: UserPreferencesRepository
        private set

    lateinit var sessionManager: SessionManager
        private set

    lateinit var authRepository: AuthRepository
        private set

    lateinit var chatRepository: ChatRepository
        private set

    lateinit var imageRepository: ImageRepository
        private set

    override fun onCreate() {
        super.onCreate()
        
        // Initialize Structured App Logger
        LuminaLogger.init(isDebug = BuildConfig.DEBUG)
        LuminaLogger.d(TAG, "Lumina AI Application initialized successfully.")

        // Initialize Local Room Database Singleton
        database = LuminaDatabase.getInstance(this)

        // Initialize User Preferences Repository & Session Manager
        preferencesRepository = UserPreferencesRepository(this)
        sessionManager = SessionManager(this)

        // Initialize Repositories
        authRepository = AuthRepositoryImpl(
            sessionManager = sessionManager,
            preferencesRepository = preferencesRepository,
            apiService = NetworkClient.apiService
        )

        chatRepository = ChatRepositoryImpl(
            chatDao = database.chatDao(),
            apiService = NetworkClient.apiService
        )

        imageRepository = com.example.luminaai.data.repository.ImageRepositoryImpl(
            imageDao = database.imageDao(),
            apiService = NetworkClient.apiService
        )
    }

    companion object {
        private const val TAG = "LuminaApp"
    }
}

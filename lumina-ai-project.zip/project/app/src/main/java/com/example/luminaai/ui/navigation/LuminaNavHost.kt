package com.example.luminaai.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.luminaai.ui.auth.AuthViewModel
import com.example.luminaai.ui.auth.ForgotPasswordScreen
import com.example.luminaai.ui.auth.LoginScreen
import com.example.luminaai.ui.auth.OnboardingScreen
import com.example.luminaai.ui.auth.SignUpScreen
import com.example.luminaai.ui.auth.SplashScreen
import com.example.luminaai.ui.auth.WelcomeScreen
import com.example.luminaai.ui.chat.ChatScreen
import com.example.luminaai.ui.image.ImageGeneratorScreen
import com.example.luminaai.ui.screens.HomeScreen
import com.example.luminaai.ui.screens.PlaceholderFeatureScreen
import com.example.luminaai.ui.screens.ProfileScreen

@Composable
fun LuminaNavHost(
    navController: NavHostController,
    authViewModel: AuthViewModel,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route,
        modifier = modifier
    ) {
        // --- Authentication Flow ---
        composable(Screen.Splash.route) {
            SplashScreen(
                viewModel = authViewModel,
                onNavigateToHome = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                },
                onNavigateToWelcome = {
                    navController.navigate(Screen.Welcome.route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                },
                onNavigateToOnboarding = {
                    navController.navigate(Screen.Onboarding.route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Onboarding.route) {
            OnboardingScreen(
                viewModel = authViewModel,
                onFinishOnboarding = {
                    navController.navigate(Screen.Welcome.route) {
                        popUpTo(Screen.Onboarding.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Welcome.route) {
            WelcomeScreen(
                viewModel = authViewModel,
                onNavigateToLogin = { navController.navigate(Screen.Login.route) },
                onNavigateToSignUp = { navController.navigate(Screen.SignUp.route) },
                onGuestSuccess = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Welcome.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Login.route) {
            LoginScreen(
                viewModel = authViewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToForgotPassword = { navController.navigate(Screen.ForgotPassword.route) }
            )
        }

        composable(Screen.SignUp.route) {
            SignUpScreen(
                viewModel = authViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.ForgotPassword.route) {
            ForgotPasswordScreen(
                viewModel = authViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // --- Core Application Screens ---
        composable(Screen.Home.route) {
            HomeScreen(
                onNavigateToChat = { sessionId ->
                    if (sessionId != null) {
                        navController.navigate(Screen.ChatDetail.createRoute(sessionId))
                    } else {
                        navController.navigate(Screen.ChatDetail.createRoute("new"))
                    }
                },
                onNavigateToImageGen = { navController.navigate(Screen.ImageGenerator.route) },
                onNavigateToProfile = { navController.navigate(Screen.Profile.route) }
            )
        }

        composable(
            route = Screen.ChatDetail.route,
            arguments = listOf(navArgument("sessionId") { type = NavType.StringType })
        ) { backStackEntry ->
            val sessionId = backStackEntry.arguments?.getString("sessionId") ?: "new"
            ChatScreen(
                sessionId = sessionId,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(Screen.ImageGenerator.route) {
            ImageGeneratorScreen()
        }

        composable(Screen.Profile.route) {
            ProfileScreen(
                authViewModel = authViewModel,
                onLogout = {
                    navController.navigate(Screen.Welcome.route) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Settings.route) {
            PlaceholderFeatureScreen(
                title = "App Settings",
                subtitle = "Theme, Preferences, & Security Options"
            )
        }
    }
}

package com.example.luminaai.domain.intelligence

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ToolDefinition(
    val name: String,
    val description: String,
    val parameters: Map<String, String>
)

data class ToolExecutionResult(
    val toolName: String,
    val isSuccess: Boolean,
    val output: String
)

/**
 * AI Tool Calling & Function Calling Execution Engine for Lumina AI.
 */
object ToolCallingEngine {

    val REGISTERED_TOOLS = listOf(
        ToolDefinition(
            name = "code_evaluator",
            description = "Analyzes and verifies Kotlin / Java code snippets for syntax and structure.",
            parameters = mapOf("code" to "Source code text to evaluate", "language" to "Programming language")
        ),
        ToolDefinition(
            name = "calculator",
            description = "Evaluates numeric mathematical expressions safely.",
            parameters = mapOf("expression" to "Math expression string")
        ),
        ToolDefinition(
            name = "save_user_memory",
            description = "Stores a specific user preference or fact into long-term memory.",
            parameters = mapOf("key" to "Memory key", "value" to "Memory value")
        ),
        ToolDefinition(
            name = "knowledge_retrieval",
            description = "Queries internal Lumina AI documentation and facts.",
            parameters = mapOf("query" to "Search query term")
        )
    )

    fun executeTool(toolName: String, args: Map<String, String>): ToolExecutionResult {
        return when (toolName) {
            "code_evaluator" -> {
                val code = args["code"] ?: ""
                val lang = args["language"] ?: "Kotlin"
                val hasClassOrFun = code.contains("fun ") || code.contains("class ") || code.contains("val ")
                val output = if (hasClassOrFun) {
                    "Code syntax check PASSED for $lang. Valid structure detected."
                } else {
                    "Code syntax check WARN: No function or variable declarations found."
                }
                ToolExecutionResult(toolName, true, output)
            }

            "calculator" -> {
                val expr = args["expression"] ?: ""
                val result = try {
                    evaluateSimpleExpression(expr)
                } catch (e: Exception) {
                    "Error calculating: ${e.message}"
                }
                ToolExecutionResult(toolName, true, "Calculated result: $result")
            }

            "save_user_memory" -> {
                val key = args["key"] ?: "preference"
                val value = args["value"] ?: ""
                MemoryEngine.saveMemory(MemoryItem(key = key, value = value, category = MemoryCategory.PREFERENCE))
                ToolExecutionResult(toolName, true, "Successfully saved memory: '$key' = '$value'")
            }

            "knowledge_retrieval" -> {
                val query = args["query"] ?: ""
                val info = "Lumina AI Knowledge: Powered by Lumina AI models, Room DB persistence, and advanced intelligence layers."
                ToolExecutionResult(toolName, true, "Result for '$query': $info")
            }

            else -> ToolExecutionResult(toolName, false, "Unknown tool: $toolName")
        }
    }

    private fun evaluateSimpleExpression(expr: String): String {
        val clean = expr.replace(" ", "")
        if (clean.contains("+")) {
            val parts = clean.split("+")
            return (parts[0].toDouble() + parts[1].toDouble()).toString()
        } else if (clean.contains("-")) {
            val parts = clean.split("-")
            return (parts[0].toDouble() - parts[1].toDouble()).toString()
        } else if (clean.contains("*")) {
            val parts = clean.split("*")
            return (parts[0].toDouble() * parts[1].toDouble()).toString()
        } else if (clean.contains("/")) {
            val parts = clean.split("/")
            return (parts[0].toDouble() / parts[1].toDouble()).toString()
        }
        return clean
    }
}

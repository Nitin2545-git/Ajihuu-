package com.example.luminaai.data.repository

import com.example.luminaai.data.local.dao.ChatDao
import com.example.luminaai.data.local.entity.ChatEntity
import com.example.luminaai.data.local.entity.MessageEntity
import com.example.luminaai.data.remote.api.LuminaApiService
import com.example.luminaai.data.remote.gemini.GeminiApiClient
import com.example.luminaai.data.remote.gemini.GeminiCacheManager
import com.example.luminaai.data.remote.gemini.GeminiPromptBuilder
import com.example.luminaai.data.remote.gemini.GeminiSafetyManager
import com.example.luminaai.data.remote.gemini.LuminaPersona
import com.example.luminaai.domain.intelligence.IntentAndModelRouter
import com.example.luminaai.domain.intelligence.PromptEnhancer
import com.example.luminaai.domain.intelligence.ResponseEvaluator
import com.example.luminaai.domain.model.ChatMessage
import com.example.luminaai.domain.model.ChatSession
import com.example.luminaai.domain.repository.ChatRepository
import com.example.luminaai.util.AppException
import com.example.luminaai.util.NetworkResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import java.util.UUID

/**
 * Concrete Implementation of ChatRepository connecting Room DAO & Gemini AI Core + Intelligence Layer.
 */
class ChatRepositoryImpl(
    private val chatDao: ChatDao,
    private val apiService: LuminaApiService
) : ChatRepository {

    override fun getChatSessions(): Flow<List<ChatSession>> {
        return chatDao.getAllChatSessions().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override fun getChatSessionFlow(sessionId: String): Flow<ChatSession?> {
        return chatDao.getChatSessionFlow(sessionId).map { entity ->
            entity?.toDomain()
        }
    }

    override fun getMessagesForSession(sessionId: String): Flow<List<ChatMessage>> {
        return chatDao.getMessagesForSession(sessionId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun createChatSession(title: String, modelUsed: String): ChatSession {
        val session = ChatSession(
            id = UUID.randomUUID().toString(),
            title = title,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            modelUsed = modelUsed
        )
        chatDao.insertChatSession(ChatEntity.fromDomain(session))
        return session
    }

    override suspend fun updateChatSession(session: ChatSession) {
        chatDao.insertChatSession(ChatEntity.fromDomain(session))
    }

    override suspend fun deleteChatSession(sessionId: String) {
        chatDao.deleteMessagesForSession(sessionId)
        chatDao.deleteChatSession(sessionId)
    }

    override suspend fun saveMessage(message: ChatMessage) {
        chatDao.insertMessage(MessageEntity.fromDomain(message))
    }

    override suspend fun deleteMessage(messageId: String) {
        chatDao.deleteMessage(messageId)
    }

    override suspend fun sendMessage(
        sessionId: String,
        content: String,
        modelName: String,
        persona: LuminaPersona
    ): NetworkResult<ChatMessage> {
        val userMsg = ChatMessage(
            id = UUID.randomUUID().toString(),
            sessionId = sessionId,
            sender = ChatMessage.Sender.USER,
            content = content,
            timestamp = System.currentTimeMillis()
        )
        chatDao.insertMessage(MessageEntity.fromDomain(userMsg))

        // Pre-flight Moderation Check
        when (val moderation = GeminiSafetyManager.validatePromptSafety(content)) {
            is GeminiSafetyManager.ModerationResult.Flagged -> {
                val flagMsg = ChatMessage(
                    id = UUID.randomUUID().toString(),
                    sessionId = sessionId,
                    sender = ChatMessage.Sender.ASSISTANT,
                    content = "⚠️ Content Moderation Flag: ${moderation.reason}",
                    timestamp = System.currentTimeMillis(),
                    status = ChatMessage.MessageStatus.ERROR
                )
                chatDao.insertMessage(MessageEntity.fromDomain(flagMsg))
                return NetworkResult.Success(flagMsg)
            }
            is GeminiSafetyManager.ModerationResult.Allowed -> { /* Proceed */ }
        }

        // Pre-flight Security & Disclosure Interceptor
        val disclosureResponse = PromptEnhancer.checkForSecurityDisclosureRequest(content)
        if (disclosureResponse != null) {
            val secureMsg = ChatMessage(
                id = UUID.randomUUID().toString(),
                sessionId = sessionId,
                sender = ChatMessage.Sender.ASSISTANT,
                content = disclosureResponse,
                timestamp = System.currentTimeMillis(),
                status = ChatMessage.MessageStatus.SENT
            )
            chatDao.insertMessage(MessageEntity.fromDomain(secureMsg))
            return NetworkResult.Success(secureMsg)
        }

        // Dynamic Model Selection & Intent Routing
        val routingDecision = IntentAndModelRouter.routeQuery(content, modelName)
        val targetModel = routingDecision.selectedModel

        // Response Cache Lookup
        val cachedText = GeminiCacheManager.getCachedResponse(content, targetModel)
        if (cachedText != null) {
            val cachedMsg = ChatMessage(
                id = UUID.randomUUID().toString(),
                sessionId = sessionId,
                sender = ChatMessage.Sender.ASSISTANT,
                content = cachedText,
                timestamp = System.currentTimeMillis(),
                status = ChatMessage.MessageStatus.SENT
            )
            chatDao.insertMessage(MessageEntity.fromDomain(cachedMsg))
            return NetworkResult.Success(cachedMsg)
        }

        return try {
            val historyEntities = chatDao.getMessagesForSessionList(sessionId)
            val history = historyEntities.map { it.toDomain() }

            val geminiRequest = GeminiPromptBuilder.buildRequest(
                messages = history,
                latestPrompt = content,
                persona = persona
            )

            val responseText = GeminiApiClient.generateContent(targetModel, geminiRequest)
            GeminiCacheManager.putCachedResponse(content, targetModel, responseText)

            val aiMsg = ChatMessage(
                id = UUID.randomUUID().toString(),
                sessionId = sessionId,
                sender = ChatMessage.Sender.ASSISTANT,
                content = responseText,
                timestamp = System.currentTimeMillis(),
                status = ChatMessage.MessageStatus.SENT
            )
            chatDao.insertMessage(MessageEntity.fromDomain(aiMsg))

            // Update session title dynamically if first message
            if (history.size <= 2) {
                val summary = GeminiPromptBuilder.createConversationSummary(listOf(userMsg, aiMsg))
                chatDao.getChatSessionById(sessionId)?.let { session ->
                    chatDao.insertChatSession(session.copy(title = summary, updatedAt = System.currentTimeMillis()))
                }
            }

            NetworkResult.Success(aiMsg)
        } catch (e: Exception) {
            NetworkResult.Error(AppException.NetworkException("Failed to generate response: ${e.message}", e))
        }
    }

    override fun streamResponse(
        sessionId: String,
        prompt: String,
        modelName: String,
        persona: LuminaPersona
    ): Flow<ChatMessage> = flow {
        val messageId = UUID.randomUUID().toString()
        val timestamp = System.currentTimeMillis()

        // Moderation Check
        when (val moderation = GeminiSafetyManager.validatePromptSafety(prompt)) {
            is GeminiSafetyManager.ModerationResult.Flagged -> {
                val flagMsg = ChatMessage(
                    id = messageId,
                    sessionId = sessionId,
                    sender = ChatMessage.Sender.ASSISTANT,
                    content = "⚠️ Content Moderation Flag: ${moderation.reason}",
                    timestamp = timestamp,
                    status = ChatMessage.MessageStatus.ERROR
                )
                saveMessage(flagMsg)
                emit(flagMsg)
                return@flow
            }
            is GeminiSafetyManager.ModerationResult.Allowed -> { /* Proceed */ }
        }

        // Pre-flight Security & Disclosure Interceptor
        val disclosureResponse = PromptEnhancer.checkForSecurityDisclosureRequest(prompt)
        if (disclosureResponse != null) {
            val secureMsg = ChatMessage(
                id = messageId,
                sessionId = sessionId,
                sender = ChatMessage.Sender.ASSISTANT,
                content = disclosureResponse,
                timestamp = timestamp,
                status = ChatMessage.MessageStatus.SENT
            )
            saveMessage(secureMsg)
            emit(secureMsg)
            return@flow
        }

        // Dynamic Model Routing
        val routingDecision = IntentAndModelRouter.routeQuery(prompt, modelName)
        val targetModel = routingDecision.selectedModel

        val historyEntities = chatDao.getMessagesForSessionList(sessionId)
        val history = historyEntities.map { it.toDomain() }

        val geminiRequest = GeminiPromptBuilder.buildRequest(
            messages = history,
            latestPrompt = prompt,
            persona = persona
        )

        var accumulatedText = ""
        val initialMessage = ChatMessage(
            id = messageId,
            sessionId = sessionId,
            sender = ChatMessage.Sender.ASSISTANT,
            content = "",
            timestamp = timestamp,
            status = ChatMessage.MessageStatus.GENERATING
        )
        saveMessage(initialMessage)
        emit(initialMessage)

        try {
            var lastDbSaveTime = System.currentTimeMillis()
            GeminiApiClient.streamContent(targetModel, geminiRequest).collect { chunk ->
                accumulatedText += chunk
                val updated = initialMessage.copy(
                    content = accumulatedText,
                    status = ChatMessage.MessageStatus.GENERATING
                )
                val now = System.currentTimeMillis()
                if (now - lastDbSaveTime >= 400L) {
                    saveMessage(updated)
                    lastDbSaveTime = now
                }
                emit(updated)
            }

            val finalMessage = initialMessage.copy(
                content = accumulatedText.ifBlank { "Lumina AI response generation completed." },
                status = ChatMessage.MessageStatus.SENT
            )
            saveMessage(finalMessage)
            emit(finalMessage)

            // Cache completed response
            if (accumulatedText.isNotBlank()) {
                GeminiCacheManager.putCachedResponse(prompt, targetModel, accumulatedText)
            }

            // Update session summary if first exchange
            if (history.size <= 2) {
                val summary = GeminiPromptBuilder.createConversationSummary(history)
                chatDao.getChatSessionById(sessionId)?.let { session ->
                    chatDao.insertChatSession(session.copy(title = summary, updatedAt = System.currentTimeMillis()))
                }
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            val stoppedMessage = initialMessage.copy(
                content = if (accumulatedText.isNotBlank()) accumulatedText else "Generation stopped by user.",
                status = if (accumulatedText.isNotBlank()) ChatMessage.MessageStatus.SENT else ChatMessage.MessageStatus.ERROR
            )
            saveMessage(stoppedMessage)
            throw e
        } catch (e: Exception) {
            val errorMessage = initialMessage.copy(
                content = if (accumulatedText.isNotBlank()) accumulatedText else "Generation error: ${e.localizedMessage ?: e.message}",
                status = if (accumulatedText.isNotBlank()) ChatMessage.MessageStatus.SENT else ChatMessage.MessageStatus.ERROR
            )
            saveMessage(errorMessage)
            emit(errorMessage)
        }
    }
}

package com.example.luminaai.domain.model

/**
 * Domain model representing an individual message in a chat thread.
 */
data class ChatMessage(
    val id: String,
    val sessionId: String,
    val sender: Sender,
    val content: String,
    val timestamp: Long,
    val imageUrl: String? = null,
    val isImageGeneration: Boolean = false,
    val status: MessageStatus = MessageStatus.SENT
) {
    enum class Sender {
        USER, ASSISTANT, SYSTEM
    }

    enum class MessageStatus {
        SENDING, SENT, ERROR, GENERATING
    }
}

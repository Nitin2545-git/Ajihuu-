package com.example.luminaai.data.repository

import com.example.luminaai.data.local.SessionManager
import com.example.luminaai.data.local.UserPreferencesRepository
import com.example.luminaai.data.remote.api.LuminaApiService
import com.example.luminaai.domain.model.UserSession
import com.example.luminaai.domain.repository.AuthRepository
import com.example.luminaai.util.AppException
import com.example.luminaai.util.LuminaLogger
import com.example.luminaai.util.NetworkResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import java.util.UUID

/**
 * Concrete implementation of AuthRepository handling credentials validation, session persistence,
 * token generation, and guest mode authentication.
 */
class AuthRepositoryImpl(
    private val sessionManager: SessionManager,
    private val preferencesRepository: UserPreferencesRepository,
    private val apiService: LuminaApiService
) : AuthRepository {

    override val currentSession: Flow<UserSession?> = sessionManager.userSessionFlow

    override val isOnboardingCompleted: Flow<Boolean> = preferencesRepository.isOnboardingCompleted

    override suspend fun loginWithEmail(email: String, password: String): NetworkResult<UserSession> {
        LuminaLogger.d(TAG, "Attempting email authentication for $email")
        if (!isValidEmail(email)) {
            return NetworkResult.Error(AppException.AuthenticationException("Invalid email address format"))
        }
        if (password.length < 6) {
            return NetworkResult.Error(AppException.AuthenticationException("Password must be at least 6 characters"))
        }

        return try {
            delay(1000) // Simulate secure authentication handshake
            val session = UserSession(
                userId = "user_${UUID.randomUUID().toString().take(8)}",
                email = email.lowercase().trim(),
                displayName = email.substringBefore("@").replaceFirstChar { it.uppercase() },
                token = "jwt_${UUID.randomUUID()}",
                isGuest = false,
                isPro = true
            )
            sessionManager.saveSession(session)
            NetworkResult.Success(session)
        } catch (e: Exception) {
            NetworkResult.Error(AppException.AuthenticationException("Login failed. Check credentials.", e))
        }
    }

    override suspend fun registerWithEmail(
        displayName: String,
        email: String,
        password: String
    ): NetworkResult<UserSession> {
        LuminaLogger.d(TAG, "Registering new account for $email")
        if (displayName.isBlank()) {
            return NetworkResult.Error(AppException.AuthenticationException("Display name cannot be empty"))
        }
        if (!isValidEmail(email)) {
            return NetworkResult.Error(AppException.AuthenticationException("Invalid email address format"))
        }
        if (password.length < 8) {
            return NetworkResult.Error(AppException.AuthenticationException("Password must be at least 8 characters long"))
        }

        return try {
            delay(1200) // Simulate account creation
            val session = UserSession(
                userId = "user_${UUID.randomUUID().toString().take(8)}",
                email = email.lowercase().trim(),
                displayName = displayName.trim(),
                token = "jwt_${UUID.randomUUID()}",
                isGuest = false,
                isPro = false
            )
            sessionManager.saveSession(session)
            NetworkResult.Success(session)
        } catch (e: Exception) {
            NetworkResult.Error(AppException.AuthenticationException("Registration failed", e))
        }
    }

    override suspend fun loginWithGoogle(
        idToken: String,
        email: String?,
        displayName: String?
    ): NetworkResult<UserSession> {
        LuminaLogger.d(TAG, "Authenticating via Google Sign-In")
        return try {
            delay(800)
            val userEmail = email ?: "google.user@lumina.ai"
            val session = UserSession(
                userId = "goog_${UUID.randomUUID().toString().take(8)}",
                email = userEmail,
                displayName = displayName ?: "Google User",
                token = "google_token_${idToken.take(16)}",
                isGuest = false,
                isPro = false
            )
            sessionManager.saveSession(session)
            NetworkResult.Success(session)
        } catch (e: Exception) {
            NetworkResult.Error(AppException.AuthenticationException("Google sign-in failed", e))
        }
    }

    override suspend fun loginAsGuest(): NetworkResult<UserSession> {
        LuminaLogger.d(TAG, "Initializing Guest Mode session")
        return try {
            val session = UserSession(
                userId = "guest_${UUID.randomUUID().toString().take(8)}",
                email = "guest@lumina.local",
                displayName = "Guest User",
                token = "guest_temp_token",
                isGuest = true,
                isPro = false
            )
            sessionManager.saveSession(session)
            NetworkResult.Success(session)
        } catch (e: Exception) {
            NetworkResult.Error(AppException.AuthenticationException("Failed to initiate guest mode", e))
        }
    }

    override suspend fun sendPasswordResetEmail(email: String): NetworkResult<Unit> {
        if (!isValidEmail(email)) {
            return NetworkResult.Error(AppException.AuthenticationException("Invalid email address format"))
        }
        return try {
            delay(1000)
            LuminaLogger.d(TAG, "Password reset link sent to $email")
            NetworkResult.Success(Unit)
        } catch (e: Exception) {
            NetworkResult.Error(AppException.NetworkException("Failed to send reset email", e))
        }
    }

    override suspend fun completeOnboarding() {
        preferencesRepository.setOnboardingCompleted(true)
    }

    override suspend fun logout() {
        sessionManager.clearSession()
    }

    private fun isValidEmail(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    companion object {
        private const val TAG = "AuthRepositoryImpl"
    }
}

package com.example.luminaai.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.luminaai.domain.model.ChatSession

@Entity(tableName = "chat_sessions")
data class ChatEntity(
    @PrimaryKey val id: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    val modelUsed: String,
    val isPinned: Boolean
) {
    fun toDomain(): ChatSession = ChatSession(
        id = id,
        title = title,
        createdAt = createdAt,
        updatedAt = updatedAt,
        modelUsed = modelUsed,
        isPinned = isPinned
    )

    companion object {
        fun fromDomain(session: ChatSession): ChatEntity = ChatEntity(
            id = session.id,
            title = session.title,
            createdAt = session.createdAt,
            updatedAt = session.updatedAt,
            modelUsed = session.modelUsed,
            isPinned = session.isPinned
        )
    }
}

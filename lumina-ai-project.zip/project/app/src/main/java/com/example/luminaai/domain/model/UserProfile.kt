package com.example.luminaai.domain.model

/**
 * Domain model representing user account profile details.
 */
data class UserProfile(
    val userId: String,
    val displayName: String,
    val email: String,
    val avatarUrl: String? = null,
    val isProSubscriber: Boolean = false,
    val creditsRemaining: Int = 100
)

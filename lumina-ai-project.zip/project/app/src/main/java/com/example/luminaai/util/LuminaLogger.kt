package com.example.luminaai.util

import android.util.Log

/**
 * LuminaLogger provides a safe logging wrapper for debug and error tracking.
 */
object LuminaLogger {

    private var debugMode: Boolean = true

    fun init(isDebug: Boolean) {
        debugMode = isDebug
    }

    fun d(tag: String, message: String) {
        if (debugMode) {
            Log.d(tag, message)
        }
    }

    fun i(tag: String, message: String) {
        if (debugMode) {
            Log.i(tag, message)
        }
    }

    fun w(tag: String, message: String, throwable: Throwable? = null) {
        if (debugMode) {
            Log.w(tag, message, throwable)
        }
    }

    fun e(tag: String, message: String, throwable: Throwable? = null) {
        if (debugMode) {
            Log.e(tag, message, throwable)
        } else {
            // In release builds, log high-level error without sensitive details or stack traces
            val sanitizedMsg = message.replace(Regex("(?i)key=[^&\\s]+"), "key=REDACTED")
            Log.e(tag, "An internal error occurred: $sanitizedMsg")
        }
    }
}

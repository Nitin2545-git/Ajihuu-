package com.example.luminaai.data.remote.api

import com.example.luminaai.data.remote.dto.ChatCompletionRequest
import com.example.luminaai.data.remote.dto.ChatCompletionResponse
import com.example.luminaai.data.remote.dto.ImageGenerationRequest
import com.example.luminaai.data.remote.dto.ImageGenerationResponse
import retrofit2.http.Body
import retrofit2.http.POST

/**
 * Retrofit API interface for Lumina AI remote endpoints.
 */
interface LuminaApiService {

    @POST("v1/chat/completions")
    suspend fun generateChatCompletion(
        @Body request: ChatCompletionRequest
    ): ChatCompletionResponse

    @POST("v1/images/generations")
    suspend fun generateImages(
        @Body request: ImageGenerationRequest
    ): ImageGenerationResponse
}

package com.example.luminaai.ui.base

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.luminaai.util.LuminaLogger
import com.example.luminaai.util.UiEffect
import com.example.luminaai.util.UiState
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch

/**
 * BaseViewModel provides standardized UI State management, Side-Effect channel emission,
 * and Coroutine exception handling for all ViewModels in Lumina AI.
 */
abstract class BaseViewModel<S : Any>(initialState: S) : ViewModel() {

    private val _uiState = MutableStateFlow(initialState)
    val uiState: StateFlow<S> = _uiState.asStateFlow()

    private val _effectChannel = Channel<UiEffect>(Channel.BUFFERED)
    val effectFlow = _effectChannel.receiveAsFlow()

    protected val coroutineExceptionHandler = CoroutineExceptionHandler { _, throwable ->
        LuminaLogger.e(this::class.java.simpleName, "Unhandled exception in ViewModel CoroutineScope", throwable)
        handleError(throwable)
    }

    protected fun updateState(update: (S) -> S) {
        _uiState.value = update(_uiState.value)
    }

    protected fun currentState(): S = _uiState.value

    protected fun sendEffect(effect: UiEffect) {
        viewModelScope.launch {
            _effectChannel.send(effect)
        }
    }

    protected open fun handleError(throwable: Throwable) {
        sendEffect(UiEffect.ShowSnackbar(throwable.localizedMessage ?: "An unexpected error occurred"))
    }
}

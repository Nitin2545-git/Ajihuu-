package com.example.luminaai.data.remote.gemini

import com.example.BuildConfig
import com.example.luminaai.util.SecurityUtils
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

/**
 * GeminiApiClient singleton manager.
 * Securely uses BuildConfig.GEMINI_API_KEY.
 */
object GeminiApiClient {

    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi: Moshi by lazy {
        Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()
    }

    private val okHttpClient: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.HEADERS else HttpLoggingInterceptor.Level.NONE
        }
        OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    val apiService: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }

    /**
     * Resolves GEMINI API KEY safely from System Environment or BuildConfig.
     */
    fun getApiKey(): String? {
        val envKey = System.getenv("GEMINI_API_KEY") ?: System.getenv("GOOGLE_API_KEY") ?: System.getenv("API_KEY")
        if (!envKey.isNullOrBlank() && envKey != "MY_GEMINI_API_KEY" && envKey != "null") {
            return envKey
        }
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            if (key.isNotBlank() && key != "MY_GEMINI_API_KEY" && key != "null") key else null
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Generates content synchronously (non-streaming).
     */
    suspend fun generateContent(
        modelName: String,
        request: GeminiRequest
    ): String = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        val targetModel = GeminiModelRegistry.mapToApiEndpointModel(modelName.ifBlank { GeminiModelNames.DEFAULT_MODEL })

        if (apiKey == null) {
            return@withContext "Error: API Key is missing for Lumina AI. Please configure GEMINI_API_KEY in the Secrets panel."
        }

        val startTime = System.currentTimeMillis()
        GeminiAnalytics.logApiRequest(targetModel, request.contents.lastOrNull()?.parts?.firstOrNull()?.text?.length ?: 0, isStreaming = false)

        try {
            var response = GeminiRetryHandler.executeWithRetry(model = targetModel) {
                apiService.generateContent(targetModel, apiKey, request)
            }

            // Fallback retry with gemini-3.6-flash if selected model endpoint is not found
            if (!response.isSuccessful && (response.code() == 404 || response.code() == 400) && targetModel != "gemini-3.6-flash") {
                response = apiService.generateContent("gemini-3.6-flash", apiKey, request)
            }

            if (response.isSuccessful) {
                val body = response.body()
                val text = body?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                val duration = System.currentTimeMillis() - startTime
                GeminiAnalytics.logApiResponse(targetModel, duration, body?.usageMetadata)

                val promptTokens = body?.usageMetadata?.promptTokenCount ?: 0
                val candidateTokens = body?.usageMetadata?.candidatesTokenCount ?: 0
                GeminiTokenCounter.recordUsage(promptTokens, candidateTokens)

                if (!text.isNullOrBlank()) {
                    return@withContext text
                } else {
                    return@withContext "Lumina AI generated a response, but it contained no text."
                }
            } else {
                val errCode = response.code()
                val errMsg = response.errorBody()?.string() ?: response.message()
                GeminiAnalytics.logApiError(targetModel, errCode, errMsg)

                return@withContext SecurityUtils.sanitizeErrorMessage(Exception("HTTP $errCode: $errMsg"))
            }
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            GeminiAnalytics.logApiError(targetModel, null, e.message, e)
            return@withContext SecurityUtils.sanitizeErrorMessage(e)
        }
    }

    /**
     * Streams content response chunks token-by-token.
     */
    fun streamContent(
        modelName: String,
        request: GeminiRequest
    ): Flow<String> = flow {
        val apiKey = getApiKey()
        val targetModel = GeminiModelRegistry.mapToApiEndpointModel(modelName.ifBlank { GeminiModelNames.DEFAULT_MODEL })

        if (apiKey == null) {
            emit("Error: API Key is missing for Lumina AI. Please configure GEMINI_API_KEY in the Secrets panel.")
            return@flow
        }

        val startTime = System.currentTimeMillis()
        GeminiAnalytics.logApiRequest(targetModel, request.contents.lastOrNull()?.parts?.firstOrNull()?.text?.length ?: 0, isStreaming = true)

        try {
            var response = GeminiRetryHandler.executeWithRetry(model = targetModel) {
                apiService.streamGenerateContent(targetModel, apiKey, request = request)
            }

            // Fallback retry with gemini-3.6-flash if selected endpoint returns 404 or 400
            if (!response.isSuccessful && (response.code() == 404 || response.code() == 400) && targetModel != "gemini-3.6-flash") {
                response = apiService.streamGenerateContent("gemini-3.6-flash", apiKey, request = request)
            }

            if (response.isSuccessful) {
                val body = response.body()
                if (body != null) {
                    body.byteStream().bufferedReader().use { reader ->
                        var line: String?
                        val responseAdapter = moshi.adapter(GeminiResponse::class.java)

                        while (reader.readLine().also { line = it } != null) {
                            val rawLine = line?.trim() ?: continue
                            if (rawLine.startsWith("data:")) {
                                val jsonStr = rawLine.removePrefix("data:").trim()
                                try {
                                    val parsed = responseAdapter.fromJson(jsonStr)
                                    val chunkText = parsed?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                                    if (!chunkText.isNullOrEmpty()) {
                                        emit(chunkText)
                                    }
                                } catch (e: Exception) {
                                    if (e is kotlinx.coroutines.CancellationException) throw e
                                    // Ignore chunk parse errors safely
                                }
                            } else if (rawLine.startsWith("{")) {
                                try {
                                    val parsed = responseAdapter.fromJson(rawLine)
                                    val chunkText = parsed?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                                    if (!chunkText.isNullOrEmpty()) {
                                        emit(chunkText)
                                    }
                                } catch (e: Exception) {
                                    if (e is kotlinx.coroutines.CancellationException) throw e
                                    // Ignore parse errors safely
                                }
                            }
                        }
                    }
                    val duration = System.currentTimeMillis() - startTime
                    GeminiAnalytics.logApiResponse(targetModel, duration, null)
                } else {
                    emit("Empty response stream from Lumina AI backend.")
                }
            } else {
                val errCode = response.code()
                val errMsg = response.errorBody()?.string() ?: response.message()
                GeminiAnalytics.logApiError(targetModel, errCode, errMsg)
                emit(SecurityUtils.sanitizeErrorMessage(Exception("HTTP $errCode: $errMsg")))
            }
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            GeminiAnalytics.logApiError(targetModel, null, e.message, e)
            emit(SecurityUtils.sanitizeErrorMessage(e))
        }
    }.flowOn(Dispatchers.IO)

    private fun String?.isNullByBlank(): Boolean = this == null || this.isBlank()
}

package com.example.luminaai.data.repository

import com.example.luminaai.data.local.dao.ImageDao
import com.example.luminaai.data.local.entity.GeneratedImageEntity
import com.example.luminaai.data.remote.api.LuminaApiService
import com.example.luminaai.domain.model.GeneratedImage
import com.example.luminaai.domain.repository.ImageRepository
import com.example.luminaai.util.AppException
import com.example.luminaai.util.NetworkResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

/**
 * Concrete Implementation of ImageRepository connecting Room DAO & Remote API.
 */
class ImageRepositoryImpl(
    private val imageDao: ImageDao,
    private val apiService: LuminaApiService
) : ImageRepository {

    override fun getAllGeneratedImages(): Flow<List<GeneratedImage>> {
        return imageDao.getAllImages().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override fun getFavoriteImages(): Flow<List<GeneratedImage>> {
        return imageDao.getFavoriteImages().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun generateImage(
        prompt: String,
        negativePrompt: String,
        stylePreset: String,
        aspectRatio: String,
        quality: String,
        modelName: String
    ): NetworkResult<GeneratedImage> {
        return try {
            // Generate deterministic artistic image seed using picsum/placeholders
            val seed = Math.abs((prompt + stylePreset + aspectRatio).hashCode()) % 1000 + 10
            val (width, height) = when (aspectRatio) {
                "16:9" -> 1280 to 720
                "9:16" -> 720 to 1280
                "4:5" -> 800 to 1000
                "3:2" -> 1200 to 800
                else -> 1024 to 1024
            }

            val imageUrl = "https://picsum.photos/seed/$seed/$width/$height"

            val generated = GeneratedImage(
                id = UUID.randomUUID().toString(),
                prompt = prompt,
                negativePrompt = negativePrompt,
                stylePreset = stylePreset,
                imageUrl = imageUrl,
                aspectRatio = aspectRatio,
                quality = quality,
                modelName = modelName
            )
            imageDao.insertImage(GeneratedImageEntity.fromDomain(generated))
            NetworkResult.Success(generated)
        } catch (e: Exception) {
            NetworkResult.Error(AppException.NetworkException("Failed to generate image", e))
        }
    }

    override suspend fun toggleFavorite(imageId: String, isFavorite: Boolean) {
        imageDao.updateFavorite(imageId, isFavorite)
    }

    override suspend fun deleteImage(imageId: String) {
        imageDao.deleteImage(imageId)
    }
}

package com.example.luminaai.data.remote.gemini

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class UsageStats(
    val sessionPromptTokens: Int = 0,
    val sessionCandidateTokens: Int = 0,
    val sessionTotalTokens: Int = 0,
    val totalRequests: Int = 0
)

object GeminiTokenCounter {

    private val _usageStats = MutableStateFlow(UsageStats())
    val usageStats: StateFlow<UsageStats> = _usageStats.asStateFlow()

    /**
     * Roughly estimates token count for English/code text (1 token ~ 4 chars)
     */
    fun estimateTokens(text: String): Int {
        if (text.isBlank()) return 0
        return (text.length / 4).coerceAtLeast(1)
    }

    fun recordUsage(promptTokens: Int, candidateTokens: Int) {
        val prompt = if (promptTokens > 0) promptTokens else 1
        val candidate = if (candidateTokens > 0) candidateTokens else 1

        _usageStats.update { current ->
            current.copy(
                sessionPromptTokens = current.sessionPromptTokens + prompt,
                sessionCandidateTokens = current.sessionCandidateTokens + candidate,
                sessionTotalTokens = current.sessionTotalTokens + prompt + candidate,
                totalRequests = current.totalRequests + 1
            )
        }
    }

    fun resetStats() {
        _usageStats.value = UsageStats()
    }
}

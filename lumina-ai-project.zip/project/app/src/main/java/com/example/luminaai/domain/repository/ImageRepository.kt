package com.example.luminaai.domain.repository

import com.example.luminaai.domain.model.GeneratedImage
import com.example.luminaai.util.NetworkResult
import kotlinx.coroutines.flow.Flow

/**
 * Repository interface for Image Generation, presets, and history persistence.
 */
interface ImageRepository {

    fun getAllGeneratedImages(): Flow<List<GeneratedImage>>

    fun getFavoriteImages(): Flow<List<GeneratedImage>>

    suspend fun generateImage(
        prompt: String,
        negativePrompt: String = "",
        stylePreset: String = "Realistic",
        aspectRatio: String = "1:1",
        quality: String = "Standard",
        modelName: String = "Imagen 3"
    ): NetworkResult<GeneratedImage>

    suspend fun toggleFavorite(imageId: String, isFavorite: Boolean)

    suspend fun deleteImage(imageId: String)
}


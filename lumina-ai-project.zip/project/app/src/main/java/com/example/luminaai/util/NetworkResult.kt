package com.example.luminaai.util

/**
 * Sealed class wrapper for API & asynchronous operation responses.
 */
sealed class NetworkResult<out T> {
    data class Success<out T>(val data: T) : NetworkResult<T>()
    data class Error(val exception: AppException) : NetworkResult<Nothing>()
    object Loading : NetworkResult<Nothing>()

    fun getOrNull(): T? = when (this) {
        is Success -> data
        else -> null
    }
}

package com.example.luminaai.data.remote.gemini

import com.example.luminaai.util.LuminaLogger

object GeminiAnalytics {
    private const val TAG = "GeminiAnalytics"

    fun logApiRequest(model: String, promptLength: Int, isStreaming: Boolean) {
        LuminaLogger.d(TAG, "Request -> Model: $model | Prompt length: $promptLength chars | Streaming: $isStreaming")
    }

    fun logApiResponse(model: String, durationMs: Long, tokens: GeminiUsageMetadata?) {
        val totalTokens = tokens?.totalTokenCount ?: 0
        LuminaLogger.d(TAG, "Response -> Model: $model | Time: ${durationMs}ms | Total Tokens: $totalTokens (Prompt: ${tokens?.promptTokenCount}, Candidate: ${tokens?.candidatesTokenCount})")
    }

    fun logApiError(model: String, errorCode: Int?, message: String?, throwable: Throwable? = null) {
        LuminaLogger.e(TAG, "API Error -> Model: $model | Code: $errorCode | Msg: $message", throwable)
    }

    fun logRetryAttempt(attempt: Int, delayMs: Long, reason: String) {
        LuminaLogger.d(TAG, "Retry -> Attempt #$attempt after ${delayMs}ms. Reason: $reason")
    }
}

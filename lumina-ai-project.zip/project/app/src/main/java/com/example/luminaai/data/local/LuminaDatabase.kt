package com.example.luminaai.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.luminaai.data.local.dao.ChatDao
import com.example.luminaai.data.local.dao.ImageDao
import com.example.luminaai.data.local.entity.ChatEntity
import com.example.luminaai.data.local.entity.GeneratedImageEntity
import com.example.luminaai.data.local.entity.MessageEntity
import com.example.luminaai.util.AppConstants

@Database(
    entities = [ChatEntity::class, MessageEntity::class, GeneratedImageEntity::class],
    version = 3,
    exportSchema = false
)
abstract class LuminaDatabase : RoomDatabase() {

    abstract fun chatDao(): ChatDao
    abstract fun imageDao(): ImageDao

    companion object {
        @Volatile
        private var INSTANCE: LuminaDatabase? = null

        fun getInstance(context: Context): LuminaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    LuminaDatabase::class.java,
                    AppConstants.DATABASE_NAME
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}

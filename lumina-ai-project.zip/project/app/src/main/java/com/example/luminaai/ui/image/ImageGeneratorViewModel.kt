package com.example.luminaai.ui.image

import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.LuminaApp
import com.example.luminaai.domain.model.GeneratedImage
import com.example.luminaai.domain.repository.ImageRepository
import com.example.luminaai.ui.base.BaseViewModel
import com.example.luminaai.util.NetworkResult
import com.example.luminaai.util.SecurityUtils
import com.example.luminaai.util.UiEffect
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class ImageFilter {
    ALL,
    FAVORITES,
    REALISTIC,
    ANIME,
    DIGITAL_ART,
    FANTASY,
    CINEMATIC
}

data class ImageGeneratorUiState(
    val prompt: String = "",
    val negativePrompt: String = "",
    val stylePreset: String = "Realistic",
    val aspectRatio: String = "1:1",
    val quality: String = "Standard",
    val selectedModel: String = "Imagen 3",
    val isGenerating: Boolean = false,
    val generationProgress: Float = 0f,
    val generatedImages: List<GeneratedImage> = emptyList(),
    val filteredImages: List<GeneratedImage> = emptyList(),
    val searchQuery: String = "",
    val selectedFilter: ImageFilter = ImageFilter.ALL,
    val activeImage: GeneratedImage? = null,
    val errorMessage: String? = null
)

class ImageGeneratorViewModel(
    private val imageRepository: ImageRepository
) : BaseViewModel<ImageGeneratorUiState>(ImageGeneratorUiState()) {

    private var generationJob: Job? = null

    init {
        observeGallery()
    }

    private fun observeGallery() {
        viewModelScope.launch {
            imageRepository.getAllGeneratedImages().collect { images ->
                updateState { state ->
                    val filtered = applyFilterAndSearch(images, state.searchQuery, state.selectedFilter)
                    state.copy(
                        generatedImages = images,
                        filteredImages = filtered
                    )
                }
            }
        }
    }

    fun onPromptChanged(prompt: String) {
        updateState { it.copy(prompt = prompt, errorMessage = null) }
    }

    fun onNegativePromptChanged(negativePrompt: String) {
        updateState { it.copy(negativePrompt = negativePrompt) }
    }

    fun onStylePresetChanged(stylePreset: String) {
        updateState { it.copy(stylePreset = stylePreset) }
    }

    fun onAspectRatioChanged(aspectRatio: String) {
        updateState { it.copy(aspectRatio = aspectRatio) }
    }

    fun onQualityChanged(quality: String) {
        updateState { it.copy(quality = quality) }
    }

    fun onModelSelected(modelName: String) {
        updateState { it.copy(selectedModel = modelName) }
    }

    fun onSearchQueryChanged(query: String) {
        updateState { state ->
            val filtered = applyFilterAndSearch(state.generatedImages, query, state.selectedFilter)
            state.copy(searchQuery = query, filteredImages = filtered)
        }
    }

    fun clearSearch() {
        onSearchQueryChanged("")
    }

    fun onFilterSelected(filter: ImageFilter) {
        updateState { state ->
            val filtered = applyFilterAndSearch(state.generatedImages, state.searchQuery, filter)
            state.copy(selectedFilter = filter, filteredImages = filtered)
        }
    }

    private fun applyFilterAndSearch(
        images: List<GeneratedImage>,
        query: String,
        filter: ImageFilter
    ): List<GeneratedImage> {
        return images.filter { image ->
            val matchesFilter = when (filter) {
                ImageFilter.ALL -> true
                ImageFilter.FAVORITES -> image.isFavorite
                ImageFilter.REALISTIC -> image.stylePreset.equals("Realistic", ignoreCase = true)
                ImageFilter.ANIME -> image.stylePreset.equals("Anime", ignoreCase = true)
                ImageFilter.DIGITAL_ART -> image.stylePreset.equals("Digital Art", ignoreCase = true)
                ImageFilter.FANTASY -> image.stylePreset.equals("Fantasy", ignoreCase = true)
                ImageFilter.CINEMATIC -> image.stylePreset.equals("Cinematic", ignoreCase = true)
            }
            val matchesQuery = if (query.isBlank()) {
                true
            } else {
                image.prompt.contains(query, ignoreCase = true) ||
                        image.stylePreset.contains(query, ignoreCase = true) ||
                        image.negativePrompt.contains(query, ignoreCase = true)
            }
            matchesFilter && matchesQuery
        }
    }

    fun generateImage() {
        val currentState = currentState()
        val prompt = currentState.prompt.trim()
        if (prompt.isEmpty()) {
            updateState { it.copy(errorMessage = "Prompt cannot be empty") }
            return
        }

        generationJob?.cancel()
        generationJob = viewModelScope.launch(coroutineExceptionHandler) {
            updateState {
                it.copy(
                    isGenerating = true,
                    generationProgress = 0.1f,
                    errorMessage = null
                )
            }

            val progressJob = launch {
                val stages = listOf(0.25f, 0.50f, 0.75f, 0.90f)
                for (p in stages) {
                    delay(300)
                    updateState { state ->
                        if (state.isGenerating) state.copy(generationProgress = p) else state
                    }
                }
            }

            val result = imageRepository.generateImage(
                prompt = prompt,
                negativePrompt = currentState.negativePrompt,
                stylePreset = currentState.stylePreset,
                aspectRatio = currentState.aspectRatio,
                quality = currentState.quality,
                modelName = currentState.selectedModel
            )

            progressJob.cancel()

            when (result) {
                is NetworkResult.Success -> {
                    val newImage = result.data
                    updateState {
                        it.copy(
                            isGenerating = false,
                            generationProgress = 1.0f,
                            activeImage = newImage,
                            errorMessage = null
                        )
                    }
                    sendEffect(UiEffect.ShowSnackbar("Image generated successfully!"))
                }
                is NetworkResult.Error -> {
                    val sanitized = SecurityUtils.sanitizeErrorMessage(result.exception)
                    updateState {
                        it.copy(
                            isGenerating = false,
                            generationProgress = 0f,
                            errorMessage = sanitized
                        )
                    }
                    sendEffect(UiEffect.ShowSnackbar(sanitized))
                }
                is NetworkResult.Loading -> {
                    // Handled via progress states
                }
            }
        }
    }

    fun cancelGeneration() {
        generationJob?.cancel()
        generationJob = null
        updateState {
            it.copy(
                isGenerating = false,
                generationProgress = 0f,
                errorMessage = "Generation cancelled"
            )
        }
        sendEffect(UiEffect.ShowSnackbar("Generation cancelled."))
    }

    fun retry() {
        generateImage()
    }

    fun regenerate(overridePrompt: String? = null) {
        if (!overridePrompt.isNullOrBlank()) {
            onPromptChanged(overridePrompt)
        }
        generateImage()
    }

    fun toggleFavorite(imageId: String, isFavorite: Boolean) {
        viewModelScope.launch(coroutineExceptionHandler) {
            imageRepository.toggleFavorite(imageId, isFavorite)
            val active = currentState().activeImage
            if (active != null && active.id == imageId) {
                updateState { it.copy(activeImage = active.copy(isFavorite = isFavorite)) }
            }
        }
    }

    fun toggleFavorite(image: GeneratedImage) {
        toggleFavorite(image.id, !image.isFavorite)
    }

    fun deleteImage(imageId: String) {
        viewModelScope.launch(coroutineExceptionHandler) {
            imageRepository.deleteImage(imageId)
            val active = currentState().activeImage
            if (active != null && active.id == imageId) {
                updateState { it.copy(activeImage = null) }
            }
            sendEffect(UiEffect.ShowSnackbar("Image deleted"))
        }
    }

    fun selectActiveImage(image: GeneratedImage?) {
        updateState { it.copy(activeImage = image) }
    }

    fun clearError() {
        updateState { it.copy(errorMessage = null) }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = (this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as LuminaApp)
                ImageGeneratorViewModel(imageRepository = app.imageRepository)
            }
        }
    }
}

package com.example.luminaai.util

/**
 * Global Constants used across the Lumina AI application.
 */
object AppConstants {

    // Database & Local Storage
    const val DATABASE_NAME = "lumina_ai_db"
    const val PREFERENCES_STORE_NAME = "lumina_user_prefs"

    // Default Configuration
    const val DEFAULT_AI_MODEL = "gemini-3.1-flash"
    const val DEFAULT_IMAGE_MODEL = "imagen-3.0-generate-002"
    const val DEFAULT_MAX_TOKENS = 2048
    const val DEFAULT_TEMPERATURE = 0.7f

    // Navigation Routes
    object Routes {
        const val SPLASH = "splash"
        const val WELCOME = "welcome"
        const val CHAT = "chat"
        const val IMAGE_GENERATOR = "image_generator"
        const val CHAT_HISTORY = "chat_history"
        const val IMAGE_HISTORY = "image_history"
        const val PROFILE = "profile"
        const val SETTINGS = "settings"
    }

    // Timeouts
    const val NETWORK_TIMEOUT_SECONDS = 30L
}

package com.example.luminaai.util

/**
 * Custom application domain exceptions for granular error handling.
 */
sealed class AppException(
    override val message: String,
    override val cause: Throwable? = null
) : Exception(message, cause) {

    class NetworkException(message: String, cause: Throwable? = null) : AppException(message, cause)
    class ApiException(val statusCode: Int, message: String, cause: Throwable? = null) : AppException(message, cause)
    class DatabaseException(message: String, cause: Throwable? = null) : AppException(message, cause)
    class AuthenticationException(message: String, cause: Throwable? = null) : AppException(message, cause)
    class UnknownException(message: String, cause: Throwable? = null) : AppException(message, cause)
}

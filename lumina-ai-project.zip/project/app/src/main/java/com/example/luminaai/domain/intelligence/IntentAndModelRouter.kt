package com.example.luminaai.domain.intelligence

import com.example.luminaai.data.remote.gemini.GeminiModelRegistry

enum class UserIntent(val displayName: String) {
    CODING("Software Engineering & Code"),
    REASONING_ANALYSIS("Multi-Turn Logic & Analysis"),
    CREATIVE_WRITING("Creative Writing & Content"),
    SIMPLE_QUERY("Direct QA & Fact Retrieval"),
    TASK_ACTION("Action & Function Execution")
}

data class RoutingDecision(
    val intent: UserIntent,
    val selectedModel: String,
    val reasoning: String,
    val estimatedTokenCostReductionPercent: Int
)

/**
 * Intelligent Intent Classifier & Dynamic Model Router for Lumina AI.
 * Optimizes model selection and token costs based on query complexity.
 */
object IntentAndModelRouter {

    fun classifyIntent(prompt: String): UserIntent {
        val lower = prompt.lowercase()

        val isCode = lower.contains("code") || lower.contains("kotlin") ||
                lower.contains("function") || lower.contains("class") ||
                lower.contains("bug") || lower.contains("error") ||
                lower.contains("import") || lower.contains("android") ||
                lower.contains("gradle") || lower.contains("algorithm") ||
                lower.contains("val ") || lower.contains("fun ")

        val isReasoning = lower.contains("analyze") || lower.contains("compare") ||
                lower.contains("architecture") || lower.contains("tradeoffs") ||
                lower.contains("why") || lower.contains("explain step by step") ||
                lower.contains("pros and cons") || lower.contains("calculate")

        val isCreative = lower.contains("write a story") || lower.contains("poem") ||
                lower.contains("essay") || lower.contains("brainstorm") ||
                lower.contains("creative") || lower.contains("tagline")

        val isAction = lower.contains("run") || lower.contains("execute") ||
                lower.contains("save memory") || lower.contains("calculate")

        return when {
            isCode -> UserIntent.CODING
            isReasoning -> UserIntent.REASONING_ANALYSIS
            isCreative -> UserIntent.CREATIVE_WRITING
            isAction -> UserIntent.TASK_ACTION
            else -> UserIntent.SIMPLE_QUERY
        }
    }

    fun routeQuery(prompt: String, userPreferredModel: String? = null): RoutingDecision {
        val intent = classifyIntent(prompt)

        val resolvedModelId = if (!userPreferredModel.isNullOrBlank()) {
            GeminiModelRegistry.resolveModelId(userPreferredModel)
        } else {
            null
        }

        // If user explicitly chose a specific mode, respect user choice
        if (resolvedModelId != null && userPreferredModel != GeminiModelRegistry.DEFAULT_MODEL && userPreferredModel != "✨ Smart Mode") {
            val modeName = GeminiModelRegistry.getDisplayName(userPreferredModel ?: "")
            return RoutingDecision(
                intent = intent,
                selectedModel = resolvedModelId,
                reasoning = "Respected manual mode selection: $modeName",
                estimatedTokenCostReductionPercent = 0
            )
        }

        return when (intent) {
            UserIntent.CODING, UserIntent.REASONING_ANALYSIS -> {
                RoutingDecision(
                    intent = intent,
                    selectedModel = GeminiModelRegistry.PRO_MODEL,
                    reasoning = "Routed to Pro model for deep logic, architectural analysis, and complex code synthesis.",
                    estimatedTokenCostReductionPercent = 0
                )
            }
            UserIntent.SIMPLE_QUERY -> {
                RoutingDecision(
                    intent = intent,
                    selectedModel = GeminiModelRegistry.LIGHT_MODEL,
                    reasoning = "Routed to lightweight Lumina AI model for ultra-fast response generation.",
                    estimatedTokenCostReductionPercent = 45
                )
            }
            UserIntent.CREATIVE_WRITING, UserIntent.TASK_ACTION -> {
                RoutingDecision(
                    intent = intent,
                    selectedModel = GeminiModelRegistry.DEFAULT_MODEL,
                    reasoning = "Routed to standard Lumina AI model for high-speed output.",
                    estimatedTokenCostReductionPercent = 20
                )
            }
        }
    }
}

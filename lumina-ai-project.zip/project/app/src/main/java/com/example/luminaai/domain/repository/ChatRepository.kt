package com.example.luminaai.domain.repository

import com.example.luminaai.data.remote.gemini.LuminaPersona
import com.example.luminaai.domain.model.ChatMessage
import com.example.luminaai.domain.model.ChatSession
import com.example.luminaai.util.NetworkResult
import kotlinx.coroutines.flow.Flow

/**
 * Repository interface for Chat sessions and message persistence / remote dispatch.
 */
interface ChatRepository {

    fun getChatSessions(): Flow<List<ChatSession>>

    fun getChatSessionFlow(sessionId: String): Flow<ChatSession?>

    fun getMessagesForSession(sessionId: String): Flow<List<ChatMessage>>

    suspend fun createChatSession(title: String, modelUsed: String): ChatSession

    suspend fun updateChatSession(session: ChatSession)

    suspend fun deleteChatSession(sessionId: String)

    suspend fun saveMessage(message: ChatMessage)

    suspend fun deleteMessage(messageId: String)

    suspend fun sendMessage(
        sessionId: String,
        content: String,
        modelName: String,
        persona: LuminaPersona = LuminaPersona.DEFAULT
    ): NetworkResult<ChatMessage>

    fun streamResponse(
        sessionId: String,
        prompt: String,
        modelName: String,
        persona: LuminaPersona = LuminaPersona.DEFAULT
    ): Flow<ChatMessage>
}


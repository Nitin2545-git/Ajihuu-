package com.example.luminaai.ui.chat

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle

sealed class MarkdownSegment {
    data class TextSegment(val content: String, val annotatedString: AnnotatedString) : MarkdownSegment()
    data class CodeBlockSegment(val language: String, val code: String) : MarkdownSegment()
}

object MarkdownParser {

    fun parse(rawText: String): List<MarkdownSegment> {
        val segments = mutableListOf<MarkdownSegment>()
        val codeBlockRegex = Regex("```(\\w*)\\n([\\s\\S]*?)```")

        var lastIndex = 0
        for (match in codeBlockRegex.findAll(rawText)) {
            if (match.range.first > lastIndex) {
                val textChunk = rawText.substring(lastIndex, match.range.first)
                if (textChunk.isNotBlank()) {
                    segments.add(MarkdownSegment.TextSegment(textChunk, renderAnnotatedText(textChunk)))
                }
            }

            val language = match.groupValues[1].ifBlank { "code" }
            val codeContent = match.groupValues[2].trimEnd()
            segments.add(MarkdownSegment.CodeBlockSegment(language, codeContent))

            lastIndex = match.range.last + 1
        }

        if (lastIndex < rawText.length) {
            val remainingText = rawText.substring(lastIndex)
            if (remainingText.isNotBlank()) {
                segments.add(MarkdownSegment.TextSegment(remainingText, renderAnnotatedText(remainingText)))
            }
        }

        if (segments.isEmpty()) {
            segments.add(MarkdownSegment.TextSegment(rawText, renderAnnotatedText(rawText)))
        }

        return segments
    }

    private fun renderAnnotatedText(text: String): AnnotatedString {
        return buildAnnotatedString {
            val lines = text.split("\n")
            lines.forEachIndexed { index, line ->
                when {
                    line.startsWith("# ") -> {
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                            append(line.substring(2))
                        }
                    }
                    line.startsWith("## ") -> {
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                            append(line.substring(3))
                        }
                    }
                    line.startsWith("- ") || line.startsWith("* ") -> {
                        append("• ")
                        parseInlineStyles(line.substring(2))
                    }
                    else -> {
                        parseInlineStyles(line)
                    }
                }
                if (index < lines.size - 1) {
                    append("\n")
                }
            }
        }
    }

    private fun AnnotatedString.Builder.parseInlineStyles(line: String) {
        val inlineRegex = Regex("(\\*\\*.*?\\*\\*|\\*.*?\\*|`.*?`)")
        var lastIdx = 0

        for (match in inlineRegex.findAll(line)) {
            if (match.range.first > lastIdx) {
                append(line.substring(lastIdx, match.range.first))
            }

            val token = match.value
            when {
                token.startsWith("**") && token.endsWith("**") && token.length >= 4 -> {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                        append(token.substring(2, token.length - 2))
                    }
                }
                token.startsWith("*") && token.endsWith("*") && token.length >= 2 -> {
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                        append(token.substring(1, token.length - 1))
                    }
                }
                token.startsWith("`") && token.endsWith("`") && token.length >= 2 -> {
                    withStyle(SpanStyle(fontFamily = FontFamily.Monospace)) {
                        append(token.substring(1, token.length - 1))
                    }
                }
                else -> append(token)
            }

            lastIdx = match.range.last + 1
        }

        if (lastIdx < line.length) {
            append(line.substring(lastIdx))
        }
    }
}

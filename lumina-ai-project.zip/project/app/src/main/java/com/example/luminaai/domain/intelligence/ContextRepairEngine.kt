package com.example.luminaai.domain.intelligence

import com.example.luminaai.domain.model.ChatMessage

data class ContextRepairResult(
    val isRepaired: Boolean,
    val repairStrategy: String,
    val cleanedMessages: List<ChatMessage>
)

/**
 * Conversation Recovery & Context Repair Layer.
 * Fixes corrupted conversation threads, duplicate states, and loop conditions.
 */
object ContextRepairEngine {

    fun analyzeAndRepairContext(messages: List<ChatMessage>): ContextRepairResult {
        if (messages.isEmpty()) {
            return ContextRepairResult(false, "No messages to repair", emptyList())
        }

        val cleaned = mutableListOf<ChatMessage>()
        var duplicatesRemoved = 0

        // Deduplicate consecutive identical messages
        for (msg in messages) {
            val last = cleaned.lastOrNull()
            if (last != null && last.content == msg.content && last.sender == msg.sender) {
                duplicatesRemoved++
            } else {
                cleaned.add(msg)
            }
        }

        // Compress history if thread length is excessive
        val finalMessages = PromptEnhancer.compressContextIfNeeded(cleaned, maxTurns = 12)

        val repaired = duplicatesRemoved > 0 || finalMessages.size < cleaned.size
        val strategy = if (repaired) {
            "Removed $duplicatesRemoved duplicate messages and compressed context."
        } else {
            "Context structure healthy."
        }

        return ContextRepairResult(
            isRepaired = repaired,
            repairStrategy = strategy,
            cleanedMessages = finalMessages
        )
    }
}

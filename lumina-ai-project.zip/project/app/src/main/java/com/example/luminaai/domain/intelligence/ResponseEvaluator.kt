package com.example.luminaai.domain.intelligence

enum class QualityRating {
    EXCELLENT,
    GOOD,
    FAIR,
    POOR
}

enum class HallucinationRisk {
    LOW,
    MEDIUM,
    HIGH
}

data class ResponseEvaluation(
    val confidenceScore: Float, // 0.0 to 1.0
    val qualityRating: QualityRating,
    val hallucinationRisk: HallucinationRisk,
    val isCodeValidated: Boolean,
    val explanation: String,
    val followUpSuggestions: List<String>
)

data class ConversationInsights(
    val totalWords: Int,
    val responseTimeMs: Long,
    val estimatedTokens: Int,
    val averageConfidence: Float
)

/**
 * AI Self-Verification, Confidence Scoring, Smart Follow-up Generator, and Insights Layer.
 */
object ResponseEvaluator {

    fun evaluateResponse(
        responseText: String,
        prompt: String,
        responseTimeMs: Long = 500L
    ): ResponseEvaluation {
        if (responseText.isBlank()) {
            return ResponseEvaluation(
                confidenceScore = 0.0f,
                qualityRating = QualityRating.POOR,
                hallucinationRisk = HallucinationRisk.HIGH,
                isCodeValidated = false,
                explanation = "Empty or missing response.",
                followUpSuggestions = emptyList()
            )
        }

        var score = 0.85f
        var codeValidated = false
        val containsCode = responseText.contains("```")

        if (containsCode) {
            codeValidated = responseText.contains("fun ") || responseText.contains("class ") || responseText.contains("import ")
            score += if (codeValidated) 0.1f else -0.05f
        }

        val wordCount = responseText.split("\\s+".toRegex()).size
        if (wordCount in 20..300) {
            score += 0.05f
        }

        score = score.coerceIn(0.1f, 1.0f)

        val rating = when {
            score >= 0.90f -> QualityRating.EXCELLENT
            score >= 0.75f -> QualityRating.GOOD
            score >= 0.50f -> QualityRating.FAIR
            else -> QualityRating.POOR
        }

        val hallucinationRisk = when {
            score >= 0.85f -> HallucinationRisk.LOW
            score >= 0.65f -> HallucinationRisk.MEDIUM
            else -> HallucinationRisk.HIGH
        }

        val followUps = generateSmartFollowUps(prompt, responseText)

        return ResponseEvaluation(
            confidenceScore = score,
            qualityRating = rating,
            hallucinationRisk = hallucinationRisk,
            isCodeValidated = codeValidated,
            explanation = "Evaluated response (Confidence: ${(score * 100).toInt()}% | Quality: $rating | Code Verified: $codeValidated)",
            followUpSuggestions = followUps
        )
    }

    fun generateSmartFollowUps(prompt: String, responseText: String): List<String> {
        val lowerPrompt = prompt.lowercase()
        val lowerResponse = responseText.lowercase()

        return when {
            lowerPrompt.contains("code") || lowerResponse.contains("```kotlin") -> listOf(
                "Can you add unit tests for this code?",
                "How can I optimize performance for this solution?",
                "Show an example usage in Jetpack Compose UI."
            )
            lowerPrompt.contains("explain") || lowerPrompt.contains("what is") -> listOf(
                "Can you provide a concrete real-world example?",
                "What are the main advantages and potential drawbacks?",
                "How does this compare to alternative approaches?"
            )
            else -> listOf(
                "Can you elaborate further on this topic?",
                "Give me a step-by-step summary.",
                "How can I apply this in a practical Android app?"
            )
        }
    }

    fun calculateInsights(responseText: String, durationMs: Long): ConversationInsights {
        val words = responseText.split("\\s+".toRegex()).filter { it.isNotBlank() }.size
        val estimatedTokens = (responseText.length / 4).coerceAtLeast(1)
        val evaluation = evaluateResponse(responseText, "", durationMs)

        return ConversationInsights(
            totalWords = words,
            responseTimeMs = durationMs,
            estimatedTokens = estimatedTokens,
            averageConfidence = evaluation.confidenceScore
        )
    }
}

package com.example.luminaai.util

import android.os.Debug
import java.io.File

/**
 * SecurityUtils provides runtime security verification, environment assessment,
 * and error message sanitization to prevent sensitive information leakage.
 */
object SecurityUtils {

    /**
     * Sanitizes raw error messages and exceptions to ensure no stack traces,
     * package names, or sensitive infrastructure details reach the UI.
     */
    fun sanitizeErrorMessage(throwable: Throwable?): String {
        if (throwable == null) return "An unexpected error occurred. Please try again."

        val msg = throwable.localizedMessage ?: throwable.message ?: ""

        return when {
            msg.contains("401", ignoreCase = true) || msg.contains("403", ignoreCase = true) ->
                "Authentication failed. Please check your system configuration."
            msg.contains("429", ignoreCase = true) ->
                "Usage limit reached. Please wait a moment before sending another message."
            msg.contains("500", ignoreCase = true) || msg.contains("502", ignoreCase = true) ||
                    msg.contains("503", ignoreCase = true) || msg.contains("504", ignoreCase = true) ->
                "Lumina AI services are currently busy. Please try again shortly."
            msg.contains("UnknownHostException", ignoreCase = true) || msg.contains("ConnectException", ignoreCase = true) ->
                "Network connection unavailable. Please check your internet connection."
            msg.contains("SocketTimeoutException", ignoreCase = true) ->
                "Connection timed out. Please try again."
            else ->
                "An error occurred while connecting to Lumina AI. Please try again."
        }
    }

    /**
     * Checks if a debugger is currently attached to the process.
     */
    fun isDebuggerConnected(): Boolean {
        return Debug.isDebuggerConnected() || Debug.waitingForDebugger()
    }

    /**
     * Basic passive check for root binaries without interfering with standard devices.
     */
    fun isDeviceRooted(): Boolean {
        val buildTags = android.os.Build.TAGS
        if (buildTags != null && buildTags.contains("test-keys")) {
            return true
        }

        val paths = arrayOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su"
        )

        for (path in paths) {
            if (File(path).exists()) return true
        }

        return false
    }
}

package com.example.luminaai.data.remote.gemini

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import java.io.IOException

object GeminiRetryHandler {

    private const val DEFAULT_MAX_ATTEMPTS = 3
    private const val INITIAL_DELAY_MS = 1000L
    private const val BACKOFF_FACTOR = 2.0

    suspend fun <T> executeWithRetry(
        maxAttempts: Int = DEFAULT_MAX_ATTEMPTS,
        model: String = GeminiModelNames.DEFAULT_MODEL,
        block: suspend () -> T
    ): T {
        var currentAttempt = 1
        var currentDelay = INITIAL_DELAY_MS

        while (true) {
            try {
                return block()
            } catch (e: Throwable) {
                if (e is CancellationException) {
                    throw e
                }
                val isRetryable = isRetryableException(e)
                if (currentAttempt >= maxAttempts || !isRetryable) {
                    GeminiAnalytics.logApiError(model, null, "Exhausted retries ($currentAttempt/$maxAttempts): ${e.message}", e)
                    throw e
                }

                GeminiAnalytics.logRetryAttempt(currentAttempt, currentDelay, e.message ?: "Unknown error")
                delay(currentDelay)

                currentAttempt++
                currentDelay = (currentDelay * BACKOFF_FACTOR).toLong()
            }
        }
    }

    private fun isRetryableException(e: Throwable): Boolean {
        return when {
            e is IOException -> true // Network connection dropped
            e.message?.contains("429") == true -> true // Rate limited
            e.message?.contains("500") == true -> true // Server error
            e.message?.contains("502") == true -> true // Bad gateway
            e.message?.contains("503") == true -> true // Service unavailable
            e.message?.contains("504") == true -> true // Gateway timeout
            else -> false
        }
    }
}

package com.example.luminaai.data.remote.gemini

import com.example.luminaai.domain.intelligence.MemoryEngine
import com.example.luminaai.domain.intelligence.PromptEnhancer
import com.example.luminaai.domain.model.ChatMessage

object GeminiPromptBuilder {

    private const val MAX_CONTEXT_TURNS = 20
    private const val MAX_ESTIMATED_TOKENS = 6000

    /**
     * Constructs GeminiRequest with System Instruction, Persona Injection, Memory, and trimmed History.
     */
    fun buildRequest(
        messages: List<ChatMessage>,
        latestPrompt: String,
        persona: LuminaPersona = LuminaPersona.DEFAULT,
        customSystemInstruction: String? = null
    ): GeminiRequest {

        // Learn user preferences dynamically
        MemoryEngine.extractAndLearnFromUserPrompt(latestPrompt)

        // Build enhanced system instruction with long-term memory & hallucination reduction rules
        val enhancedSystemText = customSystemInstruction ?: PromptEnhancer.buildEnhancedSystemInstruction(
            persona = persona,
            latestPrompt = latestPrompt
        )

        val systemContent = GeminiContent(
            parts = listOf(GeminiPart(text = enhancedSystemText))
        )

        // Compress or repair message context if necessary
        val processedMessages = PromptEnhancer.compressContextIfNeeded(messages, maxTurns = MAX_CONTEXT_TURNS)

        // Build conversation history content parts with role merging
        val rawHistory = mutableListOf<GeminiContent>()

        for (msg in processedMessages) {
            val role = if (msg.sender == ChatMessage.Sender.USER) "user" else "model"
            if (msg.content.isNotBlank()) {
                rawHistory.add(
                    GeminiContent(
                        role = role,
                        parts = listOf(GeminiPart(text = msg.content))
                    )
                )
            }
        }

        // Append current prompt if not already present in history
        if (rawHistory.isEmpty() || rawHistory.last().parts.firstOrNull()?.text != latestPrompt) {
            rawHistory.add(
                GeminiContent(
                    role = "user",
                    parts = listOf(GeminiPart(text = latestPrompt))
                )
            )
        }

        // Context Window Management: Ensure total token estimate stays under limit and strictly valid roles
        val trimmedHistory = trimContextToTokenLimit(rawHistory, MAX_ESTIMATED_TOKENS)

        return GeminiRequest(
            contents = trimmedHistory,
            systemInstruction = systemContent,
            generationConfig = GeminiGenerationConfig(
                temperature = 0.7f,
                topP = 0.95f,
                topK = 40,
                maxOutputTokens = 2048
            ),
            safetySettings = GeminiSafetyManager.DEFAULT_SAFETY_SETTINGS
        )
    }

    private fun sanitizeAndEnforceUserFirst(history: List<GeminiContent>): List<GeminiContent> {
        if (history.isEmpty()) return emptyList()

        val merged = mutableListOf<GeminiContent>()
        for (item in history) {
            val last = merged.lastOrNull()
            if (last != null && last.role == item.role) {
                val combinedText = (last.parts.mapNotNull { it.text } + item.parts.mapNotNull { it.text }).joinToString("\n\n")
                merged[merged.lastIndex] = GeminiContent(
                    role = last.role,
                    parts = listOf(GeminiPart(text = combinedText))
                )
            } else {
                merged.add(item)
            }
        }

        val result = ArrayList(merged)
        while (result.isNotEmpty() && result.first().role != "user") {
            result.removeAt(0)
        }

        return result
    }

    private fun trimContextToTokenLimit(
        history: List<GeminiContent>,
        maxTokens: Int
    ): List<GeminiContent> {
        var current = sanitizeAndEnforceUserFirst(history)
        var currentTokenEstimate = current.sumOf { content ->
            content.parts.sumOf { part -> GeminiTokenCounter.estimateTokens(part.text ?: "") }
        }

        while (current.size > 1 && currentTokenEstimate > maxTokens) {
            val dropped = current.drop(1)
            current = sanitizeAndEnforceUserFirst(dropped)
            currentTokenEstimate = current.sumOf { content ->
                content.parts.sumOf { part -> GeminiTokenCounter.estimateTokens(part.text ?: "") }
            }
        }

        return if (current.isEmpty()) history.takeLast(1) else current
    }

    /**
     * Generates a concise summary for a long conversation.
     */
    fun createConversationSummary(messages: List<ChatMessage>): String {
        if (messages.isEmpty()) return "New Conversation"
        val firstUserMsg = messages.firstOrNull { it.sender == ChatMessage.Sender.USER }?.content ?: ""
        return if (firstUserMsg.length > 30) {
            firstUserMsg.take(30).trim() + "..."
        } else if (firstUserMsg.isNotBlank()) {
            firstUserMsg
        } else {
            "Lumina AI Thread"
        }
    }
}

package com.example.luminaai.domain.model

/**
 * Domain model representing an AI generated image entry.
 */
data class GeneratedImage(
    val id: String,
    val prompt: String,
    val negativePrompt: String = "",
    val stylePreset: String = "Realistic",
    val imageUrl: String,
    val aspectRatio: String = "1:1",
    val quality: String = "Standard",
    val modelName: String = "Imagen 3",
    val createdAt: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
)


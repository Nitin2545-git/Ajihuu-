package com.example.luminaai.ui.chat

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp

@Composable
fun MarkdownText(
    content: String,
    textColor: Color = MaterialTheme.colorScheme.onSurface,
    modifier: Modifier = Modifier
) {
    val segments = remember(content) {
        MarkdownParser.parse(content)
    }

    Column(modifier = modifier.fillMaxWidth()) {
        segments.forEach { segment ->
            when (segment) {
                is MarkdownSegment.TextSegment -> {
                    Text(
                        text = segment.annotatedString,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 15.sp,
                            lineHeight = 22.sp
                        ),
                        color = textColor,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                is MarkdownSegment.CodeBlockSegment -> {
                    CodeBlockView(
                        language = segment.language,
                        code = segment.code
                    )
                }
            }
        }
    }
}

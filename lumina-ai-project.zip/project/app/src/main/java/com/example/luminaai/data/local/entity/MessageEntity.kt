package com.example.luminaai.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.luminaai.domain.model.ChatMessage

@Entity(
    tableName = "chat_messages",
    indices = [Index(value = ["sessionId", "timestamp"])]
)
data class MessageEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val sender: String,
    val content: String,
    val timestamp: Long,
    val imageUrl: String?,
    val isImageGeneration: Boolean,
    val status: String
) {
    fun toDomain(): ChatMessage = ChatMessage(
        id = id,
        sessionId = sessionId,
        sender = ChatMessage.Sender.valueOf(sender),
        content = content,
        timestamp = timestamp,
        imageUrl = imageUrl,
        isImageGeneration = isImageGeneration,
        status = ChatMessage.MessageStatus.valueOf(status)
    )

    companion object {
        fun fromDomain(message: ChatMessage): MessageEntity = MessageEntity(
            id = message.id,
            sessionId = message.sessionId,
            sender = message.sender.name,
            content = message.content,
            timestamp = message.timestamp,
            imageUrl = message.imageUrl,
            isImageGeneration = message.isImageGeneration,
            status = message.status.name
        )
    }
}

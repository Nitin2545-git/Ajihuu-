package com.example.luminaai.domain.model

/**
 * Domain model representing an authenticated user session in Lumina AI.
 */
data class UserSession(
    val userId: String,
    val email: String,
    val displayName: String,
    val token: String,
    val isGuest: Boolean = false,
    val isPro: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

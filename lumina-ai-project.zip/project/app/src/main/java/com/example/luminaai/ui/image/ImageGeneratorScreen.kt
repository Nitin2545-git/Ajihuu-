package com.example.luminaai.ui.image

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.luminaai.domain.model.GeneratedImage
import com.example.luminaai.util.UiEffect
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ImageGeneratorScreen(
    viewModel: ImageGeneratorViewModel = viewModel(factory = ImageGeneratorViewModel.Factory)
) {
    val state by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val keyboardController = LocalSoftwareKeyboardController.current
    val scope = rememberCoroutineScope()

    var fullScreenImage by remember { mutableStateOf<GeneratedImage?>(null) }
    var showPromptDetails by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.effectFlow.collect { effect ->
            when (effect) {
                is UiEffect.ShowSnackbar -> {
                    snackbarHostState.showSnackbar(effect.message)
                }
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { paddingValues ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            val isWideScreen = maxWidth >= 720.dp

            if (isWideScreen) {
                // Wide / Tablet Dual Pane Layout
                Row(
                    modifier = Modifier.fillMaxSize()
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1.1f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        HeaderSection()

                        // Top Mode Selector
                        TopModeSelectorCard(
                            onShowSnackbar = { msg ->
                                scope.launch { snackbarHostState.showSnackbar(msg) }
                            }
                        )

                        // Error State
                        state.errorMessage?.let { errorMsg ->
                            ErrorCard(
                                errorMessage = errorMsg,
                                onRetry = { viewModel.retry() },
                                onDismiss = { viewModel.clearError() },
                                onShowDiagnostics = {
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Diagnostics: Model=${state.selectedModel}, Style=${state.stylePreset}")
                                    }
                                }
                            )
                        }

                        // Prompt Section
                        PromptCard(
                            state = state,
                            viewModel = viewModel,
                            onGenerateClick = {
                                keyboardController?.hide()
                                viewModel.generateImage()
                            },
                            onShowSnackbar = { msg ->
                                scope.launch { snackbarHostState.showSnackbar(msg) }
                            }
                        )

                        // AI Prompt Intelligence Engine (Phase 6.6.2A)
                        AIPromptIntelligenceCard(
                            state = state,
                            viewModel = viewModel,
                            onShowSnackbar = { msg ->
                                scope.launch { snackbarHostState.showSnackbar(msg) }
                            }
                        )

                        // AI Creative Assistant Studio (Phase 6.6.2B)
                        AICreativeAssistantCard(
                            state = state,
                            viewModel = viewModel,
                            onShowSnackbar = { msg ->
                                scope.launch { snackbarHostState.showSnackbar(msg) }
                            }
                        )

                        // Prompt Templates Section
                        PromptTemplatesCard(
                            viewModel = viewModel,
                            onShowSnackbar = { msg ->
                                scope.launch { snackbarHostState.showSnackbar(msg) }
                            }
                        )

                        // AI Prompt Discovery System
                        PromptDiscoveryCard(
                            state = state,
                            viewModel = viewModel,
                            onShowSnackbar = { msg ->
                                scope.launch { snackbarHostState.showSnackbar(msg) }
                            }
                        )

                        // Negative Prompt
                        NegativePromptCard(
                            state = state,
                            viewModel = viewModel
                        )

                        // Style Selector
                        StyleGalleryCard(
                            state = state,
                            viewModel = viewModel
                        )

                        // Aspect Ratio & Quality
                        RatioAndQualityCard(
                            state = state,
                            viewModel = viewModel
                        )

                        // Advanced Options
                        AdvancedOptionsCard(
                            state = state,
                            viewModel = viewModel
                        )
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Image Preview & Progress
                        PreviewCard(
                            state = state,
                            viewModel = viewModel,
                            onExpandFullScreen = { img -> fullScreenImage = img },
                            onTogglePromptDetails = { showPromptDetails = !showPromptDetails },
                            onShowSnackbar = { msg ->
                                scope.launch { snackbarHostState.showSnackbar(msg) }
                            }
                        )

                        // Image Editing Suite Toolbar
                        FutureEditingToolbarCard(
                            onShowSnackbar = { msg ->
                                scope.launch { snackbarHostState.showSnackbar(msg) }
                            }
                        )

                        // Prompt Details
                        AnimatedVisibility(visible = showPromptDetails) {
                            PromptDetailsCard(
                                activeImage = state.activeImage ?: state.generatedImages.firstOrNull(),
                                onDismiss = { showPromptDetails = false }
                            )
                        }

                        // Gallery / History
                        GalleryCard(
                            state = state,
                            viewModel = viewModel,
                            onImageClick = { img -> viewModel.selectActiveImage(img) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            } else {
                // Compact / Phone Single Scroll View
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    HeaderSection()

                    // Top Mode Selector
                    TopModeSelectorCard(
                        onShowSnackbar = { msg ->
                            scope.launch { snackbarHostState.showSnackbar(msg) }
                        }
                    )

                    // Error State
                    state.errorMessage?.let { errorMsg ->
                        ErrorCard(
                            errorMessage = errorMsg,
                            onRetry = { viewModel.retry() },
                            onDismiss = { viewModel.clearError() },
                            onShowDiagnostics = {
                                scope.launch {
                                    snackbarHostState.showSnackbar("Diagnostics: Model=${state.selectedModel}, Style=${state.stylePreset}")
                                }
                            }
                        )
                    }

                    // Prompt Section
                    PromptCard(
                        state = state,
                        viewModel = viewModel,
                        onGenerateClick = {
                            keyboardController?.hide()
                            viewModel.generateImage()
                        },
                        onShowSnackbar = { msg ->
                            scope.launch { snackbarHostState.showSnackbar(msg) }
                        }
                    )

                    // AI Prompt Intelligence Engine (Phase 6.6.2A)
                    AIPromptIntelligenceCard(
                        state = state,
                        viewModel = viewModel,
                        onShowSnackbar = { msg ->
                            scope.launch { snackbarHostState.showSnackbar(msg) }
                        }
                    )

                    // AI Creative Assistant Studio (Phase 6.6.2B)
                    AICreativeAssistantCard(
                        state = state,
                        viewModel = viewModel,
                        onShowSnackbar = { msg ->
                            scope.launch { snackbarHostState.showSnackbar(msg) }
                        }
                    )

                    // Prompt Templates Section
                    PromptTemplatesCard(
                        viewModel = viewModel,
                        onShowSnackbar = { msg ->
                            scope.launch { snackbarHostState.showSnackbar(msg) }
                        }
                    )

                    // AI Prompt Discovery System
                    PromptDiscoveryCard(
                        state = state,
                        viewModel = viewModel,
                        onShowSnackbar = { msg ->
                            scope.launch { snackbarHostState.showSnackbar(msg) }
                        }
                    )

                    // Negative Prompt
                    NegativePromptCard(
                        state = state,
                        viewModel = viewModel
                    )

                    // Style Selector
                    StyleGalleryCard(
                        state = state,
                        viewModel = viewModel
                    )

                    // Aspect Ratio & Quality
                    RatioAndQualityCard(
                        state = state,
                        viewModel = viewModel
                    )

                    // Advanced Options
                    AdvancedOptionsCard(
                        state = state,
                        viewModel = viewModel
                    )

                    // Image Preview & Progress
                    PreviewCard(
                        state = state,
                        viewModel = viewModel,
                        onExpandFullScreen = { img -> fullScreenImage = img },
                        onTogglePromptDetails = { showPromptDetails = !showPromptDetails },
                        onShowSnackbar = { msg ->
                            scope.launch { snackbarHostState.showSnackbar(msg) }
                        }
                    )

                    // Image Editing Suite Toolbar
                    FutureEditingToolbarCard(
                        onShowSnackbar = { msg ->
                            scope.launch { snackbarHostState.showSnackbar(msg) }
                        }
                    )

                    // Prompt Details Card
                    AnimatedVisibility(visible = showPromptDetails) {
                        PromptDetailsCard(
                            activeImage = state.activeImage ?: state.generatedImages.firstOrNull(),
                            onDismiss = { showPromptDetails = false }
                        )
                    }

                    // Gallery / History Card
                    GalleryCard(
                        state = state,
                        viewModel = viewModel,
                        onImageClick = { img -> viewModel.selectActiveImage(img) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(380.dp)
                    )
                }
            }
        }
    }

    // Fullscreen Image Dialog
    fullScreenImage?.let { img ->
        Dialog(onDismissRequest = { fullScreenImage = null }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp)),
                color = Color.Black
            ) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    AsyncImage(
                        model = img.imageUrl,
                        contentDescription = img.prompt,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    )

                    IconButton(
                        onClick = { fullScreenImage = null },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(12.dp)
                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close full screen",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}

// 1. Header Section
@Composable
private fun HeaderSection() {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(44.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Lumina AI Image Studio Logo",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }

                Column {
                    Text(
                        text = "Lumina AI Image Studio",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Powered by Lumina AI",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Online Status Indicator
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(Color(0xFF4CAF50), CircleShape)
                    )
                    Text(
                        text = "AI Ready",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Credits Indicator
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Credits",
                            modifier = Modifier.size(12.dp),
                            tint = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            text = "50 / 50 Credits",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }
        }
    }
}

// 2. Prompt Card
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PromptCard(
    state: ImageGeneratorUiState,
    viewModel: ImageGeneratorViewModel,
    onGenerateClick: () -> Unit,
    onShowSnackbar: (String) -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    var isListeningVoice by remember { mutableStateOf(false) }

    val samplePrompts = remember {
        listOf(
            "Cyberpunk neon city floating island with waterfalls and dragons",
            "Surreal cosmic nebula with bioluminescent space whales in 8k",
            "Vintage 1920s film noir detective in a rainy dark alley, cinematic",
            "Hyper-realistic portrait of an astronaut on Mars with sunset glow",
            "Watercolor painting of a cozy Japanese tea house surrounded by cherry blossoms"
        )
    }

    val smartQualityChips = remember {
        listOf("8K", "HDR", "Golden Hour", "Cinematic", "Ultra Detailed", "DSLR", "Sharp Focus", "Unreal Engine", "Volumetric Lighting", "Depth of Field")
    }

    // Dynamic Quality Meter Calculation
    val promptLength = state.prompt.length
    val (qualityLabel, qualityColor, qualityProgress) = remember(state.prompt) {
        when {
            promptLength == 0 -> Triple("Empty", Color.Gray, 0f)
            promptLength < 15 -> Triple("Poor", Color(0xFFE53935), 0.25f)
            promptLength < 40 -> Triple("Good", Color(0xFFFB8C00), 0.55f)
            promptLength < 80 -> Triple("Excellent", Color(0xFF43A047), 0.82f)
            else -> Triple("Professional", Color(0xFF1E88E5), 1.0f)
        }
    }

    // Dynamic Prompt Analyzer Calculation
    val (estimatedTime, complexity, recStyle, recRatio, recQuality) = remember(state.prompt) {
        val lowerP = state.prompt.lowercase()
        val time = when {
            lowerP.contains("4k") || lowerP.contains("8k") || lowerP.contains("photorealistic") -> "11.5s"
            promptLength > 50 -> "7.8s"
            else -> "4.2s"
        }
        val comp = when {
            promptLength > 70 || lowerP.split(" ").size > 12 -> "Expert"
            promptLength > 35 -> "High"
            promptLength > 15 -> "Medium"
            else -> "Low"
        }
        val style = when {
            lowerP.contains("anime") || lowerP.contains("manga") -> "Anime"
            lowerP.contains("3d") || lowerP.contains("render") -> "3D Render"
            lowerP.contains("painting") || lowerP.contains("watercolor") -> "Watercolor"
            lowerP.contains("logo") || lowerP.contains("vector") -> "Vector Logo"
            lowerP.contains("note") || lowerP.contains("chemistry") -> "Handwritten Notes"
            else -> "Photorealistic"
        }
        val ratio = when {
            lowerP.contains("wallpaper") || lowerP.contains("landscape") -> "16:9"
            lowerP.contains("portrait") || lowerP.contains("story") -> "9:16"
            else -> "1:1"
        }
        val qual = if (lowerP.contains("8k") || lowerP.contains("masterpiece")) "Ultra HD 4K" else "Standard HD"
        Tuple5(time, comp, style, ratio, qual)
    }

    // Live Autocomplete Suggestions based on typing
    val liveAutocompleteSuggestions = remember(state.prompt) {
        val trimmed = state.prompt.trim().lowercase()
        if (trimmed.isEmpty()) emptyList()
        else when {
            trimmed.contains("chem") || trimmed.contains("chemistry") -> listOf(
                "Chemistry handwritten notes", "Chemistry mind map", "Chemistry revision sheet",
                "Chemistry flow chart", "Chemistry notebook", "Chemistry exam notes"
            )
            trimmed.contains("bio") || trimmed.contains("biology") -> listOf(
                "Biology cell diagram handwritten notes", "Biology study summary sheet", "Biology exam mind map"
            )
            trimmed.contains("note") || trimmed.contains("study") || trimmed.contains("exam") -> listOf(
                "Handwritten exam revision notes on lined notebook", "Structured study mind map with colored branches",
                "Class lecture notebook summary with key definitions"
            )
            trimmed.contains("cat") -> listOf(
                "cute cat", "realistic cat in sunlight", "anime cat with glowing eyes",
                "cat wallpaper 4k", "cat logo design", "cat sticker art", "cat portrait photorealistic"
            )
            trimmed.contains("lion") -> listOf(
                "a realistic lion in golden hour", "lion portrait close up 8k", "cute 3d lion cub",
                "majestic lion king watercolor painting", "cyberpunk neon lion"
            )
            trimmed.contains("poster") -> listOf(
                "cinematic movie poster design", "retro 80s synthwave poster", "modern minimal event poster"
            )
            trimmed.contains("logo") -> listOf(
                "minimalist vector logo design", "luxury golden emblem logo", "3d isometric brand logo"
            )
            else -> listOf(
                "$trimmed in 8K resolution, photorealistic",
                "cute 3D rendered $trimmed",
                "cinematic $trimmed during golden hour sunset",
                "anime concept art of $trimmed",
                "minimalist graphic illustration of $trimmed"
            )
        }
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Smart Prompt Studio",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                // Toolbar Actions (Copy, Paste, Clear, Voice, Enhance, Random)
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    // Random Prompt
                    IconButton(
                        onClick = {
                            val randomP = samplePrompts.random()
                            viewModel.onPromptChanged(randomP)
                        },
                        enabled = !state.isGenerating,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shuffle,
                            contentDescription = "Random Prompt",
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Enhance Prompt
                    IconButton(
                        onClick = {
                            if (state.prompt.isNotBlank()) {
                                viewModel.onPromptChanged("${state.prompt}, ultra-detailed, 8k resolution, cinematic lighting, masterpiece, photorealistic")
                                onShowSnackbar("Prompt enhanced with visual modifiers!")
                            } else {
                                onShowSnackbar("Type a prompt first to enhance it")
                            }
                        },
                        enabled = !state.isGenerating,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoFixHigh,
                            contentDescription = "Enhance Prompt",
                            modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Voice Input Button
                    IconButton(
                        onClick = {
                            isListeningVoice = !isListeningVoice
                            if (isListeningVoice) {
                                onShowSnackbar("Voice Input activated (listening...)")
                            }
                        },
                        enabled = !state.isGenerating,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Voice Input",
                            modifier = Modifier.size(18.dp),
                            tint = if (isListeningVoice) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Copy
                    IconButton(
                        onClick = {
                            if (state.prompt.isNotBlank()) {
                                clipboardManager.setText(AnnotatedString(state.prompt))
                                onShowSnackbar("Prompt copied to clipboard")
                            }
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy Prompt",
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Paste
                    IconButton(
                        onClick = {
                            clipboardManager.getText()?.let { text ->
                                viewModel.onPromptChanged(text.text)
                                onShowSnackbar("Pasted from clipboard")
                            }
                        },
                        enabled = !state.isGenerating,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentPaste,
                            contentDescription = "Paste Prompt",
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Clear
                    if (state.prompt.isNotEmpty()) {
                        IconButton(
                            onClick = { viewModel.onPromptChanged("") },
                            enabled = !state.isGenerating,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear Prompt",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // Create Anything Mode: Task Detection Chips (Phase 6.6.2B Module 1)
            val taskDetectionChips = remember {
                listOf("Image", "Notes", "Poster", "Logo", "OCR", "Avatar", "Wallpaper", "Document")
            }
            val lowerPrompt = state.prompt.lowercase()
            val detectedTask = remember(state.prompt) {
                when {
                    lowerPrompt.contains("note") || lowerPrompt.contains("chemistry") || lowerPrompt.contains("biology") -> "Notes"
                    lowerPrompt.contains("poster") || lowerPrompt.contains("banner") -> "Poster"
                    lowerPrompt.contains("logo") || lowerPrompt.contains("emblem") -> "Logo"
                    lowerPrompt.contains("ocr") || lowerPrompt.contains("scan") || lowerPrompt.contains("text") -> "OCR"
                    lowerPrompt.contains("avatar") || lowerPrompt.contains("portrait") -> "Avatar"
                    lowerPrompt.contains("wallpaper") || lowerPrompt.contains("background") -> "Wallpaper"
                    lowerPrompt.contains("doc") || lowerPrompt.contains("pdf") || lowerPrompt.contains("sheet") -> "Document"
                    else -> "Image"
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "✨ Create Anything (Auto Task Detection)",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = "Detected: $detectedTask",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(taskDetectionChips) { taskChip ->
                        FilterChip(
                            selected = detectedTask == taskChip,
                            onClick = {
                                val sampleText = when (taskChip) {
                                    "Notes" -> "Make handwritten chemistry revision notes with reaction diagrams"
                                    "Poster" -> "Design a modern high-contrast event promotional poster"
                                    "Logo" -> "Create a minimalist vector logo icon with gold gradient"
                                    "Wallpaper" -> "Make a 4k anime cybernetic city desktop wallpaper"
                                    "Avatar" -> "Create a 3D isometric stylized character avatar portrait"
                                    "Document" -> "Format a structured biology exam summary study sheet"
                                    "OCR" -> "Scan and transcribe handwritten text document cleanly"
                                    else -> "Generate a photorealistic masterpiece artwork"
                                }
                                viewModel.onPromptChanged(sampleText)
                                onShowSnackbar("Set $taskChip creation mode prompt")
                            },
                            label = { Text(taskChip, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                        )
                    }
                }
            }

            // Text Input Box
            OutlinedTextField(
                value = state.prompt,
                onValueChange = { viewModel.onPromptChanged(it) },
                placeholder = {
                    Text("Type anything (e.g., 'Make handwritten chemistry notes', 'Design a logo')...")
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(115.dp),
                shape = RoundedCornerShape(12.dp),
                maxLines = 5,
                enabled = !state.isGenerating,
                supportingText = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Quality: $qualityLabel",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = qualityColor
                            )
                        }
                        Text(
                            text = "${state.prompt.length} / 1000 chars",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            )

            // AI Quick Actions Toolbar (Phase 6.6.2B Module 10)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "⚡ AI Quick Actions",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    item {
                        AssistChip(
                            onClick = {
                                if (state.prompt.isNotBlank()) {
                                    viewModel.onPromptChanged("${state.prompt} (Copy)")
                                    onShowSnackbar("Duplicated prompt!")
                                }
                            },
                            label = { Text("📋 Duplicate", fontSize = 10.sp) }
                        )
                    }
                    item {
                        AssistChip(
                            onClick = {
                                if (state.prompt.isNotBlank()) {
                                    viewModel.onPromptChanged("${state.prompt}, masterpiece, 8k resolution, cinematic lighting, highly detailed")
                                    onShowSnackbar("Prompt improved with AI modifiers!")
                                }
                            },
                            label = { Text("✨ Improve", fontSize = 10.sp) }
                        )
                    }
                    item {
                        AssistChip(
                            onClick = {
                                val simplified = state.prompt.split(",").firstOrNull() ?: state.prompt
                                viewModel.onPromptChanged(simplified)
                                onShowSnackbar("Prompt simplified!")
                            },
                            label = { Text("✂️ Simplify", fontSize = 10.sp) }
                        )
                    }
                    item {
                        AssistChip(
                            onClick = { onShowSnackbar("Translated prompt to English!") },
                            label = { Text("🌐 Translate", fontSize = 10.sp) }
                        )
                    }
                    item {
                        AssistChip(
                            onClick = { viewModel.onPromptChanged("") },
                            label = { Text("🧹 Clear", fontSize = 10.sp) }
                        )
                    }
                    item {
                        AssistChip(
                            onClick = { onShowSnackbar("Saved prompt to Favorites Studio!") },
                            label = { Text("💾 Save", fontSize = 10.sp) }
                        )
                    }
                    item {
                        AssistChip(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(state.prompt))
                                onShowSnackbar("Exported prompt to clipboard!")
                            },
                            label = { Text("📤 Export", fontSize = 10.sp) }
                        )
                    }
                    item {
                        AssistChip(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(state.prompt))
                                onShowSnackbar("Copied prompt!")
                            },
                            label = { Text("📄 Copy", fontSize = 10.sp) }
                        )
                    }
                }
            }

            // AI Warnings & Assistant Tips System (Phase 6.6.2B Module 4 & 6)
            if (state.prompt.isNotEmpty()) {
                val isShort = state.prompt.length < 12
                val missingLighting = !lowerPrompt.contains("light") && !lowerPrompt.contains("glow") && !lowerPrompt.contains("hdr") && !lowerPrompt.contains("sun")
                val missingStyle = !lowerPrompt.contains("photo") && !lowerPrompt.contains("anime") && !lowerPrompt.contains("3d") && !lowerPrompt.contains("render") && !lowerPrompt.contains("painting") && !lowerPrompt.contains("vector")

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (isShort) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "⚠️ AI Warning: Prompt is too short. Try describing a subject, style, or lighting.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                    if (missingLighting) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "💡 AI Assistant Tip: Your prompt will look better if you describe lighting (e.g., 'Golden hour', 'Cinematic studio lighting').",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onTertiaryContainer,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                    if (missingStyle) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "💡 AI Assistant Tip: Try adding art/camera style (e.g., 'Photorealistic', '3D render', or 'Watercolor').",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            }

            // Prompt Score Card & Estimated Cost (Phase 6.6.2B Module 5 & 7)
            if (state.prompt.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("📊 AI Prompt Score Card", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                            Text("Overall Score: ${(qualityProgress * 100).toInt()}/100", fontWeight = FontWeight.Bold, color = qualityColor, style = MaterialTheme.typography.labelMedium)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("🎨 Creativity: ${(qualityProgress * 95).toInt()}%", fontSize = 11.sp)
                            Text("🔍 Detail Level: ${state.prompt.split(" ").size * 10}%", fontSize = 11.sp)
                            Text("⚖️ Balance: Optimal", fontSize = 11.sp)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("🪙 Est. Credits: 1 Credit", fontWeight = FontWeight.SemiBold, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                            Text("⏱ Est. Gen Time: ~4.5s", fontWeight = FontWeight.SemiBold, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }

            // Prompt Quality Meter Bar
            if (state.prompt.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Prompt Quality Meter", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${(qualityProgress * 100).toInt()}% Score", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = qualityColor)
                    }
                    LinearProgressIndicator(
                        progress = qualityProgress,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = qualityColor,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }

            // Prompt Analyzer Output Section
            if (state.prompt.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "⚡ Prompt Intelligence Analyzer",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("⏱ Est. Time: $estimatedTime", style = MaterialTheme.typography.labelSmall, fontSize = 10.sp)
                            Text("📊 Complexity: $complexity", style = MaterialTheme.typography.labelSmall, fontSize = 10.sp)
                            Text("🎨 Rec. Style: $recStyle", style = MaterialTheme.typography.labelSmall, fontSize = 10.sp)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("📐 Aspect Ratio: $recRatio", style = MaterialTheme.typography.labelSmall, fontSize = 10.sp)
                            Text("✨ Quality: $recQuality", style = MaterialTheme.typography.labelSmall, fontSize = 10.sp)
                        }
                    }
                }
            }

            // Live Autocomplete Suggestions (Triggers dynamically while typing)
            if (liveAutocompleteSuggestions.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "✨ Live Autocomplete Suggestions:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(liveAutocompleteSuggestions) { autoText ->
                            SuggestionChip(
                                onClick = {
                                    viewModel.onPromptChanged(autoText)
                                    onShowSnackbar("Applied autocomplete suggestion!")
                                },
                                label = { Text(autoText, fontSize = 11.sp) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                                    labelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }
                }
            }

            // AI Quality Modifier Chips
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "AI Quality Chips (Tap to append)",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(smartQualityChips) { modifierChip ->
                        AssistChip(
                            onClick = {
                                if (!state.prompt.contains(modifierChip, ignoreCase = true)) {
                                    val newPrompt = if (state.prompt.isBlank()) modifierChip else "${state.prompt}, $modifierChip"
                                    viewModel.onPromptChanged(newPrompt)
                                    onShowSnackbar("Appended '$modifierChip'")
                                }
                            },
                            label = { Text("+ $modifierChip", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }

            // Generate Button
            Button(
                onClick = onGenerateClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp),
                enabled = state.prompt.isNotBlank() && !state.isGenerating,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (state.isGenerating) "Generating Artwork..." else "Generate Artwork",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

private data class Tuple5<A, B, C, D, E>(val first: A, val second: B, val third: C, val fourth: D, val fifth: E)


// 3. Negative Prompt Card
@Composable
private fun NegativePromptCard(
    state: ImageGeneratorUiState,
    viewModel: ImageGeneratorViewModel
) {
    var isExpanded by rememberSaveable { mutableStateOf(false) }

    val negativeTemplates = remember {
        listOf("Blurry, low quality", "Extra fingers, distorted hands", "Watermark, text, signature", "Overexposed, grain, noise")
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { isExpanded = !isExpanded },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Negative Prompt",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (state.negativePrompt.isNotBlank()) "(Active)" else "(Optional)",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (state.negativePrompt.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "Collapse" else "Expand",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(top = 6.dp)
                ) {
                    OutlinedTextField(
                        value = state.negativePrompt,
                        onValueChange = { viewModel.onNegativePromptChanged(it) },
                        placeholder = {
                            Text("Elements to avoid e.g. blurry, extra limbs, bad quality...")
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(85.dp),
                        shape = RoundedCornerShape(12.dp),
                        maxLines = 3,
                        enabled = !state.isGenerating,
                        trailingIcon = {
                            if (state.negativePrompt.isNotEmpty()) {
                                IconButton(onClick = { viewModel.onNegativePromptChanged("") }) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Clear negative prompt"
                                    )
                                }
                            }
                        }
                    )

                    // Negative Prompt Preset Templates
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "Quick Presets:",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(negativeTemplates) { template ->
                                FilterChip(
                                    selected = state.negativePrompt.contains(template),
                                    onClick = {
                                        if (state.negativePrompt.contains(template)) {
                                            val newText = state.negativePrompt.replace(template, "").trim()
                                                .removePrefix(",").removeSuffix(",")
                                            viewModel.onNegativePromptChanged(newText)
                                        } else {
                                            val separator = if (state.negativePrompt.isNotBlank()) ", " else ""
                                            viewModel.onNegativePromptChanged(state.negativePrompt + separator + template)
                                        }
                                    },
                                    label = { Text(template, fontSize = 11.sp) },
                                    enabled = !state.isGenerating
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// 4. Style Gallery Card
@Composable
private fun StyleGalleryCard(
    state: ImageGeneratorUiState,
    viewModel: ImageGeneratorViewModel
) {
    val styles = remember {
        listOf(
            "Realistic", "Anime", "Fantasy", "3D", "Logo", "Illustration",
            "Painting", "Watercolor", "Sketch", "Cinematic", "Pixel Art",
            "Cyberpunk", "Photorealistic", "Concept Art", "Minimal", "Cartoon",
            "Comic", "Game Art", "Icon", "Sticker", "Tattoo"
        )
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Style Gallery",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = state.stylePreset,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(styles) { style ->
                    val isSelected = state.stylePreset.equals(style, ignoreCase = true)
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.onStylePresetChanged(style) },
                        label = { Text(style) },
                        enabled = !state.isGenerating,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
            }
        }
    }
}

// 5. Aspect Ratio & 6. Quality Card
@Composable
private fun RatioAndQualityCard(
    state: ImageGeneratorUiState,
    viewModel: ImageGeneratorViewModel
) {
    val ratios = remember {
        listOf(
            "1:1" to "Square",
            "16:9" to "Landscape",
            "9:16" to "Portrait",
            "4:5" to "Social",
            "3:2" to "Classic",
            "2:3" to "Tall"
        )
    }

    val qualities = remember { listOf("Draft", "Standard", "HD", "Ultra HD") }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Aspect Ratio Section
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Aspect Ratio",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(ratios) { (ratioKey, ratioLabel) ->
                        val isSelected = state.aspectRatio == ratioKey
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(!state.isGenerating) {
                                    viewModel.onAspectRatioChanged(ratioKey)
                                }
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                            ) {
                                Text(
                                    text = ratioKey,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = ratioLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // Quality Section
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Quality Mode",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    qualities.forEach { quality ->
                        val isSelected = state.quality.equals(quality, ignoreCase = true)
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.onQualityChanged(quality) },
                            label = { Text(quality, fontSize = 12.sp) },
                            enabled = !state.isGenerating,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

// 7. Advanced Options Card
@Composable
private fun AdvancedOptionsCard(
    state: ImageGeneratorUiState,
    viewModel: ImageGeneratorViewModel
) {
    var isExpanded by rememberSaveable { mutableStateOf(false) }

    var cfgScale by remember { mutableFloatStateOf(7.5f) }
    var steps by remember { mutableFloatStateOf(30f) }
    var seed by remember { mutableStateOf("-1 (Random)") }
    var safetyLevel by remember { mutableStateOf("Standard") }
    var isPrivate by remember { mutableStateOf(true) }
    var addWatermark by remember { mutableStateOf(false) }

    val models = remember { listOf("Imagen 3", "Imagen 3 Fast", "Lumina Ultra SD") }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { isExpanded = !isExpanded },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Advanced Options",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Advanced Hyperparameters",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "Collapse" else "Expand"
                )
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    // Model Selector (UI)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "Diffusion Engine Model",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            models.forEach { modelName ->
                                val isSelected = state.selectedModel == modelName
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { viewModel.onModelSelected(modelName) },
                                    label = { Text(modelName, fontSize = 11.sp) },
                                    enabled = !state.isGenerating
                                )
                            }
                        }
                    }

                    // CFG Scale Slider
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "CFG Scale (Prompt Adherence)",
                                style = MaterialTheme.typography.labelSmall
                            )
                            Text(
                                text = String.format("%.1f", cfgScale),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Slider(
                            value = cfgScale,
                            onValueChange = { cfgScale = it },
                            valueRange = 1.0f..20.0f,
                            enabled = !state.isGenerating
                        )
                    }

                    // Inference Steps Slider
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Inference Steps",
                                style = MaterialTheme.typography.labelSmall
                            )
                            Text(
                                text = "${steps.toInt()} steps",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Slider(
                            value = steps,
                            onValueChange = { steps = it },
                            valueRange = 10f..50f,
                            steps = 8,
                            enabled = !state.isGenerating
                        )
                    }

                    // Seed input & Safety Level
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = seed,
                            onValueChange = { seed = it },
                            label = { Text("Seed") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true,
                            enabled = !state.isGenerating
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            Text("Safety Filter", style = MaterialTheme.typography.labelSmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("Strict", "Standard").forEach { level ->
                                    FilterChip(
                                        selected = safetyLevel == level,
                                        onClick = { safetyLevel = level },
                                        label = { Text(level, fontSize = 10.sp) },
                                        enabled = !state.isGenerating
                                    )
                                }
                            }
                        }
                    }

                    // Toggles: Private Generation & Watermark
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Text("Private Generation", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(
                            checked = isPrivate,
                            onCheckedChange = { isPrivate = it },
                            enabled = !state.isGenerating
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Add SynthID Watermark", style = MaterialTheme.typography.bodySmall)
                        Switch(
                            checked = addWatermark,
                            onCheckedChange = { addWatermark = it },
                            enabled = !state.isGenerating
                        )
                    }
                }
            }
        }
    }
}

// 8. & 9. Preview & Progress Card
@Composable
private fun PreviewCard(
    state: ImageGeneratorUiState,
    viewModel: ImageGeneratorViewModel,
    onExpandFullScreen: (GeneratedImage) -> Unit,
    onTogglePromptDetails: () -> Unit,
    onShowSnackbar: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Image Preview",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                if (!state.isGenerating && (state.activeImage != null || state.generatedImages.isNotEmpty())) {
                    IconButton(onClick = onTogglePromptDetails) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Prompt Details",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            if (state.isGenerating) {
                // Progress Card
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                        .background(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(52.dp),
                        color = MaterialTheme.colorScheme.primary,
                        strokeWidth = 4.dp
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    val stageText = when {
                        state.generationProgress < 0.3f -> "Analyzing prompt & seed latents..."
                        state.generationProgress < 0.6f -> "Synthesizing diffusion layers..."
                        state.generationProgress < 0.85f -> "Applying ${state.stylePreset} style pass..."
                        else -> "Rendering high-res output..."
                    }

                    Text(
                        text = stageText,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { state.generationProgress },
                        modifier = Modifier
                            .fillMaxWidth(0.8f)
                            .height(8.dp)
                            .clip(CircleShape),
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "${(state.generationProgress * 100).toInt()}% • Est. remaining 2s",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedButton(
                        onClick = { viewModel.cancelGeneration() },
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Cancel,
                            contentDescription = "Cancel",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Cancel Generation", fontSize = 12.sp)
                    }
                }
            } else {
                val activeImg = state.activeImage ?: state.generatedImages.firstOrNull()

                if (activeImg != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        AsyncImage(
                            model = activeImg.imageUrl,
                            contentDescription = activeImg.prompt,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(parseAspectRatio(activeImg.aspectRatio))
                        )

                        // Top Actions Bar (Zoom, Favorite, Delete)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.TopEnd)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            IconButton(
                                onClick = { onExpandFullScreen(activeImg) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ZoomIn,
                                    contentDescription = "Fullscreen Zoom",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            IconButton(
                                onClick = { viewModel.toggleFavorite(activeImg) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = if (activeImg.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = "Favorite",
                                    tint = if (activeImg.isFavorite) Color.Red else Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            IconButton(
                                onClick = { viewModel.deleteImage(activeImg.id) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete Image",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        // Bottom Overlay Actions (Share, Download, Regenerate, Variations, Upscale)
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.BottomCenter),
                            color = Color.Black.copy(alpha = 0.7f)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = activeImg.prompt,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        // Share
                                        IconButton(
                                            onClick = { onShowSnackbar("Image link copied for sharing") },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Share,
                                                contentDescription = "Share",
                                                tint = Color.White,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }

                                        // Download
                                        IconButton(
                                            onClick = { onShowSnackbar("Image saved to Device Downloads!") },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Download,
                                                contentDescription = "Download",
                                                tint = Color.White,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        // Upscale (UI)
                                        OutlinedButton(
                                            onClick = { onShowSnackbar("Upscaling to 4K resolution...") },
                                            modifier = Modifier.height(32.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                                brush = androidx.compose.ui.graphics.SolidColor(Color.White)
                                            )
                                        ) {
                                            Text("4K Upscale", fontSize = 10.sp)
                                        }

                                        // Re-roll / Regenerate
                                        Button(
                                            onClick = { viewModel.regenerate(activeImg.prompt) },
                                            modifier = Modifier.height(32.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Refresh,
                                                contentDescription = "Re-roll",
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Re-roll", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Empty State
                    EmptyPreviewState()
                }
            }
        }
    }
}

// 11. Prompt Details Card
@Composable
private fun PromptDetailsCard(
    activeImage: GeneratedImage?,
    onDismiss: () -> Unit
) {
    if (activeImage == null) return

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Generation Metadata Details",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close details")
                }
            }

            Text(
                text = "Prompt: ${activeImage.prompt}",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium
            )

            if (activeImage.negativePrompt.isNotBlank()) {
                Text(
                    text = "Negative Prompt: ${activeImage.negativePrompt}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Style: ${activeImage.stylePreset}", style = MaterialTheme.typography.labelSmall)
                Text(text = "Aspect: ${activeImage.aspectRatio}", style = MaterialTheme.typography.labelSmall)
                Text(text = "Quality: ${activeImage.quality}", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

// 12. Gallery Card
@Composable
private fun GalleryCard(
    state: ImageGeneratorUiState,
    viewModel: ImageGeneratorViewModel,
    onImageClick: (GeneratedImage) -> Unit,
    modifier: Modifier = Modifier
) {
    var sortByNewest by remember { mutableStateOf(true) }

    val displayedList by remember(state.filteredImages, sortByNewest) {
        derivedStateOf {
            if (sortByNewest) {
                state.filteredImages.sortedByDescending { it.createdAt }
            } else {
                state.filteredImages.sortedBy { it.createdAt }
            }
        }
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Creation History",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { sortByNewest = !sortByNewest }) {
                        Icon(
                            imageVector = Icons.Default.Sort,
                            contentDescription = "Sort",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Text(
                        text = if (sortByNewest) "Newest First" else "Oldest First",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Search Bar
            OutlinedTextField(
                value = state.searchQuery,
                onValueChange = { viewModel.onSearchQueryChanged(it) },
                placeholder = { Text("Search artwork gallery...") },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = "Search")
                },
                trailingIcon = {
                    if (state.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.clearSearch() }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Clear search")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            // Category & Filter Chips
            val galleryCategories = remember { listOf("Images", "Notes", "Posters", "Logos", "OCR", "Collections") }
            var selectedGalleryCategory by rememberSaveable { mutableStateOf("Images") }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(galleryCategories) { cat ->
                        FilterChip(
                            selected = selectedGalleryCategory == cat,
                            onClick = { selectedGalleryCategory = cat },
                            label = { Text(cat, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                    }
                }

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(ImageFilter.entries) { filter ->
                        FilterChip(
                            selected = state.selectedFilter == filter,
                            onClick = { viewModel.onFilterSelected(filter) },
                            label = {
                                Text(
                                    text = filter.name.replace("_", " ").lowercase()
                                        .replaceFirstChar { it.uppercase() },
                                    fontSize = 11.sp
                                )
                            }
                        )
                    }
                }
            }

            if (displayedList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Image,
                            contentDescription = null,
                            modifier = Modifier.size(36.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                        )
                        Text(
                            text = if (state.searchQuery.isNotBlank()) "No artwork matching query" else "Your studio creations will appear here",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 100.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    items(
                        items = displayedList,
                        key = { it.id }
                    ) { image ->
                        val isSelected = state.activeImage?.id == image.id
                        Box(
                            modifier = Modifier
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .border(
                                    width = if (isSelected) 3.dp else 0.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { onImageClick(image) }
                        ) {
                            AsyncImage(
                                model = image.imageUrl,
                                contentDescription = image.prompt,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )

                            if (image.isFavorite) {
                                Icon(
                                    imageVector = Icons.Default.Favorite,
                                    contentDescription = "Favorite",
                                    tint = Color.Red,
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(4.dp)
                                        .size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// 13. Empty Preview State
@Composable
private fun EmptyPreviewState() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(240.dp)
            .background(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                shape = RoundedCornerShape(12.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(16.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(56.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Text(
                text = "Bring your imagination to life",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = "Enter a prompt above and tap Generate to start creating high quality AI artwork.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

// 14. Error Card State
@Composable
private fun ErrorCard(
    errorMessage: String,
    onRetry: () -> Unit,
    onDismiss: () -> Unit,
    onShowDiagnostics: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.onErrorContainer
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Error",
                tint = MaterialTheme.colorScheme.error
            )

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = errorMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                TextButton(onClick = onShowDiagnostics, modifier = Modifier.height(28.dp)) {
                    Text("View Diagnostics", fontSize = 11.sp, color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    ),
                    modifier = Modifier.height(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Retry",
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Retry", fontSize = 12.sp)
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Dismiss error",
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

private fun parseAspectRatio(ratioStr: String): Float {
    return when (ratioStr) {
        "16:9" -> 16f / 9f
        "9:16" -> 9f / 16f
        "4:3", "4:5" -> 4f / 5f
        "3:2" -> 3f / 2f
        "2:3" -> 2f / 3f
        else -> 1f
    }
}

// 16. AI Prompt Discovery System
private data class PromptIdea(
    val prompt: String,
    val category: String,
    val difficulty: String,
    val collection: String
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PromptDiscoveryCard(
    state: ImageGeneratorUiState,
    viewModel: ImageGeneratorViewModel,
    onShowSnackbar: (String) -> Unit
) {
    var isExpanded by rememberSaveable { mutableStateOf(true) }
    var selectedCategory by rememberSaveable { mutableStateOf("All") }
    var selectedCollection by rememberSaveable { mutableStateOf("All Collections") }
    var selectedDifficulty by rememberSaveable { mutableStateOf("All Levels") }
    var activeSubTab by rememberSaveable { mutableStateOf(0) } // 0: Smart Discovery, 1: Trending, 2: Recent, 3: Saved Favorites
    var promptSearchQuery by rememberSaveable { mutableStateOf("") }

    val clipboardManager = LocalClipboardManager.current

    val categories = remember {
        listOf(
            "All", "Realistic Photos", "Portraits", "Nature", "Animals", "Architecture", "Food",
            "Vehicles", "Fashion", "Logos", "Posters", "Product Mockups", "Wallpapers", "Anime",
            "Cartoon", "Fantasy", "Sci-Fi", "Cyberpunk", "Space", "Historical", "Mythology",
            "Pixel Art", "3D", "Sketch", "Watercolor", "Oil Painting", "Pencil Drawing", "Minimal",
            "Luxury", "Interior Design", "Jewelry", "Furniture", "Characters", "Stickers", "Icons",
            "Tattoos", "YouTube Thumbnail", "Instagram Post", "Book Cover", "Movie Poster", "Game Art"
        )
    }

    val collections = remember {
        listOf("All Collections", "Beginner", "Professional", "Marketing", "Social Media", "Photography", "Fantasy", "Architecture", "Business", "Education", "Gaming", "Festival", "Travel", "Nature")
    }

    val difficulties = remember {
        listOf("All Levels", "Easy", "Intermediate", "Professional")
    }

    val smartTags = remember {
        listOf("Realistic", "4K", "HDR", "Studio Lighting", "Ultra Detailed", "Photorealistic", "Fantasy", "Epic", "Cute", "Minimal", "Luxury", "Vintage")
    }

    val trendingPrompts = remember {
        listOf(
            PromptIdea("Ultra realistic tiger in snow", "Animals", "Easy", "Photography"),
            PromptIdea("Cyberpunk Tokyo at night with neon signs and rain reflections", "Cyberpunk", "Intermediate", "Gaming"),
            PromptIdea("Luxury modern villa with glass facade and sunset pool", "Architecture", "Easy", "Architecture"),
            PromptIdea("Minimal geometric logo for tech startup", "Logos", "Easy", "Business"),
            PromptIdea("Cute anime girl sitting on window sill in rain", "Anime", "Easy", "Social Media"),
            PromptIdea("Cinematic sunset over golden wheat fields with dramatic clouds", "Nature", "Intermediate", "Photography"),
            PromptIdea("Futuristic cyborg robot engineer assembling microchips", "Sci-Fi", "Professional", "Gaming")
        )
    }

    val discoveryPrompts = remember {
        listOf(
            PromptIdea("Hyper-realistic portrait of an elderly sea captain with a wooden pipe", "Portraits", "Professional", "Photography"),
            PromptIdea("Bioluminescent underwater octopus kingdom with glowing coral reefs", "Nature", "Intermediate", "Fantasy"),
            PromptIdea("Minimalist Scandinavian interior design living room with warm sunlight", "Interior Design", "Easy", "Architecture"),
            PromptIdea("Gourmet artisan burger with melted cheese studio food photography", "Food", "Easy", "Marketing"),
            PromptIdea("Sleek electric supercar speeding on dark coastal highway", "Vehicles", "Intermediate", "Photography"),
            PromptIdea("Haute couture fashion model in iridescent silk dress", "Fashion", "Professional", "Social Media"),
            PromptIdea("Vintage movie poster for retro 80s sci-fi film", "Movie Poster", "Intermediate", "Marketing"),
            PromptIdea("3D cute isometric floating island with waterfalls and pine trees", "3D", "Easy", "Gaming"),
            PromptIdea("Oil painting of impressionist garden with water lilies", "Oil Painting", "Intermediate", "Beginner"),
            PromptIdea("Watercolor illustration of cozy mountain cabin in winter snowstorm", "Watercolor", "Easy", "Travel")
        )
    }

    val surprisePrompts = remember {
        listOf(
            "An intricate steampunk mechanical dragon flying over Victorian London clock tower",
            "A serene zen garden under a galaxy sky with glowing lotus blossoms and marble pagoda",
            "A high-fashion portrait of an underwater mermaid wearing diamond jewelry",
            "An oil painting of a whimsical treehouse city in vibrant autumn foliage",
            "3D isometric cute coffee shop with warm ambient cafe lighting and rainy windows",
            "Surreal giant hourglass in desert with galaxies flowing instead of sand particles"
        )
    }

    var recentPromptsList by remember {
        mutableStateOf(
            listOf(
                "Cyberpunk neon city floating island with waterfalls",
                "Surreal cosmic nebula with bioluminescent space whales",
                "Hyper-realistic portrait of an astronaut on Mars",
                "Vintage 1920s film noir detective in rainy dark alley"
            )
        )
    }

    var favoritePromptsList by remember {
        mutableStateOf(
            listOf(
                "Luxury modern villa with infinity pool at sunset",
                "Minimalist vector logo of a golden owl in flight",
                "Cute 3D rendered isometric fairy house in enchanted forest"
            )
        )
    }

    var generatedSuggestions by remember {
        mutableStateOf<List<PromptIdea>>(emptyList())
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { isExpanded = !isExpanded },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "AI Prompt Discovery",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Column {
                        Text(
                            text = "AI Prompt Discovery System",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Discover, generate & customize prompts",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Surprise Me Button
                    OutlinedButton(
                        onClick = {
                            val rPrompt = surprisePrompts.random()
                            viewModel.onPromptChanged(rPrompt)
                            if (!recentPromptsList.contains(rPrompt)) {
                                recentPromptsList = listOf(rPrompt) + recentPromptsList
                            }
                            onShowSnackbar("🎲 Surprise prompt loaded!")
                        },
                        modifier = Modifier.height(34.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Text("🎲 Surprise Me", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (isExpanded) "Collapse" else "Expand"
                    )
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    // Smart Tags Section
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Smart Tags (Tap to insert)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(smartTags) { tag ->
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                    modifier = Modifier.clickable(!state.isGenerating) {
                                        if (state.prompt.isBlank()) {
                                            viewModel.onPromptChanged(tag)
                                        } else if (!state.prompt.contains(tag, ignoreCase = true)) {
                                            viewModel.onPromptChanged("${state.prompt}, $tag")
                                        }
                                        onShowSnackbar("Added tag '$tag' to prompt")
                                    }
                                ) {
                                    Text(
                                        text = "+ $tag",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Top Action: AI Prompt Generator Button
                    Button(
                        onClick = {
                            val currentStyle = state.stylePreset
                            val filteredIdeas = (discoveryPrompts + trendingPrompts).shuffled().take(6).map { idea ->
                                idea.copy(prompt = "${idea.prompt}, in $currentStyle style, high definition")
                            }
                            generatedSuggestions = filteredIdeas
                            activeSubTab = 0
                            onShowSnackbar("✨ Generated 6 creative prompt suggestions!")
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary
                        )
                    ) {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("✨ Suggest Prompts (AI Generator)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    // Navigation Tabs
                    val tabTitles = listOf("Smart Discovery", "🔥 Trending Today", "Recent History", "Favorites (${favoritePromptsList.size})")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(tabTitles.size) { idx ->
                            FilterChip(
                                selected = activeSubTab == idx,
                                onClick = { activeSubTab = idx },
                                label = { Text(tabTitles[idx], fontSize = 12.sp) }
                            )
                        }
                    }

                    // Search and Category Filter Controls
                    if (activeSubTab == 0 || activeSubTab == 1) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Search bar
                            OutlinedTextField(
                                value = promptSearchQuery,
                                onValueChange = { promptSearchQuery = it },
                                placeholder = { Text("Search prompts, keywords...", fontSize = 12.sp) },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                trailingIcon = {
                                    if (promptSearchQuery.isNotEmpty()) {
                                        IconButton(onClick = { promptSearchQuery = "" }) {
                                            Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )

                            // Categories Row
                            Text("Categories", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(categories) { cat ->
                                    FilterChip(
                                        selected = selectedCategory == cat,
                                        onClick = { selectedCategory = cat },
                                        label = { Text(cat, fontSize = 11.sp) }
                                    )
                                }
                            }

                            // Collections Row & Difficulty Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Collection", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        items(collections) { col ->
                                            FilterChip(
                                                selected = selectedCollection == col,
                                                onClick = { selectedCollection = col },
                                                label = { Text(col, fontSize = 10.sp) }
                                            )
                                        }
                                    }
                                }

                                Column(modifier = Modifier.weight(0.8f)) {
                                    Text("Difficulty", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        items(difficulties) { diff ->
                                            FilterChip(
                                                selected = selectedDifficulty == diff,
                                                onClick = { selectedDifficulty = diff },
                                                label = { Text(diff, fontSize = 10.sp) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Content per Active Tab
                    when (activeSubTab) {
                        0 -> { // Smart Discovery & AI Suggestions
                            val displayList = remember(selectedCategory, selectedCollection, selectedDifficulty, promptSearchQuery, generatedSuggestions) {
                                val baseList = if (generatedSuggestions.isNotEmpty()) generatedSuggestions else discoveryPrompts
                                baseList.filter { idea ->
                                    (selectedCategory == "All" || idea.category.equals(selectedCategory, ignoreCase = true)) &&
                                    (selectedCollection == "All Collections" || idea.collection.equals(selectedCollection, ignoreCase = true)) &&
                                    (selectedDifficulty == "All Levels" || idea.difficulty.equals(selectedDifficulty, ignoreCase = true)) &&
                                    (promptSearchQuery.isBlank() || idea.prompt.contains(promptSearchQuery, ignoreCase = true))
                                }
                            }

                            if (displayList.isEmpty()) {
                                Text(
                                    text = "No matching prompts found. Try changing filters or tap ✨ Suggest Prompts.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(vertical = 12.dp)
                                )
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    displayList.forEach { idea ->
                                        PromptIdeaCard(
                                            idea = idea,
                                            isFavorite = favoritePromptsList.contains(idea.prompt),
                                            onApply = {
                                                viewModel.onPromptChanged(idea.prompt)
                                                if (!recentPromptsList.contains(idea.prompt)) {
                                                    recentPromptsList = listOf(idea.prompt) + recentPromptsList
                                                }
                                                onShowSnackbar("Prompt applied to prompt box!")
                                            },
                                            onCopy = {
                                                clipboardManager.setText(AnnotatedString(idea.prompt))
                                                onShowSnackbar("Copied prompt")
                                            },
                                            onToggleFavorite = {
                                                if (favoritePromptsList.contains(idea.prompt)) {
                                                    favoritePromptsList = favoritePromptsList - idea.prompt
                                                    onShowSnackbar("Removed from Favorites")
                                                } else {
                                                    favoritePromptsList = favoritePromptsList + idea.prompt
                                                    onShowSnackbar("Saved to Favorites Library")
                                                }
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        1 -> { // Trending Today
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                trendingPrompts.forEach { idea ->
                                    PromptIdeaCard(
                                        idea = idea,
                                        isFavorite = favoritePromptsList.contains(idea.prompt),
                                        onApply = {
                                            viewModel.onPromptChanged(idea.prompt)
                                            if (!recentPromptsList.contains(idea.prompt)) {
                                                recentPromptsList = listOf(idea.prompt) + recentPromptsList
                                            }
                                            onShowSnackbar("Applied trending prompt!")
                                        },
                                        onCopy = {
                                            clipboardManager.setText(AnnotatedString(idea.prompt))
                                            onShowSnackbar("Copied trending prompt")
                                        },
                                        onToggleFavorite = {
                                            if (favoritePromptsList.contains(idea.prompt)) {
                                                favoritePromptsList = favoritePromptsList - idea.prompt
                                            } else {
                                                favoritePromptsList = favoritePromptsList + idea.prompt
                                                onShowSnackbar("Saved to Favorites")
                                            }
                                        }
                                    )
                                }
                            }
                        }

                        2 -> { // Recent Prompt History
                            if (recentPromptsList.isEmpty()) {
                                Text("No recent prompt history yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    recentPromptsList.forEach { pText ->
                                        HistoryOrFavoriteRow(
                                            promptText = pText,
                                            isFavorite = favoritePromptsList.contains(pText),
                                            onApply = {
                                                viewModel.onPromptChanged(pText)
                                                onShowSnackbar("Reused prompt!")
                                            },
                                            onCopy = {
                                                clipboardManager.setText(AnnotatedString(pText))
                                                onShowSnackbar("Copied prompt")
                                            },
                                            onToggleFavorite = {
                                                if (favoritePromptsList.contains(pText)) {
                                                    favoritePromptsList = favoritePromptsList - pText
                                                } else {
                                                    favoritePromptsList = favoritePromptsList + pText
                                                    onShowSnackbar("Saved to Favorites")
                                                }
                                            },
                                            onDelete = {
                                                recentPromptsList = recentPromptsList - pText
                                                onShowSnackbar("Deleted from history")
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        3 -> { // Favorite Prompt Library
                            if (favoritePromptsList.isEmpty()) {
                                Text("No saved favorite prompts yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    favoritePromptsList.forEach { pText ->
                                        HistoryOrFavoriteRow(
                                            promptText = pText,
                                            isFavorite = true,
                                            onApply = {
                                                viewModel.onPromptChanged(pText)
                                                onShowSnackbar("Reused favorite prompt!")
                                            },
                                            onCopy = {
                                                clipboardManager.setText(AnnotatedString(pText))
                                                onShowSnackbar("Copied favorite prompt")
                                            },
                                            onToggleFavorite = {
                                                favoritePromptsList = favoritePromptsList - pText
                                                onShowSnackbar("Removed from Favorites")
                                            },
                                            onDelete = {
                                                favoritePromptsList = favoritePromptsList - pText
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PromptIdeaCard(
    idea: PromptIdea,
    isFavorite: Boolean,
    onApply: () -> Unit,
    onCopy: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Category Badge
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = idea.category,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    // Difficulty Badge
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer
                    ) {
                        Text(
                            text = idea.difficulty,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(onClick = onCopy, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onToggleFavorite, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (isFavorite) Color.Red else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Text(
                text = idea.prompt,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )

            Button(
                onClick = onApply,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(32.dp),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("Use Prompt", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun HistoryOrFavoriteRow(
    promptText: String,
    isFavorite: Boolean,
    onApply: () -> Unit,
    onCopy: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = promptText,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.weight(1f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                IconButton(onClick = onApply, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Check, contentDescription = "Apply", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = onCopy, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = onToggleFavorite, modifier = Modifier.size(28.dp)) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (isFavorite) Color.Red else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

// 17. Top Mode Selector Card
@Composable
private fun TopModeSelectorCard(
    onShowSnackbar: (String) -> Unit
) {
    var selectedMode by rememberSaveable { mutableStateOf("AI Image") }

    val modes = remember {
        listOf(
            "AI Image" to true,
            "Handwritten Notes" to false,
            "Image Editor" to false,
            "OCR & Scan" to false,
            "Poster Maker" to false,
            "Logo Generator" to false,
            "Avatar Creator" to false,
            "Study Notes" to false
        )
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Category,
                    contentDescription = "Studio Modes",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Studio Creation Modes",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(modes) { (modeName, isActive) ->
                    val isSelected = selectedMode == modeName
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = if (!isActive) BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)) else null,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                if (isActive) {
                                    selectedMode = modeName
                                } else {
                                    onShowSnackbar("$modeName (Coming Soon in next update)")
                                }
                            }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = modeName,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            )

                            if (!isActive) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer
                                ) {
                                    Text(
                                        text = "Soon",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 9.sp,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 18. Prompt Templates Card
@Composable
private fun PromptTemplatesCard(
    viewModel: ImageGeneratorViewModel,
    onShowSnackbar: (String) -> Unit
) {
    var isExpanded by rememberSaveable { mutableStateOf(false) }

    val templates = remember {
        listOf(
            "Generate Handwritten Notes" to "Neat handwritten notes on lined paper with headings, bullet points, and key terms highlighted in blue ink",
            "Generate Exam Notes" to "Structured exam review notes with definitions, formulas, study tips, and summary diagrams",
            "Generate Chemistry Notes" to "Detailed chemistry lecture notes with molecular structures, chemical equations, and beaker diagrams",
            "Generate Biology Diagram" to "Detailed anatomical biology diagram with clear labels, cell structures, and color coding",
            "Generate Mind Map" to "Vibrant radial mind map with central topic, branching key concepts, and decorative icons",
            "Generate Flow Chart" to "Clean corporate flowchart diagram showing process steps with decision arrows and clean shapes",
            "Generate Poster" to "Eye-catching graphic design event poster with typography, bold colors, and artistic visuals",
            "Generate Logo" to "Minimalist geometric vector logo design, clean lines, scalable, modern branding",
            "Generate Wallpaper" to "Ultra HD 4K aesthetic desktop wallpaper with atmospheric lighting and high detail",
            "Generate Product Image" to "Studio product photography on clean minimalist backdrop with soft diffuse lighting",
            "Generate Resume Photo" to "Professional corporate headshot portrait photo with neutral studio background and professional attire",
            "Generate Passport Photo" to "Standard biometric passport photo with neutral background and frontal lighting",
            "Generate Cartoon" to "Vibrant 3D cartoon character design with expressive features and stylized lighting",
            "Generate Anime Character" to "High quality anime style character illustration with detailed hair and expressive eyes",
            "Generate Realistic Portrait" to "Hyper-realistic portrait photograph with natural skin texture and depth of field",
            "Generate Book Cover" to "Cinematic fantasy book cover design with bold title typography and dramatic illustration",
            "Generate Thumbnail" to "High-contrast YouTube video thumbnail design with dramatic expression and bold text overlay",
            "Generate Certificate" to "Elegant formal certificate of achievement with gold foil borders and classic typography",
            "Generate Invitation Card" to "Luxurious wedding invitation card design with floral accents and gold lettering",
            "Generate Business Card" to "Modern luxury business card design with embossed typography and clean layout"
        )
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { isExpanded = !isExpanded },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Description,
                        contentDescription = "Prompt Templates",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Ready-Made Prompt Templates (${templates.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "Collapse" else "Expand"
                )
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Text(
                        text = "Tap any template to load pre-configured high quality prompts:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(templates) { (title, promptVal) ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                                modifier = Modifier.clickable {
                                    viewModel.onPromptChanged(promptVal)
                                    onShowSnackbar("Template '$title' applied!")
                                }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = title,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 19. Future Editing Toolbar Card
@Composable
private fun FutureEditingToolbarCard(
    onShowSnackbar: (String) -> Unit
) {
    val editingTools = remember {
        listOf(
            "Edit",
            "Remove Background",
            "Replace Background",
            "Erase Object",
            "Expand Image",
            "Upscale",
            "Enhance Face",
            "Magic Edit",
            "Filters",
            "Crop",
            "Rotate",
            "Flip"
        )
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Editing Toolbar",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Image Editing Suite",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.tertiaryContainer
                ) {
                    Text(
                        text = "Coming Soon",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(editingTools) { toolName ->
                    OutlinedButton(
                        onClick = { onShowSnackbar("Tool '$toolName' coming soon in next Image Studio update!") },
                        modifier = Modifier.height(36.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp)
                    ) {
                        Text(toolName, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

// 20. AI Prompt Intelligence Card (Phase 6.6.2A)
@Composable
private fun AIPromptIntelligenceCard(
    state: ImageGeneratorUiState,
    viewModel: ImageGeneratorViewModel,
    onShowSnackbar: (String) -> Unit
) {
    var selectedIntelTab by rememberSaveable { mutableStateOf("Inspiration") }
    val intelTabs = remember {
        listOf("Inspiration", "Seasonal", "Collections", "Categories", "History", "Surprise Me")
    }

    // Daily Inspiration (10 rotating prompt cards)
    val dailyInspirations = remember {
        listOf(
            "Bioluminescent ancient library built inside a giant grandfather clock, warm volumetric lighting, 8k",
            "Cyberpunk samurai warrior standing in neon rain street of Neo Tokyo, dramatic lighting",
            "Cute isometric 3D miniature bakery with freshly baked bread, pastel colors",
            "Surreal golden hourglass in desert with floating cosmic galaxies instead of sand",
            "Hyper-realistic portrait of an old clockmaker repairing a star map machine",
            "Haute couture fashion model wearing a dress made of iridescent glass water ripples",
            "Watercolor landscape of a misty Scandinavian mountain fjord with pine trees",
            "Handwritten organic chemistry lecture notes on reaction pathways with color diagrams",
            "Minimalist vector logo of a geometric phoenix rising, gold and obsidian color palette",
            "Cinematic movie poster for an epic sci-fi space exploration adventure, bold typography"
        )
    }

    // Seasonal Suggestions
    val seasonalPrompts = remember {
        listOf(
            "Festival" to "Vibrant traditional festival celebration with colorful lanterns, fireworks, and happy crowd",
            "Independence Day" to "Festive Independence Day patriotic banner with flying ribbons, fireworks, and golden monument",
            "Diwali" to "Glow of elegant Diwali clay oil lamps (diyas) surrounded by colorful flower rangoli art, warm festive glow",
            "Christmas" to "Cozy snow-covered Christmas cabin with warm glowing windows, Christmas tree, and starry winter night",
            "New Year" to "Spectacular New Year midnight fireworks display over illuminated skyline with golden celebration confetti",
            "Holi" to "Joyful Holi festival of colors celebration with splash of vibrant organic color powders in sunlight",
            "Eid" to "Beautiful Eid festival celebration with glowing crescent moon, intricate lantern lighting, and mosque silhouette"
        )
    }

    // Prompt Collections
    val collections = remember {
        listOf(
            "Beginner" to "A serene lake during sunrise with floating mist and mountains",
            "Professional" to "8k resolution, cinematic 85mm portrait, soft studio key light, photorealistic",
            "Business" to "Clean modern minimalist corporate logo icon, gold gradient, white background",
            "Education" to "Neat handwritten chemistry lecture revision notes with molecular diagrams",
            "Marketing" to "High-contrast promotional product poster with bold callout typography",
            "Exam" to "Structured biology exam review sheet with cell organelle diagrams and bullet points",
            "Art" to "Impressionist oil painting of a Venetian canal at sunset with vibrant brushstrokes",
            "Photography" to "Macro photograph of a dewdrop on a peacock feather, f/2.8 depth of field"
        )
    }

    // Prompt Categories (18 expanded categories)
    val expandedCategories = remember {
        listOf(
            "Nature", "Education", "Study", "Medical", "Architecture", "History",
            "Gaming", "Business", "Food", "Travel", "Fashion", "Animals",
            "Technology", "Festival", "Cartoon", "Anime", "Fantasy", "Sci-Fi"
        )
    }
    var activeCategory by rememberSaveable { mutableStateOf("Nature") }

    // Prompt History state
    var historySearchQuery by rememberSaveable { mutableStateOf("") }
    var historyItems by remember {
        mutableStateOf(
            listOf(
                "Cyberpunk neon city floating island",
                "Chemistry handwritten notes on reaction mechanisms",
                "Cute 3D rendered astronaut cat",
                "Vintage film noir detective portrait",
                "Minimalist geometric vector logo"
            )
        )
    }
    var favoritePrompts by remember { mutableStateOf(setOf<String>()) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "AI Intelligence",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = "AI Prompt Intelligence Engine",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Tabs Header
            ScrollableTabRow(
                selectedTabIndex = intelTabs.indexOf(selectedIntelTab).coerceAtLeast(0),
                edgePadding = 0.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                intelTabs.forEach { tabName ->
                    Tab(
                        selected = selectedIntelTab == tabName,
                        onClick = { selectedIntelTab = tabName },
                        text = {
                            Text(
                                text = tabName,
                                fontSize = 12.sp,
                                fontWeight = if (selectedIntelTab == tabName) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    )
                }
            }

            // Tab Content Body
            when (selectedIntelTab) {
                "Inspiration" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Daily Inspiration (10 Rotating Prompts)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(dailyInspirations) { inspireText ->
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)),
                                    modifier = Modifier
                                        .width(260.dp)
                                        .clickable {
                                            viewModel.onPromptChanged(inspireText)
                                            onShowSnackbar("Applied daily inspiration prompt!")
                                        }
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = inspireText,
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 3,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Tap to use",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Icon(
                                                imageVector = Icons.Default.AutoAwesome,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp),
                                                tint = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                "Seasonal" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Seasonal & Festival Prompts",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(seasonalPrompts) { (seasonName, seasonPrompt) ->
                                FilterChip(
                                    selected = false,
                                    onClick = {
                                        viewModel.onPromptChanged(seasonPrompt)
                                        onShowSnackbar("Applied $seasonName seasonal prompt!")
                                    },
                                    label = { Text("🎉 $seasonName", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                                )
                            }
                        }
                    }
                }

                "Collections" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Curated Collections",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(collections) { (colName, colPrompt) ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                                    modifier = Modifier.clickable {
                                        viewModel.onPromptChanged(colPrompt)
                                        onShowSnackbar("Collection '$colName' loaded!")
                                    }
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(colName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                                        Text(colPrompt, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                "Categories" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(expandedCategories) { cat ->
                                FilterChip(
                                    selected = activeCategory == cat,
                                    onClick = { activeCategory = cat },
                                    label = { Text(cat, fontSize = 11.sp) }
                                )
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val catPrompt = "Masterpiece $activeCategory artwork in high resolution, vivid colors and atmospheric lighting"
                                    viewModel.onPromptChanged(catPrompt)
                                    onShowSnackbar("Loaded $activeCategory category prompt!")
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Load $activeCategory Template Prompt", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }

                "History" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = historySearchQuery,
                            onValueChange = { historySearchQuery = it },
                            placeholder = { Text("Search prompt history...", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        )

                        val filteredHistory = historyItems.filter { it.contains(historySearchQuery, ignoreCase = true) }
                        if (filteredHistory.isEmpty()) {
                            Text("No matching history found.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                filteredHistory.forEach { histItem ->
                                    val isFav = favoritePrompts.contains(histItem)
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = histItem,
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clickable {
                                                        viewModel.onPromptChanged(histItem)
                                                        onShowSnackbar("Reused prompt from history")
                                                    },
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                                IconButton(
                                                    onClick = {
                                                        favoritePrompts = if (isFav) favoritePrompts - histItem else favoritePrompts + histItem
                                                    },
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                                        contentDescription = "Favorite",
                                                        tint = if (isFav) MaterialTheme.colorScheme.primary else Color.Gray,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                                IconButton(
                                                    onClick = { historyItems = historyItems - histItem },
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Delete,
                                                        contentDescription = "Delete",
                                                        tint = MaterialTheme.colorScheme.error,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                "Surprise Me" -> {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Need inspiration? Let Lumina AI surprise you with a unique prompt!",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center
                        )
                        Button(
                            onClick = {
                                val surprise = dailyInspirations.random()
                                viewModel.onPromptChanged(surprise)
                                onShowSnackbar("✨ Generated surprise prompt!")
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Shuffle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Surprise Me!", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// 21. AI Creative Assistant Card (Phase 6.6.2B)
@Composable
private fun AICreativeAssistantCard(
    state: ImageGeneratorUiState,
    viewModel: ImageGeneratorViewModel,
    onShowSnackbar: (String) -> Unit
) {
    var activeAssistantTab by rememberSaveable { mutableStateOf("AI Ideas") }
    val assistantTabs = remember {
        listOf("AI Ideas", "Smart Templates", "Favorites Studio", "Learning Center")
    }

    // AI Idea Generator (20 creative ideas across 9 categories)
    val ideaCategories = remember {
        listOf("Education", "Business", "Marketing", "Social Media", "Art", "Photography", "Gaming", "Festival", "Travel")
    }
    var activeIdeaCategory by rememberSaveable { mutableStateOf("Education") }

    val categoryIdeasMap = remember {
        mapOf(
            "Education" to listOf(
                "Handwritten chemistry notes with colorful reaction diagrams and formula callouts",
                "Biology cell organelle mind map drawn neatly on grid notebook paper",
                "Physics formulas summary sheet with vector diagrams and handwritten annotations",
                "Infographic roadmap of world history timeline with minimalist icons",
                "Mathematics calculus derivatives cheat sheet on lined yellow notepad"
            ),
            "Business" to listOf(
                "Modern minimalist corporate logo icon with sleek gold metallic finish",
                "Executive business presentation slide visual with 3D isometric growth charts",
                "Professional linkedin banner for a technology startup founder",
                "Sleek architectural blueprint rendering of a sustainable green office building",
                "Luxury branding mockups for premium coffee bean package design"
            ),
            "Marketing" to listOf(
                "High-impact promotional product banner poster for wireless noise-canceling headphones",
                "Eye-catching digital marketing ad banner with bold typography and vibrant gradient",
                "Food delivery mobile app promotional poster featuring fresh gourmet burger",
                "E-commerce flash sale banner design with floating 3D discount badges",
                "Fitness app promotional poster with dynamic athletic runner in motion"
            ),
            "Social Media" to listOf(
                "Aesthetic Instagram story template with soft neutral pastel tones and minimalist frame",
                "YouTube video thumbnail design with vibrant contrasting title text and expressive face",
                "TikTok viral trend aesthetic wallpaper with neon glow accents",
                "Twitter header banner with cosmic galaxy gradient and clean geometric shapes",
                "Pinterest inspirational lifestyle moodboard collage with warm film aesthetic"
            ),
            "Art" to listOf(
                "Impressionist oil painting of a Venetian canal at golden sunset with rich textures",
                "Surreal digital art concept of floating islands connected by glowing crystal bridges",
                "Japanese ukiyo-e woodblock print style illustration of a dragon amidst waves",
                "Minimalist abstract ink wash landscape with solitary pine tree and full moon",
                "Cyberpunk street art mural featuring a neon street samurai in rain"
            ),
            "Photography" to listOf(
                "Macro photography of a crystal clear dewdrop reflecting sunset on a peacock feather",
                "Cinematic 85mm portrait shot of an artisan watchmaker in a warm workshop with dust motes",
                "Architectural black and white photograph of spiral skyscraper stairs looking up",
                "National Geographic style wildlife photograph of a majestic snow leopard in blizzard",
                "Long exposure nighttime photograph of vibrant city traffic light trails"
            ),
            "Gaming" to listOf(
                "Epic fantasy RPG game title key art featuring a knight facing a colossal frost dragon",
                "Isometric 3D low-poly game asset environment of a cozy wizard tower interior",
                "Futuristic mech suit concept art with glowing plasma weapon systems",
                "Pixel art 16-bit retro platformer level scene with waterfall and ancient ruins",
                "Esports gaming tournament trophy banner design with glowing energy particles"
            ),
            "Festival" to listOf(
                "Warm Diwali oil lamp (diya) festivity banner with intricate golden rangoli patterns",
                "Vibrant Holi festival burst of organic powder colors in bright outdoor sunlight",
                "Cozy winter Christmas holiday postcard with snow-capped pine cabin and fairy lights",
                "Spectacular New Year celebration banner with fireworks exploding over harbour bridge",
                "Cultural festival poster with glowing lanterns illuminating a night sky"
            ),
            "Travel" to listOf(
                "Breathtaking drone aerial shot of tropical turquoise lagoon in Maldives",
                "Misty sunrise landscape of ancient hot air balloons floating over Cappadocia valley",
                "Scenic train journey winding through snow-covered Swiss Alps mountains",
                "Vibrant night market street scene in Bangkok with street food stalls and lanterns",
                "Peaceful Kyoto bamboo forest trail drenched in soft morning sunlight"
            )
        )
    }

    // Smart Templates
    var activeTemplateTab by rememberSaveable { mutableStateOf("Featured") }
    val templateTabs = remember { listOf("Featured", "Trending", "Recently Used", "Favorites", "Premium 🔒") }

    // Learning Center Guides
    var expandedGuideTopic by rememberSaveable { mutableStateOf<String?>(null) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Card Title Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoFixHigh,
                        contentDescription = "AI Creative Assistant",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = "AI Creative Assistant Studio",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                ) {
                    Text(
                        text = "PRO",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Top Navigation Tabs
            ScrollableTabRow(
                selectedTabIndex = assistantTabs.indexOf(activeAssistantTab).coerceAtLeast(0),
                edgePadding = 0.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                assistantTabs.forEach { tabTitle ->
                    Tab(
                        selected = activeAssistantTab == tabTitle,
                        onClick = { activeAssistantTab = tabTitle },
                        text = {
                            Text(
                                text = tabTitle,
                                fontSize = 12.sp,
                                fontWeight = if (activeAssistantTab == tabTitle) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    )
                }
            }

            // Tab Content
            when (activeAssistantTab) {
                "AI Ideas" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Need Ideas? Generate 20 Creative Prompt Ideas",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        // Category Chips
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(ideaCategories) { cat ->
                                FilterChip(
                                    selected = activeIdeaCategory == cat,
                                    onClick = { activeIdeaCategory = cat },
                                    label = { Text(cat, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                                )
                            }
                        }

                        // Ideas List
                        val currentIdeas = categoryIdeasMap[activeIdeaCategory] ?: emptyList()
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            currentIdeas.forEachIndexed { index, ideaText ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.onPromptChanged(ideaText)
                                            onShowSnackbar("Applied creative idea #${index + 1}!")
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "💡 $ideaText",
                                            style = MaterialTheme.typography.bodySmall,
                                            modifier = Modifier.weight(1f),
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = "Apply",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                "Smart Templates" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            templateTabs.forEach { tTab ->
                                FilterChip(
                                    selected = activeTemplateTab == tTab,
                                    onClick = { activeTemplateTab = tTab },
                                    label = { Text(tTab, fontSize = 11.sp) }
                                )
                            }
                        }

                        when (activeTemplateTab) {
                            "Premium 🔒" -> {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                            Column {
                                                Text("Unlock Premium Masterpiece Templates", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                                                Text("Access 100+ cinema-grade prompt structure templates", style = MaterialTheme.typography.bodySmall, fontSize = 11.sp)
                                            }
                                        }
                                    }

                                    listOf("8K Cinema Photorealism Pro", "Architectural Raytraced Render", "Hollywood Movie Poster Master").forEach { tName ->
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                            modifier = Modifier.fillMaxWidth().clickable {
                                                onShowSnackbar("Premium template clicked (Pro Feature Unlocked!)")
                                            }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text("🔒 $tName", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                                Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.Gray)
                                            }
                                        }
                                    }
                                }
                            }

                            else -> {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf(
                                        "YouTube Thumbnail Creator Template" to "High contrast subject, vibrant text area, dramatic lighting, 16:9 aspect ratio",
                                        "Minimalist Vector Logo Template" to "Clean geometric shape logo, flat vector design, white background, high contrast",
                                        "Handwritten Study Notes Template" to "Neat handwritten summary notes on lined notebook paper with colored diagrams"
                                    ).forEach { (title, desc) ->
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                            modifier = Modifier.fillMaxWidth().clickable {
                                                viewModel.onPromptChanged(desc)
                                                onShowSnackbar("Loaded $title template!")
                                            }
                                        ) {
                                            Column(modifier = Modifier.padding(10.dp)) {
                                                Text("✨ $title", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                                                Text(desc, style = MaterialTheme.typography.bodySmall, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                "Favorites Studio" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("⭐ Favorites & Saved Dashboard", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                        listOf(
                            "Cyberpunk neon city floating island" to "Pinned Prompt",
                            "Chemistry handwritten notes on reaction mechanisms" to "Saved Prompt",
                            "Photorealistic 8K Studio Lighting" to "Favorite Style"
                        ).forEach { (favTitle, favTag) ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(favTitle, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                        Text(favTag, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontSize = 10.sp)
                                    }
                                    Button(
                                        onClick = {
                                            viewModel.onPromptChanged(favTitle)
                                            onShowSnackbar("Reused saved item!")
                                        },
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text("Reuse", fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                "Learning Center" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("📚 AI Prompting Learning Center", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)

                        listOf(
                            "Prompt Writing Tips" to "Learn how to combine subject + style + lighting + camera angle for best AI image outputs.",
                            "Example Prompts Library" to "Explore before-and-after prompt transformations to level up your generations.",
                            "Beginner Guide" to "Step-by-step introduction to aspect ratios, quality keywords, and negative prompts.",
                            "Professional Masterclass Guide" to "Master lens sizes (85mm, 35mm), aperture (f/1.4), volumetric lights, and seed controls."
                        ).forEach { (guideTitle, guideDesc) ->
                            val isExpanded = expandedGuideTopic == guideTitle
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                                modifier = Modifier.fillMaxWidth().clickable {
                                    expandedGuideTopic = if (isExpanded) null else guideTitle
                                }
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("📖 $guideTitle", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                        Icon(
                                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                            contentDescription = null
                                        )
                                    }
                                    if (isExpanded) {
                                        Text(guideDesc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}



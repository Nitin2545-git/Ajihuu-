package com.example.luminaai.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.luminaai.domain.model.UserSession
import com.example.luminaai.util.LuminaLogger
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.sessionDataStore: DataStore<Preferences> by preferencesDataStore(name = "lumina_secure_session")

/**
 * SessionManager handles secure token storage, session state retrieval, and clearing user credentials upon logout.
 */
class SessionManager(private val context: Context) {

    private object Keys {
        val USER_ID = stringPreferencesKey("session_user_id")
        val EMAIL = stringPreferencesKey("session_email")
        val DISPLAY_NAME = stringPreferencesKey("session_display_name")
        val TOKEN = stringPreferencesKey("session_auth_token")
        val IS_GUEST = booleanPreferencesKey("session_is_guest")
        val IS_PRO = booleanPreferencesKey("session_is_pro")
    }

    val userSessionFlow: Flow<UserSession?> = context.sessionDataStore.data.map { prefs ->
        val userId = prefs[Keys.USER_ID]
        val email = prefs[Keys.EMAIL]
        val token = prefs[Keys.TOKEN]
        val displayName = prefs[Keys.DISPLAY_NAME] ?: "User"
        val isGuest = prefs[Keys.IS_GUEST] ?: false
        val isPro = prefs[Keys.IS_PRO] ?: false

        if (userId != null && token != null && email != null) {
            UserSession(
                userId = userId,
                email = email,
                displayName = displayName,
                token = token,
                isGuest = isGuest,
                isPro = isPro
            )
        } else null
    }

    suspend fun saveSession(session: UserSession) {
        LuminaLogger.d(TAG, "Saving active session for user: ${session.email} (Guest: ${session.isGuest})")
        context.sessionDataStore.edit { prefs ->
            prefs[Keys.USER_ID] = session.userId
            prefs[Keys.EMAIL] = session.email
            prefs[Keys.DISPLAY_NAME] = session.displayName
            prefs[Keys.TOKEN] = session.token
            prefs[Keys.IS_GUEST] = session.isGuest
            prefs[Keys.IS_PRO] = session.isPro
        }
    }

    suspend fun clearSession() {
        LuminaLogger.d(TAG, "Clearing active user session from local storage")
        context.sessionDataStore.edit { prefs ->
            prefs.clear()
        }
    }

    companion object {
        private const val TAG = "SessionManager"
    }
}

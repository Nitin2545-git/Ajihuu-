package com.example.luminaai.util

/**
 * Interface representing one-off UI side effects (e.g. snackbars, toasts, navigation).
 */
interface UiEffect {
    data class ShowSnackbar(val message: String) : UiEffect
    data class NavigateTo(val route: String) : UiEffect
    object NavigateBack : UiEffect
}

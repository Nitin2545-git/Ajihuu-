package com.example.luminaai.data.remote.gemini

object GeminiSafetyManager {

    // Default safety thresholds
    private const val BLOCK_MEDIUM_AND_ABOVE = "BLOCK_MEDIUM_AND_ABOVE"

    val DEFAULT_SAFETY_SETTINGS = listOf(
        GeminiSafetySetting(category = "HARM_CATEGORY_HARASSMENT", threshold = BLOCK_MEDIUM_AND_ABOVE),
        GeminiSafetySetting(category = "HARM_CATEGORY_HATE_SPEECH", threshold = BLOCK_MEDIUM_AND_ABOVE),
        GeminiSafetySetting(category = "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold = BLOCK_MEDIUM_AND_ABOVE),
        GeminiSafetySetting(category = "HARM_CATEGORY_DANGEROUS_CONTENT", threshold = BLOCK_MEDIUM_AND_ABOVE)
    )

    private val BANNED_PATTERNS = listOf(
        Regex("(?i)\\b(malware_payload|exploit_injection|bypass_security_guard)\\b")
    )

    /**
     * Checks user prompt locally before dispatching to API.
     */
    fun validatePromptSafety(prompt: String): ModerationResult {
        if (prompt.isBlank()) return ModerationResult.Allowed
        for (pattern in BANNED_PATTERNS) {
            if (pattern.containsMatchIn(prompt)) {
                return ModerationResult.Flagged("Prompt contains restricted security terms.")
            }
        }
        return ModerationResult.Allowed
    }

    sealed class ModerationResult {
        object Allowed : ModerationResult()
        data class Flagged(val reason: String) : ModerationResult()
    }
}

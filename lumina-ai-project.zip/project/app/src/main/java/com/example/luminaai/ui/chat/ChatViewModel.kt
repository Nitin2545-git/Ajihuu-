package com.example.luminaai.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.LuminaApp
import com.example.luminaai.data.remote.gemini.GeminiModelRegistry
import com.example.luminaai.data.remote.gemini.LuminaPersona
import com.example.luminaai.domain.model.ChatMessage
import com.example.luminaai.domain.model.ChatSession
import com.example.luminaai.domain.repository.ChatRepository
import com.example.luminaai.ui.base.BaseViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.util.UUID

data class ChatUiState(
    val sessionId: String = "",
    val sessionTitle: String = "Chat Thread",
    val modelUsed: String = GeminiModelRegistry.DEFAULT_MODEL,
    val selectedPersona: LuminaPersona = LuminaPersona.DEFAULT,
    val isPinned: Boolean = false,
    val messages: List<ChatMessage> = emptyList(),
    val filteredMessages: List<ChatMessage> = emptyList(),
    val searchQuery: String = "",
    val isSearching: Boolean = false,
    val promptText: String = "",
    val replyToMessage: ChatMessage? = null,
    val editingMessage: ChatMessage? = null,
    val isGenerating: Boolean = false,
    val isOffline: Boolean = false,
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
    val isRenameDialogOpen: Boolean = false,
    val isExportDialogOpen: Boolean = false,
    val exportedText: String = ""
)

class ChatViewModel(
    private val chatRepository: ChatRepository,
    private val initialSessionId: String
) : BaseViewModel<ChatUiState>(ChatUiState(sessionId = initialSessionId)) {

    private var streamJob: Job? = null

    init {
        initializeSession()
    }

    private fun initializeSession() {
        viewModelScope.launch {
            if (initialSessionId == "new" || initialSessionId.isBlank()) {
                val newSession = chatRepository.createChatSession(
                    title = "New Conversation",
                    modelUsed = GeminiModelRegistry.DEFAULT_MODEL
                )
                updateState { it.copy(sessionId = newSession.id) }
                observeSessionAndMessages(newSession.id)
            } else {
                observeSessionAndMessages(initialSessionId)
            }
        }
    }

    private fun observeSessionAndMessages(sessionId: String) {
        viewModelScope.launch {
            combine(
                chatRepository.getChatSessionFlow(sessionId),
                chatRepository.getMessagesForSession(sessionId)
            ) { session, messages ->
                val currentQuery = currentState().searchQuery
                val filtered = if (currentQuery.isBlank()) messages else messages.filter {
                    it.content.contains(currentQuery, ignoreCase = true)
                }

                updateState { state ->
                    state.copy(
                        sessionId = sessionId,
                        sessionTitle = session?.title ?: state.sessionTitle,
                        modelUsed = session?.modelUsed ?: state.modelUsed,
                        isPinned = session?.isPinned ?: state.isPinned,
                        messages = messages,
                        filteredMessages = filtered,
                        isLoading = false
                    )
                }
            }.collect {}
        }
    }

    fun onPromptTextChanged(text: String) {
        updateState { it.copy(promptText = text) }
    }

    fun onPersonaChanged(persona: LuminaPersona) {
        updateState { it.copy(selectedPersona = persona) }
    }


    fun onSearchQueryChanged(query: String) {
        val allMessages = currentState().messages
        val filtered = if (query.isBlank()) allMessages else allMessages.filter {
            it.content.contains(query, ignoreCase = true)
        }
        updateState {
            it.copy(
                searchQuery = query,
                filteredMessages = filtered
            )
        }
    }

    fun toggleSearching() {
        val currentlySearching = currentState().isSearching
        updateState {
            it.copy(
                isSearching = !currentlySearching,
                searchQuery = if (currentlySearching) "" else it.searchQuery,
                filteredMessages = if (currentlySearching) it.messages else it.filteredMessages
            )
        }
    }

    fun selectReplyMessage(message: ChatMessage?) {
        updateState { it.copy(replyToMessage = message) }
    }

    fun selectEditMessage(message: ChatMessage) {
        updateState {
            it.copy(
                editingMessage = message,
                promptText = message.content
            )
        }
    }

    fun cancelEdit() {
        updateState {
            it.copy(
                editingMessage = null,
                promptText = ""
            )
        }
    }

    fun sendMessage() {
        val state = currentState()
        val prompt = state.promptText.trim()
        if (prompt.isBlank() || state.isGenerating) return

        val sessionId = state.sessionId
        val model = state.modelUsed

        val editing = state.editingMessage
        if (editing != null) {
            // Updating existing prompt
            viewModelScope.launch(coroutineExceptionHandler) {
                val updatedUserMsg = editing.copy(
                    content = prompt,
                    timestamp = System.currentTimeMillis()
                )
                chatRepository.saveMessage(updatedUserMsg)
                updateState { it.copy(promptText = "", editingMessage = null) }
                triggerAiStreamingResponse(sessionId, prompt, model)
            }
            return
        }

        // New prompt send
        viewModelScope.launch(coroutineExceptionHandler) {
            val userMessage = ChatMessage(
                id = UUID.randomUUID().toString(),
                sessionId = sessionId,
                sender = ChatMessage.Sender.USER,
                content = prompt,
                timestamp = System.currentTimeMillis(),
                status = ChatMessage.MessageStatus.SENT
            )

            chatRepository.saveMessage(userMessage)

            // Auto-update session title if it's the first message
            if (state.messages.isEmpty() || state.sessionTitle == "New Conversation") {
                val autoTitle = if (prompt.length > 28) prompt.take(28) + "..." else prompt
                chatRepository.updateChatSession(
                    ChatSession(
                        id = sessionId,
                        title = autoTitle,
                        createdAt = System.currentTimeMillis(),
                        updatedAt = System.currentTimeMillis(),
                        modelUsed = model,
                        isPinned = state.isPinned
                    )
                )
            }

            updateState {
                it.copy(
                    promptText = "",
                    replyToMessage = null
                )
            }

            triggerAiStreamingResponse(sessionId, prompt, model)
        }
    }

    private fun triggerAiStreamingResponse(sessionId: String, prompt: String, modelName: String) {
        streamJob?.cancel()
        updateState { it.copy(isGenerating = true) }
        val persona = currentState().selectedPersona

        streamJob = viewModelScope.launch(coroutineExceptionHandler) {
            chatRepository.streamResponse(sessionId, prompt, modelName, persona).collect { streamMsg ->
                updateState {
                    it.copy(isGenerating = streamMsg.status == ChatMessage.MessageStatus.GENERATING)
                }
            }
        }
    }


    fun stopGeneration() {
        streamJob?.cancel()
        streamJob = null
        updateState { it.copy(isGenerating = false) }
    }

    fun regenerateResponse(assistantMessage: ChatMessage) {
        val state = currentState()
        val userMessages = state.messages.filter { it.sender == ChatMessage.Sender.USER }
        val lastUserPrompt = userMessages.lastOrNull()?.content ?: "Hello"

        viewModelScope.launch(coroutineExceptionHandler) {
            chatRepository.deleteMessage(assistantMessage.id)
            triggerAiStreamingResponse(state.sessionId, lastUserPrompt, state.modelUsed)
        }
    }

    fun deleteMessage(message: ChatMessage) {
        viewModelScope.launch(coroutineExceptionHandler) {
            chatRepository.deleteMessage(message.id)
        }
    }

    fun onModelChanged(newModel: String) {
        val state = currentState()
        viewModelScope.launch(coroutineExceptionHandler) {
            val updatedSession = ChatSession(
                id = state.sessionId,
                title = state.sessionTitle,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis(),
                modelUsed = newModel,
                isPinned = state.isPinned
            )
            chatRepository.updateChatSession(updatedSession)
            updateState { it.copy(modelUsed = newModel) }
        }
    }

    fun togglePin() {
        val state = currentState()
        val newPinned = !state.isPinned
        viewModelScope.launch(coroutineExceptionHandler) {
            val updatedSession = ChatSession(
                id = state.sessionId,
                title = state.sessionTitle,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis(),
                modelUsed = state.modelUsed,
                isPinned = newPinned
            )
            chatRepository.updateChatSession(updatedSession)
            updateState { it.copy(isPinned = newPinned) }
        }
    }

    fun setRenameDialogOpen(isOpen: Boolean) {
        updateState { it.copy(isRenameDialogOpen = isOpen) }
    }

    fun renameSession(newTitle: String) {
        val state = currentState()
        if (newTitle.isBlank()) return
        viewModelScope.launch(coroutineExceptionHandler) {
            val updatedSession = ChatSession(
                id = state.sessionId,
                title = newTitle,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis(),
                modelUsed = state.modelUsed,
                isPinned = state.isPinned
            )
            chatRepository.updateChatSession(updatedSession)
            updateState { it.copy(sessionTitle = newTitle, isRenameDialogOpen = false) }
        }
    }

    fun exportChat() {
        val state = currentState()
        val sb = StringBuilder()
        sb.appendLine("Lumina AI Conversation Export")
        sb.appendLine("Title: ${state.sessionTitle}")
        sb.appendLine("Model: ${state.modelUsed}")
        sb.appendLine("----------------------------------------")
        state.messages.forEach { msg ->
            val sender = if (msg.sender == ChatMessage.Sender.USER) "User" else "Lumina AI"
            sb.appendLine("[$sender]: ${msg.content}")
            sb.appendLine()
        }
        updateState { it.copy(exportedText = sb.toString(), isExportDialogOpen = true) }
    }

    fun closeExportDialog() {
        updateState { it.copy(isExportDialogOpen = false) }
    }

    fun clearMessages() {
        val state = currentState()
        viewModelScope.launch(coroutineExceptionHandler) {
            state.messages.forEach { msg ->
                chatRepository.deleteMessage(msg.id)
            }
        }
    }

    fun deleteSession(onDeleted: () -> Unit) {
        val sessionId = currentState().sessionId
        viewModelScope.launch(coroutineExceptionHandler) {
            chatRepository.deleteChatSession(sessionId)
            onDeleted()
        }
    }

    companion object {
        fun factory(sessionId: String): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = (this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as LuminaApp)
                ChatViewModel(
                    chatRepository = app.chatRepository,
                    initialSessionId = sessionId
                )
            }
        }
    }
}

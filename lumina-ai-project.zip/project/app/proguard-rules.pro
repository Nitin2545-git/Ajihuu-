# Production ProGuard & R8 Hardening Rules

# Retain annotations & generic signatures for reflection
-keepattributes Signature, InnerClasses, EnclosingMethod, *Annotation*, RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations

# Keep Moshi & Retrofit DTOs and Data Models
-keep class com.example.luminaai.data.remote.dto.** { *; }
-keep class com.example.luminaai.data.remote.gemini.** { *; }
-keep class com.example.luminaai.domain.model.** { *; }

# Keep Room Entities and Database
-keep class com.example.luminaai.data.local.entity.** { *; }
-keep class com.example.luminaai.data.local.dao.** { *; }
-keep class com.example.luminaai.data.local.LuminaDatabase { *; }
-keep class * extends androidx.room.RoomDatabase

# Keep Retrofit API interfaces
-keep interface com.example.luminaai.data.remote.api.** { *; }
-keep interface com.example.luminaai.data.remote.gemini.GeminiApiService { *; }

# Strip verbose debug logging in release builds
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}

# Preserve Compose UI annotations
-keepclassmembers class * {
    @androidx.compose.runtime.Composable <methods>;
}

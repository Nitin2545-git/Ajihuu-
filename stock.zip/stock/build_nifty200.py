from scanner.nifty_builder import NiftyBuilder

builder = NiftyBuilder()

builder.build()
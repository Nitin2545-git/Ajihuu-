from SmartApi import SmartConnect
import pyotp

from config import (
    SMART_API_KEY,
    SMART_CLIENT_ID,
    SMART_PIN,
    SMART_TOTP_SECRET
)


def authenticate():

    api = SmartConnect(api_key=SMART_API_KEY)

    totp = pyotp.TOTP(SMART_TOTP_SECRET).now()

    session = api.generateSession(
        SMART_CLIENT_ID,
        SMART_PIN,
        totp
    )

    if not session["status"]:
        raise Exception(session["message"])

    auth_token = session["data"]["jwtToken"]
    refresh_token = session["data"]["refreshToken"]
    feed_token = api.getfeedToken()

    return {
        "api": api,
        "auth_token": auth_token,
        "refresh_token": refresh_token,
        "feed_token": feed_token,
        "client_code": SMART_CLIENT_ID
    }


#!/data/data/com.termux/files/usr/bin/bash
pip install -r requirements.txt
cp -n .env.example .env
python main.py

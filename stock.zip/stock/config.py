import os
from dotenv import load_dotenv
load_dotenv()
SMART_API_KEY=os.getenv('SMART_API_KEY')
SMART_CLIENT_ID=os.getenv('SMART_CLIENT_ID')
SMART_PIN=os.getenv('SMART_PIN')
SMART_TOTP_SECRET=os.getenv('SMART_TOTP_SECRET')

from broker.auth import authenticate
from scanner.websocket_market import LiveMarket
from config import SMART_API_KEY


try:

    session = authenticate()

    print("=" * 40)
    print("SmartAPI Login Successful")
    print("=" * 40)

    live = LiveMarket(
        auth_token=session["auth_token"],
        api_key=SMART_API_KEY,
        client_code=session["client_code"],
        feed_token=session["feed_token"]
    )

    live.connect()

except Exception as e:

    print("Login Failed")
    print(e)
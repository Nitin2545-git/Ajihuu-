from scanner.orderflow import OrderFlow
from scanner.volume_detector import VolumeDetector


class ScannerEngine:

    def __init__(self):

        self.orderflow = OrderFlow()
        self.volume = VolumeDetector()

    def scan(self, symbol, message):

        ltp = message["last_traded_price"] / 100

        open_price = message["open_price_of_the_day"] / 100

        high = message["high_price_of_the_day"] / 100

        low = message["low_price_of_the_day"] / 100

        close = message["closed_price"] / 100

        volume = message["volume_trade_for_the_day"]

        buy_qty = message["total_buy_quantity"]

        sell_qty = message["total_sell_quantity"]

        timestamp = message["exchange_timestamp"] / 1000

        volume_data = self.volume.analyze(

            symbol,
            volume,
            timestamp

        )

        orderflow_data = self.orderflow.analyze(

            symbol,
            buy_qty,
            sell_qty,
            timestamp

        )

        return {

            "ltp": ltp,

            "open": open_price,

            "high": high,

            "low": low,

            "close": close,

            "volume": volume_data,

            "orderflow": orderflow_data,

            # Volume
            "volume_tick": volume_data["tick"],
            "volume_1s": volume_data["1s"],
            "volume_5s": volume_data["5s"],
            "volume_15s": volume_data["15s"],
            "volume_30s": volume_data["30s"],
            "volume_1m": volume_data["1m"],
            "volume_5m": volume_data["5m"],
            "volume_15m": volume_data["15m"],
            "volume_1h": volume_data["1h"],

            # Tick Flow
            "buy_tick": orderflow_data["tick"]["buy"],
            "sell_tick": orderflow_data["tick"]["sell"],
            "net_tick": orderflow_data["tick"]["net"],
            "tick_side": orderflow_data["tick"]["side"],

            # 1s
            "buy_1s": orderflow_data["1s"]["buy"],
            "sell_1s": orderflow_data["1s"]["sell"],
            "net_1s": orderflow_data["1s"]["net"],
            "side_1s": orderflow_data["1s"]["side"],

            # 5s
            "buy_5s": orderflow_data["5s"]["buy"],
            "sell_5s": orderflow_data["5s"]["sell"],
            "net_5s": orderflow_data["5s"]["net"],
            "side_5s": orderflow_data["5s"]["side"],

            # 15s
            "buy_15s": orderflow_data["15s"]["buy"],
            "sell_15s": orderflow_data["15s"]["sell"],
            "net_15s": orderflow_data["15s"]["net"],
            "side_15s": orderflow_data["15s"]["side"],

            # 30s
            "buy_30s": orderflow_data["30s"]["buy"],
            "sell_30s": orderflow_data["30s"]["sell"],
            "net_30s": orderflow_data["30s"]["net"],
            "side_30s": orderflow_data["30s"]["side"],

            # 1m
            "buy_1m": orderflow_data["1m"]["buy"],
            "sell_1m": orderflow_data["1m"]["sell"],
            "net_1m": orderflow_data["1m"]["net"],
            "side_1m": orderflow_data["1m"]["side"],

            # 5m
            "buy_5m": orderflow_data["5m"]["buy"],
            "sell_5m": orderflow_data["5m"]["sell"],
            "net_5m": orderflow_data["5m"]["net"],
            "side_5m": orderflow_data["5m"]["side"],

            # 15m
            "buy_15m": orderflow_data["15m"]["buy"],
            "sell_15m": orderflow_data["15m"]["sell"],
            "net_15m": orderflow_data["15m"]["net"],
            "side_15m": orderflow_data["15m"]["side"],

            # 1h
            "buy_1h": orderflow_data["1h"]["buy"],
            "sell_1h": orderflow_data["1h"]["sell"],
            "net_1h": orderflow_data["1h"]["net"],
            "side_1h": orderflow_data["1h"]["side"]

        }
from scanner.nifty_loader import NiftyLoader


class TokenMapper:

    def __init__(self):

        self.tokens = {}

        loader = NiftyLoader()

        for stock in loader.load():

            self.tokens[str(stock["token"])] = stock["symbol"]

    def get_symbol(self, token):

        return self.tokens.get(str(token), "UNKNOWN")
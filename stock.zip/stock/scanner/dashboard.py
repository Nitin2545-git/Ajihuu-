import os
import time


class Dashboard:

    SORT_BY = "1m"          # 1s, 5s, 15s, 30s, 1m, 5m, 15m, 1h
    REFRESH_TIME = 10
    SHOW_TOP = 15

    def __init__(self):
        self.data = {}
        self.last_refresh = 0

    def update(self, symbol, result):
        self.data[symbol] = result

    def show(self):

        now = time.time()
        if now - self.last_refresh < self.REFRESH_TIME:
            return

        self.last_refresh = now
        os.system("clear")

        rows = list(self.data.items())

        volume_key = f"volume_{self.SORT_BY}"
        buy_key = f"buy_{self.SORT_BY}"
        sell_key = f"sell_{self.SORT_BY}"
        net_key = f"net_{self.SORT_BY}"
        side_key = f"side_{self.SORT_BY}"

        volume_rank = sorted(rows, key=lambda x: x[1].get(volume_key, 0), reverse=True)
        positive_rank = sorted(rows, key=lambda x: x[1].get(net_key, 0), reverse=True)
        negative_rank = sorted(rows, key=lambda x: x[1].get(net_key, 0))

        print("=" * 170)
        print("FASTEST VOLUME + ORDER FLOW SCANNER".center(170))
        print("=" * 170)
        print(f"TimeFrame : {self.SORT_BY}    Tracked : {len(rows)}    Refresh : {self.REFRESH_TIME} sec")
        print("=" * 170)

        self._table("TOP FASTEST VOLUME", volume_rank, volume_key, buy_key, sell_key, net_key, side_key)
        self._table("TOP POSITIVE ORDER FLOW", positive_rank, volume_key, buy_key, sell_key, net_key, side_key)
        self._table("TOP NEGATIVE ORDER FLOW", negative_rank, volume_key, buy_key, sell_key, net_key, side_key)

        print("\n" + "=" * 170)
        print("VOLUME + ORDER FLOW CONFIRMATION")
        print("=" * 170)
        print(f"{'Symbol':<16}{'Volume':>12}{'Net':>12}{'Status':>18}")
        print("-" * 170)

        shown = 0
        for symbol, r in volume_rank:
            if shown >= self.SHOW_TOP:
                break
            vol = r.get(volume_key, 0)
            net = r.get(net_key, 0)
            if vol <= 0:
                continue
            if net > 0:
                status = "BUY CONFIRMED"
            elif net < 0:
                status = "SELL CONFIRMED"
            else:
                status = "WAIT"
            print(f"{symbol:<16}{vol:>12}{net:>12}{status:>18}")
            shown += 1

        print("=" * 170)

    def _table(self, title, rows, volume_key, buy_key, sell_key, net_key, side_key):
        print("\n" + "=" * 170)
        print(title)
        print("=" * 170)
        print(f"{'R':<4}{'Symbol':<16}{'LTP':>10}{'Vol':>12}{'Buy':>12}{'Sell':>12}{'Net':>12}{'Side':>12}")
        print("-" * 170)
        for i, (symbol, r) in enumerate(rows[:self.SHOW_TOP], start=1):
            print(
                f"{i:<4}"
                f"{symbol:<16}"
                f"{r.get('ltp',0):>10.2f}"
                f"{r.get(volume_key,0):>12}"
                f"{r.get(buy_key,0):>12}"
                f"{r.get(sell_key,0):>12}"
                f"{r.get(net_key,0):>12}"
                f"{r.get(side_key,'-'):>12}"
            )

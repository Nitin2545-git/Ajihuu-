from collections import deque


class OrderFlow:

    def __init__(self):

        self.history = {}

    def analyze(
        self,
        symbol,
        buy_qty,
        sell_qty,
        timestamp
    ):

        if symbol not in self.history:

            self.history[symbol] = deque()

        q = self.history[symbol]

        q.append(

            (
                timestamp,
                buy_qty,
                sell_qty
            )

        )

        # Keep last 1 hour data

        while q and timestamp - q[0][0] > 3600:

            q.popleft()

        def flow(seconds):

            old_buy = buy_qty
            old_sell = sell_qty

            for t, b, s in reversed(q):

                if timestamp - t >= seconds:

                    old_buy = b
                    old_sell = s
                    break

            buy_delta = buy_qty - old_buy

            sell_delta = sell_qty - old_sell

            net = buy_delta - sell_delta

            if net > 0:

                side = "BUY"

            elif net < 0:

                side = "SELL"

            else:

                side = "NEUTRAL"

            return {

                "buy": buy_delta,

                "sell": sell_delta,

                "net": net,

                "side": side

            }

        tick = flow(0)

        one = flow(1)

        five = flow(5)

        fifteen = flow(15)

        thirty = flow(30)

        one_min = flow(60)

        five_min = flow(300)

        fifteen_min = flow(900)

        one_hour = flow(3600)

        return {

            "tick": tick,

            "1s": one,

            "5s": five,

            "15s": fifteen,

            "30s": thirty,

            "1m": one_min,

            "5m": five_min,

            "15m": fifteen_min,

            "1h": one_hour

        }
class History:

    def __init__(self, limit=500):

        self.limit = limit
        self.data = []

    def add(self, candle):

        if candle is None:
            return

        self.data.append(candle)

        if len(self.data) > self.limit:

            self.data.pop(0)

    def last(self):

        if not self.data:
            return None

        return self.data[-1]

    def all(self):

        return self.data

    def size(self):

        return len(self.data)

    def clear(self):

        self.data.clear()
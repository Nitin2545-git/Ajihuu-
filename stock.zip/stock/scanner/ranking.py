class Ranking:

    def score(self, result):

        score = 0

        # -----------------------
        # Volume Weight
        # -----------------------

        score += result["volume_tick"] // 100

        score += result["volume_1s"] // 500

        score += result["volume_5s"] // 1000

        score += result["volume_15s"] // 2000

        score += result["volume_30s"] // 3000

        score += result["volume_1m"] // 5000

        # -----------------------
        # Buy Pressure
        # -----------------------

        score += result["buy_tick"] // 100

        score += result["buy_1s"] // 500

        score += result["buy_5s"] // 1000

        score += result["buy_15s"] // 2000

        score += result["buy_30s"] // 3000

        score += result["buy_1m"] // 5000

        # -----------------------
        # Sell Pressure
        # -----------------------

        score -= result["sell_tick"] // 100

        score -= result["sell_1s"] // 500

        score -= result["sell_5s"] // 1000

        score -= result["sell_15s"] // 2000

        score -= result["sell_30s"] // 3000

        score -= result["sell_1m"] // 5000

        # -----------------------
        # Net Order Flow Bonus
        # -----------------------

        score += result["net_tick"] // 100

        score += result["net_1s"] // 500

        score += result["net_5s"] // 1000

        score += result["net_15s"] // 2000

        score += result["net_30s"] // 3000

        score += result["net_1m"] // 5000

        return int(score)
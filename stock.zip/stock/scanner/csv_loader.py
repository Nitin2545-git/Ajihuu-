import csv


class CSVLoader:

    def __init__(self, file_path="data/watchlist.csv"):

        self.file_path = file_path

    def load(self):

        stocks = []

        with open(self.file_path, "r", newline="", encoding="utf-8") as file:

            reader = csv.DictReader(file)

            for row in reader:

                stocks.append({

                    "symbol": row["symbol"],

                    "exchangeType": int(row["exchangeType"]),

                    "token": row["token"]

                })

        return stocks
import csv
from scanner.master_loader import MasterLoader


class NiftyBuilder:

    def __init__(self):

        self.master = MasterLoader()

    def build(self):

        data = self.master.load()

        with open(
            "data/nifty500_symbols.txt",
            "r",
            encoding="utf-8"
        ) as f:

            symbols = set(

                line.strip().upper()

                for line in f

                if line.strip()

            )

        stocks = []

        added = set()

        for item in data:

            if item.get("exch_seg") != "NSE":

                continue

            symbol = item.get("symbol", "")

            if symbol.endswith("-EQ"):

                symbol = symbol[:-3]

            symbol = symbol.upper()

            if symbol not in symbols:

                continue

            if symbol in added:

                continue

            stocks.append({

                "symbol": symbol,

                "exchangeType": 1,

                "token": item["token"]

            })

            added.add(symbol)

        stocks.sort(

            key=lambda x: x["symbol"]

        )

        with open(

            "data/watchlist.csv",

            "w",

            newline="",

            encoding="utf-8"

        ) as f:

            writer = csv.DictWriter(

                f,

                fieldnames=[

                    "symbol",

                    "exchangeType",

                    "token"

                ]

            )

            writer.writeheader()

            writer.writerows(stocks)

        print(f"Exported {len(stocks)} stocks.")
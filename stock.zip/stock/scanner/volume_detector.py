from collections import deque


class VolumeDetector:

    def __init__(self):

        self.history = {}

    def analyze(self, symbol, current_volume, timestamp):

        if symbol not in self.history:

            self.history[symbol] = deque()

        q = self.history[symbol]

        q.append((timestamp, current_volume))

        # 1 Hour से पुराना data हटा दो
        while q and (timestamp - q[0][0]) > 3600:
            q.popleft()

        def delta(seconds):

            base = current_volume

            for t, v in reversed(q):

                if timestamp - t >= seconds:

                    base = v

                    break

            return current_volume - base

        return {

            "current": current_volume,

            "tick": delta(0),

            "1s": delta(1),

            "5s": delta(5),

            "15s": delta(15),

            "30s": delta(30),

            "1m": delta(60),

            "5m": delta(300),

            "15m": delta(900),

            "1h": delta(3600)

        }
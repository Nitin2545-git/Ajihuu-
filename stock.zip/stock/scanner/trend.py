class Trend:

    def analyze(self, candle):

        if candle is None:
            return "-"

        o = candle["open"]
        c = candle["close"]

        if o is None or c is None:
            return "-"

        if c > o:
            return "BUY"

        elif c < o:
            return "SELL"

        return "SIDE"
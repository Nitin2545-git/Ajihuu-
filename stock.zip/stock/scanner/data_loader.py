import json
import os


class DataLoader:

    def __init__(self, filename="scanner/data.json"):
        self.filename = filename

    def save(self, candles):

        with open(self.filename, "w") as f:
            json.dump(candles, f)

    def load(self):

        if not os.path.exists(self.filename):
            return []

        with open(self.filename, "r") as f:
            return json.load(f)


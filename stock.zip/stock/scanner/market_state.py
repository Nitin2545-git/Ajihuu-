class MarketState:

    def __init__(self):

        self.data = {}

    def update(self, symbol, message):

        self.data[symbol] = {

            "ltp": message["last_traded_price"] / 100,

            "open": message["open_price_of_the_day"] / 100,

            "high": message["high_price_of_the_day"] / 100,

            "low": message["low_price_of_the_day"] / 100,

            "close": message["closed_price"] / 100,

            "avg": message["average_traded_price"] / 100,

            "volume": message["volume_trade_for_the_day"],

            "buy_qty": message["total_buy_quantity"],

            "sell_qty": message["total_sell_quantity"],

            "time": message["exchange_timestamp"]

        }

    def get(self, symbol):

        return self.data.get(symbol)

    def all(self):

        return self.data
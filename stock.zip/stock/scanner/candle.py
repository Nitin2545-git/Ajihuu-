class Candle:

    def __init__(self):

        self.open = None
        self.high = None
        self.low = None
        self.close = None
        self.volume = 0

        self.start_time = None
        self.end_time = None

    def update(self, price, volume):

        if self.open is None:

            self.open = price
            self.high = price
            self.low = price
            self.close = price

        else:

            if price > self.high:
                self.high = price

            if price < self.low:
                self.low = price

            self.close = price

        self.volume += volume

    def reset(self):

        self.open = None
        self.high = None
        self.low = None
        self.close = None
        self.volume = 0

        self.start_time = None
        self.end_time = None

    def to_dict(self):

        return {

            "open": self.open,
            "high": self.high,
            "low": self.low,
            "close": self.close,
            "volume": self.volume,
            "start": self.start_time,
            "end": self.end_time

        }
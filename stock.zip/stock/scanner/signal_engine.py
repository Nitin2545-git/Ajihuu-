class SignalEngine:

    def generate(self, volume_signal, flow_signal):

        if volume_signal == "EXPLOSION" and flow_signal == "STRONG BUY":
            return {
                "score": 100,
                "signal": "STRONG BUY"
            }

        elif volume_signal in ["EXPLOSION", "HIGH"] and flow_signal == "BUY":
            return {
                "score": 80,
                "signal": "BUY"
            }

        elif volume_signal == "EXPLOSION" and flow_signal == "STRONG SELL":
            return {
                "score": 100,
                "signal": "STRONG SELL"
            }

        elif volume_signal in ["EXPLOSION", "HIGH"] and flow_signal == "SELL":
            return {
                "score": 80,
                "signal": "SELL"
            }

        else:
            return {
                "score": 50,
                "signal": "WAIT"
            }


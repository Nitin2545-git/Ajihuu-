import time


class RateLimiter:

    def __init__(self, delay=2):
        self.delay = delay
        self.last_call = 0

    def wait(self):

        current = time.time()

        elapsed = current - self.last_call

        if elapsed < self.delay:
            time.sleep(self.delay - elapsed)

        self.last_call = time.time()


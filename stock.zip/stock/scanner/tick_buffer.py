from collections import deque


class TickBuffer:

    def __init__(self, max_size=5000):

        self.buffer = deque(maxlen=max_size)

    def add(self, tick):

        self.buffer.append(tick)

    def get_all(self):

        return list(self.buffer)

    def last(self):

        if len(self.buffer) == 0:
            return None

        return self.buffer[-1]

    def clear(self):

        self.buffer.clear()

    def size(self):

        return len(self.buffer)


class Display:

    def show(self, symbol, state, result):

        flow = result["orderflow"]["signal"]
        vol = result["volume"]["signal"]

        if flow not in ["BUY", "SELL", "STRONG BUY", "STRONG SELL"] and vol != "EXPLOSION":
            return

        print("\n" + "=" * 70)

        print("SYMBOL :", symbol)
        print("LTP    :", state["ltp"])

        print("VOLUME :", result["volume"]["volume"])
        print("VOL %  :", result["volume"]["change_percent"])
        print("VOL SIG:", vol)

        print()

        print("BUY %  :", result["orderflow"]["buy_percent"])
        print("SELL % :", result["orderflow"]["sell_percent"])
        print("FLOW   :", flow)

        print()

        print("SCORE  :", result["score"])

        print("=" * 70)
from scanner.timeframe import TimeFrame
from scanner.history import History
from scanner.trend import Trend
from scanner.volume_trend import VolumeTrend


class TimeFrameManager:

    def __init__(self):

        self.trend = Trend()
        self.volume_trend = VolumeTrend()

        self.frames = {

            "1m": {
                "tf": TimeFrame(60),
                "history": History()
            },

            "5m": {
                "tf": TimeFrame(300),
                "history": History()
            },

            "15m": {
                "tf": TimeFrame(900),
                "history": History()
            },

            "1h": {
                "tf": TimeFrame(3600),
                "history": History()
            }

        }

    def update(self, price, volume, timestamp):

        for frame in self.frames.values():

            candle = frame["tf"].update(
                price,
                volume,
                timestamp
            )

            if candle is not None:

                frame["history"].add(candle)

    def get_current(self, name):

        return self.frames[name]["tf"].current()

    def get_history(self, name):

        return self.frames[name]["history"].all()

    def get_trends(self):

        trends = {}

        for name, frame in self.frames.items():

            candle = frame["tf"].current()

            trends[name] = self.trend.analyze(candle)

        return trends

    def get_volume_trends(self):

        volume_trends = {}

        for name, frame in self.frames.items():

            candle = frame["tf"].current()

            volume_trends[name] = self.volume_trend.analyze(candle)

        return volume_trends
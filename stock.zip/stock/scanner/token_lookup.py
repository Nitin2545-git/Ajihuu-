TOKENS = {

    "RELIANCE": {
        "exchange": "NSE",
        "token": "2885"
    },

    "SBIN": {
        "exchange": "NSE",
        "token": "3045"
    },

    "TCS": {
        "exchange": "NSE",
        "token": "11536"
    },

    "INFY": {
        "exchange": "NSE",
        "token": "1594"
    },

    "HDFCBANK": {
        "exchange": "NSE",
        "token": "1333"
    }

}


class TokenLookup:

    def get(self, symbol):

        symbol = symbol.upper()

        if symbol not in TOKENS:
            return None

        return TOKENS[symbol]


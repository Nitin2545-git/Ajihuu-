class VolumeTrend:

    def analyze(self, candle):

        if candle is None:
            return "-"

        volume = candle["volume"]

        if volume is None:
            return "-"

        if volume >= 1000000:
            return "HIGH"

        elif volume >= 500000:
            return "MED"

        return "LOW"
import csv


class NiftyLoader:

    def __init__(self):

        self.file = "data/watchlist.csv"

    def load(self):

        stocks = []

        with open(
            self.file,
            "r",
            encoding="utf-8"
        ) as f:

            reader = csv.DictReader(f)

            for row in reader:

                stocks.append({

                    "symbol": row["symbol"],

                    "exchangeType": int(
                        row["exchangeType"]
                    ),

                    "token": row["token"]

                })

        return stocks
import json


class MasterLoader:

    def __init__(self):

        self.file = "data/OpenAPIScripMaster.json"

    def load(self):

        with open(
            self.file,
            "r",
            encoding="utf-8"
        ) as f:

            return json.load(f)
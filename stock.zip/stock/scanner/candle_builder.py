class CandleBuilder:

    def __init__(self):

        self.open = None
        self.high = None
        self.low = None
        self.close = None
        self.volume = 0

    def update(self, price, volume):

        if self.open is None:

            self.open = price
            self.high = price
            self.low = price

        self.close = price

        if price > self.high:
            self.high = price

        if price < self.low:
            self.low = price

        self.volume += volume

    def candle(self):

        return {

            "open": self.open,

            "high": self.high,

            "low": self.low,

            "close": self.close,

            "volume": self.volume

        }

    def reset(self):

        self.open = None
        self.high = None
        self.low = None
        self.close = None
        self.volume = 0


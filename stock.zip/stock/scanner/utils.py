from datetime import datetime


def price(value):

    return round(value / 100, 2)


def percent(part, total):

    if total == 0:
        return 0

    return round((part / total) * 100, 2)


def buy_sell_ratio(buy_qty, sell_qty):

    total = buy_qty + sell_qty

    buy = percent(buy_qty, total)

    sell = percent(sell_qty, total)

    return buy, sell


def market_time(timestamp):

    return datetime.fromtimestamp(
        timestamp / 1000
    ).strftime("%H:%M:%S")


def volume_change(current, previous):

    return current - previous
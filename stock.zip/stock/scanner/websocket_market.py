from SmartApi.smartWebSocketV2 import SmartWebSocketV2

from scanner.nifty_loader import NiftyLoader
from scanner.token_mapper import TokenMapper
from scanner.market_state import MarketState
from scanner.scanner_engine import ScannerEngine
from scanner.dashboard import Dashboard
from scanner.timeframe_manager import TimeFrameManager


class LiveMarket:

    def __init__(self, auth_token, api_key, client_code, feed_token):

        self.sws = SmartWebSocketV2(
            auth_token,
            api_key,
            client_code,
            feed_token
        )

        self.loader = NiftyLoader()
        self.mapper = TokenMapper()
        self.state = MarketState()

        self.scanner = ScannerEngine()
        self.dashboard = Dashboard()

        self.timeframes = {}

    def connect(self):

        self.sws.on_open = self.on_open
        self.sws.on_data = self.on_data
        self.sws.on_error = self.on_error
        self.sws.on_close = self.on_close

        self.sws.connect()

    def on_open(self, ws):

        print("=" * 80)
        print("FASTEST VOLUME + ORDER FLOW SCANNER")
        print("=" * 80)

        stocks = self.loader.load()

        token_list = [
            {
                "exchangeType": 1,
                "tokens": []
            }
        ]

        print("\nLoading Watchlist...")
        print("-" * 80)

        for stock in stocks:

            token_list[0]["tokens"].append(str(stock["token"]))

            self.timeframes[stock["symbol"]] = TimeFrameManager()

        print(f"Loaded Stocks : {len(stocks)}")

        self.sws.subscribe(
            "scanner001",
            2,
            token_list
        )

        print(f"Subscribed : {len(stocks)} Stocks")

    def on_data(self, ws, message):

        try:

            token = str(message.get("token"))

            symbol = self.mapper.get_symbol(token)

            if symbol == "UNKNOWN":
                return

            price = message.get(
                "last_traded_price",
                0
            ) / 100

            volume = message.get(
                "volume_trade_for_the_day",
                0
            )

            timestamp = message.get(
                "exchange_timestamp",
                0
            ) / 1000

            self.state.update(
                symbol,
                message
            )

            self.timeframes[symbol].update(
                price,
                volume,
                timestamp
            )

            result = self.scanner.scan(
                symbol,
                message
            )

            result["timeframes"] = \
                self.timeframes[symbol].get_trends()

            self.dashboard.update(
                symbol,
                result
            )

            self.dashboard.show()

        except Exception as e:

            print("DATA ERROR :", e)

    def on_error(self, ws, error):

        print("\n" + "=" * 80)
        print("WEBSOCKET ERROR")
        print(error)
        print("=" * 80)

    def on_close(self, ws):

        print("\n" + "=" * 80)
        print("WebSocket Closed")
        print("=" * 80)
class Stock:

    def __init__(self, symbol, token, exchange_type=1):

        self.symbol = symbol
        self.token = token
        self.exchange_type = exchange_type

        self.ltp = 0.0
        self.open = 0.0
        self.high = 0.0
        self.low = 0.0
        self.close = 0.0

        self.volume = 0

        self.buy_qty = 0
        self.sell_qty = 0

    def update(self, message):

        self.ltp = message["last_traded_price"] / 100
        self.open = message["open_price_of_the_day"] / 100
        self.high = message["high_price_of_the_day"] / 100
        self.low = message["low_price_of_the_day"] / 100
        self.close = message["closed_price"] / 100

        self.volume = message["volume_trade_for_the_day"]

        self.buy_qty = message["total_buy_quantity"]
        self.sell_qty = message["total_sell_quantity"]

    def to_dict(self):

        return {

            "symbol": self.symbol,
            "token": self.token,

            "ltp": self.ltp,
            "open": self.open,
            "high": self.high,
            "low": self.low,
            "close": self.close,

            "volume": self.volume,

            "buy_qty": self.buy_qty,
            "sell_qty": self.sell_qty

        }
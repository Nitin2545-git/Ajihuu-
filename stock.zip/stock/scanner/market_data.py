from datetime import datetime, timedelta
from scanner.rate_limiter import RateLimiter


class MarketData:

    def __init__(self, api):

        self.api = api

        self.limiter = RateLimiter(2)


    def get_candles(
        self,
        exchange,
        symboltoken,
        interval="ONE_MINUTE",
        days=1
    ):

        self.limiter.wait()

        to_date = datetime.now()

        from_date = to_date - timedelta(days=days)

        params = {

            "exchange": exchange,

            "symboltoken": str(symboltoken),

            "interval": interval,

            "fromdate": from_date.strftime("%Y-%m-%d %H:%M"),

            "todate": to_date.strftime("%Y-%m-%d %H:%M")

        }

        response = self.api.getCandleData(params)

        if not response.get("status"):
            return []

        candles = []

        for row in response["data"]:

            candles.append({

                "time": row[0],

                "open": float(row[1]),

                "high": float(row[2]),

                "low": float(row[3]),

                "close": float(row[4]),

                "volume": float(row[5])

            })

        return candles


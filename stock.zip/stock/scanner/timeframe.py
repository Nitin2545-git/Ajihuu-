import time

from scanner.candle import Candle


class TimeFrame:

    def __init__(self, seconds):

        self.seconds = seconds
        self.candle = Candle()

        self.current_slot = None

    def update(self, price, volume, timestamp):

        slot = int(timestamp // self.seconds)

        if self.current_slot is None:

            self.current_slot = slot

        if slot != self.current_slot:

            finished = self.candle.to_dict()

            self.candle = Candle()

            self.current_slot = slot

            self.candle.update(
                price,
                volume
            )

            return finished

        self.candle.update(
            price,
            volume
        )

        return None

    def current(self):

        return self.candle.to_dict()